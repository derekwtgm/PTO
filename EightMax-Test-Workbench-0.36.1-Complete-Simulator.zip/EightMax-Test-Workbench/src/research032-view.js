/* EightMax Test Workbench 0.32 - pure view functions for the "Research" panel (preflop analysis, multi-street studies, coverage,
 * memory). No DOM; unit-tested. Wording rule (as 0.31): plain language first, technical measure second, every figure labelled with
 * its kind (exact count / sampled estimate / lower bound / unavailable) and its source (this computer or the release build machine).
 * Never "GTO", never a zero for something that was not measured. */
(function (root, factory) { if (typeof module === 'object' && module.exports) module.exports = factory(); else root.WorkbenchResearch032View = factory(); })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const pc = (x, d = 1) => (x === null || x === undefined || !Number.isFinite(x) ? '—' : (100 * x).toFixed(d) + '%');
  const ci = (c) => (Array.isArray(c) ? ' (95% interval ' + pc(c[0]) + '–' + pc(c[1]) + ')' : '');
  const bb = (x) => (x === null || x === undefined || !Number.isFinite(x) ? '—' : x.toFixed(Math.abs(x) < 0.01 ? 5 : 3) + ' bb');
  const mib = (b) => (b === null || b === undefined || !Number.isFinite(b) ? '—' : Math.round(b / 1048576) + ' MB');

  function preflopView(p) {
    if (!p || !p.available) return { headline: 'No preflop research yet', detail: (p && p.message) || 'Press Run Preflop Research.', rows: [], seats: [], missing: [], deviations: [], status: 'Not validated' };
    const runs = p.runs || [], base = runs.filter((r) => (r.variant || 'baseline') === 'baseline' && r.complete !== false), last = (base.length ? base.slice().sort((a, b) => b.updates - a.updates || a.seed - b.seed)[0] : runs[runs.length - 1]) || null;   // the main study: largest complete baseline
    const rows = runs.map((r) => ({ study: (r.variant || 'baseline') + ' · seed ' + r.seed + ' · ' + (r.updates || 0).toLocaleString('en-US') + ' updates' + (r.complete === false ? ' (incomplete)' : ''),
      classCoverage: pc(r.reachWeightedClassCoverage), comboCoverage: pc(r.reachWeightedComboCoverage), rangeSupport: pc(r.rangeSupportWithinLimit) + ci(r.rangeSupportCi95), noRowStates: (r.statesWithNoRow || 0).toLocaleString('en-US') + ' of ' + (r.decisionStates || 0).toLocaleString('en-US') }));
    return {
      headline: last ? 'Main study (' + (last.variant || 'baseline') + ', seed ' + last.seed + ', ' + (last.updates || 0).toLocaleString('en-US') + ' updates): hand-class coverage of reachable decisions ' + pc(last.reachWeightedClassCoverage) + '; flop ranges within the 25% unsupported limit ' + pc(last.rangeSupportWithinLimit) : 'No completed study',
      detail: (p.mode ? p.mode + ' · ' : '') + p.source + '. Coverage counts are exact; reach and range support are sampled estimates; deviation gains are LOWER-BOUND estimates.', status: 'Not validated: ' + String(p.validationStatus || 'no eight-handed accuracy measure exists').replace(/^not validated:\s*/i, ''), mainStudy: last ? (last.variant || 'baseline') + ' seed ' + last.seed + ', ' + (last.updates || 0).toLocaleString('en-US') + ' updates' : null,
      rows, seats: last ? last.perSeat.map((s) => ({ position: s.position, coverage: pc(s.classCoverage), missing: s.missingStates })) : [],
      missing: last ? (last.missingBranches || []).map((m) => ({ path: m.path, position: m.position, reach: pc(m.reach, 2), classes: m.classesStored + ' of ' + m.classesInRange + ' hand classes' })) : [],
      deviations: last ? (last.deviations || []).map((d) => ({ position: d.position, gain: d.error ? 'unavailable: ' + d.error : bb(d.gainBB) + (Array.isArray(d.ci95) ? ' [' + bb(d.ci95[0]) + ', ' + bb(d.ci95[1]) + ']' : ''), atNode: d.conditionalGainBB === null || d.conditionalGainBB === undefined ? '—' : bb(d.conditionalGainBB) + ' when reached (' + pc(d.reach, 2) + ' of hands)', fallback: d.fallbackShare === null || d.fallbackShare === undefined ? '—' : pc(d.fallbackShare) + ' of later lookups unvisited' })) : [],
      fullGame: 'Full eight-handed exploitability: unavailable (not computed; it is not zero).' };
  }
  function linkedView(l) {
    if (!l || !l.available) return { headline: 'No strategy library yet', detail: (l && l.message) || '', rows: [] };
    const rows = Object.entries(l.byStreet || {}).sort().map(([k, b]) => ({ street: k, records: b.records, linked: b.withLinkedContinuation, complete: b.linkedComplete, validated: b.validated, unverified: b.unverified, failed: b.failed,
      completeness: b.records ? pc(b.withLinkedContinuation / b.records, 0) + ' have continuation data' : '—', missing: b.records - b.withLinkedContinuation }));
    const tot = rows.reduce((a, r) => ({ records: a.records + r.records, linked: a.linked + r.linked, validated: a.validated + r.validated }), { records: 0, linked: 0, validated: 0 });
    return { headline: tot.validated + ' of ' + tot.records + ' stored strategies are validated; ' + tot.linked + ' have linked flop-to-river continuation data', detail: l.note, rows };
  }
  function coverageView(c) {
    if (!c || !c.available) return { headline: 'No coverage measurement yet', rows: [], streets: [] };
    const col = (name, x, kind) => (x ? { name, kind, decisions: x.decisions, exact: pc(x.exactShare) + ci(x.exactShareCi95), any: pc(x.anyStrategyShare) + ci(x.anyStrategyShareCi95), abstracted: x.abstracted, onDemand: x.solvedOnDemand, unavailable: x.unavailable } : null);
    const rows = [col('Unseen hands · stored strategies only', c.outOfSampleExact, 'exact'), col('+ validated approximations (opt-in)', c.outOfSampleWithApproximations, 'exact + labelled approximate'), col('+ on-demand heads-up rivers', c.outOfSampleWithOnDemandRivers, 'exact + solved on demand'), col('+ on-demand rivers and turns + approximations', c.outOfSampleWithOnDemandRiversTurnsAndApproximations, 'all 0.32 sources, each labelled')].filter(Boolean);
    const best = c.outOfSampleWithOnDemandRiversTurnsAndApproximations || c.outOfSampleWithOnDemandRivers || c.outOfSampleExact;
    const streets = best && best.byStreet ? Object.entries(best.byStreet).sort().map(([k, b]) => ({ street: k, decisions: b.decisions, exact: b.exact, abstracted: b.abstracted, onDemand: b.solvedOnDemand, unavailable: b.unavailable })) : [];
    const est = c.missingOnUnseenHands ? c.missingOnUnseenHands.estimatedTrainingHoursToCoverExactly : null;
    return { headline: 'On unseen hands: ' + (c.outOfSampleExact ? pc(c.outOfSampleExact.exactShare) : '—') + ' exact stored strategies, ' + (best ? pc(best.anyStrategyShare) : '—') + ' with every enabled source', detail: c.source + (c.baseline031 ? ' · 0.31 baseline: ' + c.baseline031.outOfSampleExact + ' exact' : ''), rows, streets,
      resources: est === null ? 'Training needed for the missing situations: not estimated' : 'Training needed to cover the missing situations exactly: about ' + est + ' single-thread hours (these exact situations rarely recur)' };
  }
  function memoryView(m) {
    if (!m) return { headline: 'Memory unknown', rows: [], live: null };
    const live = m.live ? { total: mib(m.live.totalBytes), used: pc(m.live.usedShare, 0), pressure: m.live.pressure, process: mib(m.live.thisProcessRssBytes) } : null;
    const rows = m.comparison ? (m.comparison.rows || []).map((r) => ({ tables: r.tables, before: r.peakRssMiB['0.31'] + ' MB', after: r.peakRssMiB['0.32'] + ' MB', saved: (r.peakRssMiB['0.31'] - r.peakRssMiB['0.32']) + ' MB', identical: r.identicalDecisions ? 'yes' : 'NO' })) : [];
    const shared = m.comparison && m.comparison.sharedPreflop ? mib(m.comparison.sharedPreflop.bytes) + ' shared preflop strategy (one copy for all workers)' : '—';
    return { headline: rows.length ? 'Ten tables: ' + rows[rows.length - 1].before + ' → ' + rows[rows.length - 1].after + ' peak memory with the shared preflop strategy' : 'No memory comparison yet', detail: (m.comparison ? m.comparison.source : '') + ' · ' + shared, rows, live, limits: m.trainingLimits || null };
  }
  function turnView(t) {
    if (!t || !t.available) return { headline: 'Turn solver not benchmarked on this computer yet', rows: [] };
    const rows = (t.rows || []).map((r) => ({ config: r.ranges + ' · ' + r.menu + ' · ' + r.stacks, result: r.error ? 'refused: ' + r.error : (r.exploitabilityPctPot === undefined ? '—' : r.exploitabilityPctPot.toFixed(3) + '% of the pot') + ' after ' + r.iterations + ' iterations, ' + (r.solveMs / 1000).toFixed(1) + ' s (' + r.stopped + ')', memory: r.memoryEstimateMiB === undefined ? '—' : r.memoryEstimateMiB + ' MB' }));
    return { headline: rows.filter((r) => !/refused/.test(r.result)).length + ' of ' + rows.length + ' turn configurations solved', detail: t.source, rows };
  }
  return { preflopView, linkedView, coverageView, memoryView, turnView, pc, bb, mib };
});
