/* EightMax Test Workbench 0.33 - pure view functions of the "Solver research" panel (no DOM; unit-tested).
   Input: the v033 block of GET /api/research/summary (tools/research-summary-033.cjs). Every row keeps its classification:
   approximate / restricted / exact / sampled / unavailable. Nothing is ever shown as "GTO" or "solved". */
(function (root, factory) { if (typeof module === 'object' && module.exports) module.exports = factory(); else root.WorkbenchResearch033View = factory(); })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const pct = (x, d = 1) => (x === null || x === undefined || !Number.isFinite(x) ? '—' : (x * 100).toFixed(d) + '%');
  const mib = (b) => (b ? (b / 1048576).toFixed(0) + ' MiB' : '—');
  const num = (x) => (x === null || x === undefined ? '—' : Number(x).toLocaleString('en-US'));
  const EXPLAIN = {
    approximate: 'Approximate: the strategy was trained in a simplified game (postflop play replaced by a check-down or a restricted tree). It is research data, not an equilibrium of the full game.',
    incomplete: 'Incomplete: some information sets were never visited by training; they are played uniformly and the strategy cannot be validated.',
    unverified: 'Unverified: no exact accuracy measurement exists for this strategy in its game.',
    restricted: 'Restricted: checked only against a limited set of responses or inside an abstraction; a lower bound, not a full measurement.',
  };
  function preflopModesView(b) {
    if (!b || !b.available) return { headline: (b && b.message) || 'No preflop mode comparison yet.', rows: [], positions: [], gains: [], comparisons: [], explain: [] };
    const rows = b.runs.map((r) => ({ study: 'Mode ' + r.mode + ' · seed ' + r.seed + ' · ' + num(r.updates) + ' updates', accuracy: r.accuracy || '—', memory: r.peakRssMiB ? Math.round(r.peakRssMiB) + ' MiB' : '—', state: mib(r.stateBytes), checkpoint: mib(r.checkpointBytes), speed: r.updatesPerSecond ? num(r.updatesPerSecond) + ' /s' : '—', postflop: pct(r.postflopRowShare) }));
    const latest = b.runs[b.runs.length - 1] || null;
    const positions = latest ? latest.positions.map((x) => ({ position: x.position, states: num(x.statesWithRows), coverage: pct(x.classCoverage), firstIn: x.firstInClasses === undefined ? '—' : x.firstInClasses + ' / 169', missing: x.firstInMissing === undefined ? '—' : String(x.firstInMissing) })) : [];
    const gains = []; for (const r of b.runs) for (const g of r.gains || []) gains.push({ study: 'Mode ' + r.mode + ' seed ' + r.seed, position: g.position, gain: g.gainBB === null ? (g.error ? 'unavailable: ' + g.error : '—') : g.gainBB.toFixed(4) + ' bb', ci: g.ci95 ? '[' + g.ci95.map((x) => x.toFixed(4)).join(', ') + ']' : '—', verdict: g.ci95 ? (g.ci95[0] > 0 ? 'profitable deviation found' : 'not resolved (interval includes 0)') : '—' });
    const comparisons = (b.comparisons || []).map((c) => ({ kind: c.kind === 'seed-noise' ? 'Seed noise (mode ' + c.mode + ')' : 'Model difference (' + c.modes.join(' vs ') + ', seed ' + c.seed + ')', updates: num(c.updates), mean: (c.nodes || []).filter((n) => n.meanTotalVariation !== null).map((n) => n.position + ' ' + n.meanTotalVariation.toFixed(2)).join(' · ') }));
    const approx = b.runs.some((r) => r.mode !== 'A');
    return { headline: b.runs.length + ' preflop studies (' + b.source + ')', rows, positions, positionsOf: latest ? 'Mode ' + latest.mode + ' seed ' + latest.seed + ' ' + num(latest.updates) : '', gains, comparisons, fullGame: b.fullGame || 'Eight-handed exploitability: unavailable.', explain: approx ? [EXPLAIN.approximate] : [] };
  }
  function calibrationView(b) {
    if (!b || !b.available) return { headline: (b && b.message) || 'Not measured yet.', rows: [] };
    const rows = []; for (const f of b.flops || []) for (const p of f.players) rows.push({ flop: f.flop, player: p.player, equilibrium: p.equilibriumValueBB.toFixed(3) + ' bb', checkdown: p.checkdownValueBB.toFixed(3) + ' bb', error: (p.differencePctPot >= 0 ? '+' : '') + p.differencePctPot.toFixed(1) + '% of pot', realisation: (p.realisation * 100).toFixed(1) + '%', accuracy: 'exact flop game, exploitability ' + f.exploitabilityPctPot + '% of pot' });
    return { headline: 'Check-down continuation vs exact flop equilibria: ' + (b.line || '') + ' (' + b.source + ')', rows, summary: b.summary };
  }
  function flopView(b) {
    if (!b || !b.available) return { headline: (b && b.message) || 'Not measured yet.', rows: [] };
    const rows = (b.results || []).map((x) => x.error ? { config: x.board + ' · ' + x.ranges, result: 'not completed: ' + x.error, status: 'unavailable' } : ({ config: x.board + ' · ' + x.ranges + ' · ' + x.menu + ' · ' + x.stacks, result: x.exploitabilityPctPot + '% of pot after ' + num(x.iterations) + ' iterations, ' + (x.wallMs / 1000).toFixed(1) + ' s, ' + x.memoryMiB + ' MiB', continuation: x.missingRows === 0 ? 'complete (every turn and river row stored)' : x.missingRows === null ? '—' : x.missingRows + ' rows missing (incomplete)', status: x.missingRows === 0 && x.meetsTarget ? 'validated at the target (exact, independent evaluator)' : x.meetsTarget ? 'incomplete' : 'did not reach the target' }));
    return { headline: 'Restricted heads-up flop solver (exact CFR+; ' + b.source + ')', rows, checks: b.checks || null };
  }
  function multiwayView(b) {
    if (!b || !b.available) return { headline: (b && b.message) || 'Not measured yet.', refs: [], cross: [] };
    const refs = (b.references || []).map((x) => ({ game: x.game, result: x.pass === true ? 'matches the analytic value' : x.pass === false ? 'MISMATCH' : 'convergence evidence', measured: JSON.stringify(x.measured).slice(0, 90) }));
    const cross = (b.crossCheck || []).map((x) => ({ updates: num(x.updates), independent: x.independentPctPot === undefined ? '—' : x.independentPctPot.toFixed(3) + '% of pot', engine: x.enginePctPot === undefined ? '—' : x.enginePctPot.toFixed(3) + '% of pot', agree: x.agree ? 'identical (1e-9)' : 'differ', status: x.missingRows ? 'incomplete (' + x.missingRows + ' unvisited rows)' : x.meetsLimit ? 'within 2.5% limit' : 'above 2.5% limit' }));
    return { headline: 'Independent multiway evaluator (' + b.source + ')', meaning: b.meaning, refs, cross };
  }
  function coverageView(b) {
    if (!b || !b.available || !b.summary) return { headline: (b && b.message) || 'Not measured yet.', rows: [] };
    const s = b.summary; return { headline: 'Unseen-hand strategy coverage (' + b.source + ')', rows: (s.rows || []).map((r) => ({ name: r.name, decisions: num(r.decisions), exact: pct(r.exactShare), approximate: pct(r.approximateShare), onDemand: pct(r.onDemandShare), unavailable: pct(r.unavailableShare), refused: num(r.gateRefusals) })), byStreet: s.byStreet || [], byPlayers: s.byPlayers || [] };
  }
  function performanceView(b) {
    if (!b || !b.available || !b.summary) return { headline: (b && b.message) || 'Not measured yet.', rows: [] };
    return { headline: 'Multi-table performance (' + b.source + ')', rows: (b.summary.rows || []).map((r) => ({ workload: r.workload, tables: r.tables, decisionsPerSecond: r.decisionsPerSecond, p95: r.p95 + ' ms', peak: r.peakRssMiB + ' MiB', errors: r.errors })) };
  }
  return { preflopModesView, calibrationView, flopView, multiwayView, coverageView, performanceView, EXPLAIN };
});
