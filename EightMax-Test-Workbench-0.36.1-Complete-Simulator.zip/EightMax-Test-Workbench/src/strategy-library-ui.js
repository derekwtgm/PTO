/* EightMax Test Workbench 0.30 - "Strategy library" panel. Reads the library status through the desktop host
   (GET /api/library/status) and starts the library tools in their own windows (POST /api/desktop/launch). In a plain
   browser it explains which .cmd file to double-click. It never trains or plays anything by itself. */
(function(){
'use strict';
const $=id=>document.getElementById(id),V=window.WorkbenchLibraryView;
const panel=$('sl-panel');if(!panel||!V)return;
function token(){const d=window.WorkbenchDesktop&&window.WorkbenchDesktop.fromPage&&window.WorkbenchDesktop.fromPage(window);return d&&d.secret?d.secret:null;}
async function host(method,path,body){
 const t=token();if(!t){const e=Error('Open the workbench with START-DESKTOP.cmd to use this button.');e.code='no-desktop-host';throw e;}
 const r=await fetch('http://127.0.0.1:48713'+path,{method,headers:{'X-EightMax-Session':t,'X-EightMax-Step':'dashboard-strategy-library',...(body===undefined?{}:{'Content-Type':'application/json'})},body:body===undefined?undefined:JSON.stringify(body),credentials:'omit',cache:'no-store'});
 let j=null;try{j=await r.json();}catch(e){}
 if(!r.ok){const e=Error((j&&j.error)||('HTTP '+r.status));e.code=j&&j.code;throw e;}
 return j;
}
function status(text,bad){const s=$('sl-status');s.textContent=text;s.classList.toggle('bad',!!bad);}
function render(st){
 const v=V.view(st);$('sl-headline').textContent=v.headline;$('sl-detail').textContent=v.detail;
 const tb=$('sl-rows');tb.textContent='';for(const [k,val] of v.rows){const tr=document.createElement('tr');const a=document.createElement('th');a.textContent=k;const b=document.createElement('td');b.textContent=val;tr.appendChild(a);tr.appendChild(b);tb.appendChild(tr);}
 $('sl-warning').hidden=!v.warning;$('sl-warning').textContent=v.warning||'';
}
async function refresh(){status('Reading the strategy library status…');try{render(await host('GET','/api/library/status'));status('Status read. Nothing was trained or changed.');}catch(e){status(e.code==='no-desktop-host'?'Not connected to the desktop host. Start with START-DESKTOP.cmd, or double-click VERIFY-STRATEGIES.cmd in the release folder.':'Could not read the status: '+e.message,true);}}
async function launch(tool,label){status('Starting '+label+'…');try{const r=await host('POST','/api/desktop/launch',{tool});status(r.message+' Press Refresh to see progress.');}catch(e){status(e.code==='no-desktop-host'?'Double-click '+label+' in the release folder (this page is not connected to the desktop host).':'Could not start '+label+': '+e.message,true);}}
const wire=(id,fn)=>{const el=$(id);if(el)el.addEventListener('click',fn);};
wire('sl-nav',()=>{panel.hidden=false;panel.scrollIntoView({behavior:'smooth'});refresh();});
wire('sl-close',()=>{panel.hidden=true;});wire('sl-refresh',refresh);
wire('sl-precompute',()=>launch('library-precompute','PRECOMPUTE-STRATEGIES.cmd'));wire('sl-record',()=>launch('library-record','RECORD-SITUATIONS.cmd'));
wire('sl-verify',()=>launch('library-verify','VERIFY-STRATEGIES.cmd'));wire('sl-cancel',()=>launch('library-cancel','CANCEL-TRAINING.cmd'));
wire('sl-export',()=>launch('library-export','EXPORT-STRATEGIES.cmd'));wire('sl-import',()=>launch('library-import','IMPORT-STRATEGIES.cmd'));
$('sl-missing-text').textContent=V.MISSING_TEXT;
})();
