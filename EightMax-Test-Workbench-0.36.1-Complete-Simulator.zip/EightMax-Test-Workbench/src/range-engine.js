/* EightMax Test Workbench 0.31: weighted opponent ranges, action-conditioned updates and street-to-street continuity.
 *
 * A range is a weight for each of the 1,326 two-card combinations (index order: card a < card b, card = rank*4 + suit, the same
 * order as EightMax 5.1). Weights are relative (not probabilities); `normalized()` gives probabilities for display.
 *
 * Bayesian conditioning. If a player follows a stored strategy sigma, the posterior weight of combo h after the player takes
 * action a at node I is   w'(h) = w(h) * sigma(a | I, h)   (the constant P(a) cancels in normalisation). Applied once per observed
 * action of that player, this is exact Bayes for "the player plays sigma"; it is only as good as sigma. Combos for which the
 * strategy has no stored row get likelihood 1 and are LISTED as unsupported (never filled with invented frequencies).
 *
 * Card removal. Combos containing a board card or a card known to the viewer are impossible and get weight 0 (with the mass
 * removed reported). Folded players' cards are NOT known and are never removed. The ranges handed to the solver do not remove
 * the hero's own cards: the study deals every player jointly from these ranges, and blocking is applied per deal by the engine.
 *
 * Provenance (every range says which applies):
 *   derived-validated-strategy    derived by conditioning on a strategy whose quality status is "validated"
 *   derived-approximate-strategy  derived from a stored strategy that is NOT validated (e.g. the 8-handed preflop study)
 *   observed-tendencies           estimated from observed frequencies of a specific opponent (profile counts)
 *   manual                        entered by a person
 *   assumed-any-two-cards         the 0.30 default model: every combination equally likely
 *   unknown                       not enough information (off-tree action, missing study, inconsistent observation)
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.WorkbenchRangeEngine = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const ok = (x, m) => { if (!x) throw new Error(m); };
  const RANKS = '23456789TJQKA', SUITS = 'cdhs';
  const PROVENANCE = Object.freeze({ VALIDATED: 'derived-validated-strategy', APPROXIMATE: 'derived-approximate-strategy', OBSERVED: 'observed-tendencies', MANUAL: 'manual', ANY_TWO: 'assumed-any-two-cards', UNKNOWN: 'unknown' });
  const PROVENANCE_TEXT = Object.freeze({
    'derived-validated-strategy': 'Derived from the betting so far, assuming players follow a strategy that passed an exact accuracy check',
    'derived-approximate-strategy': 'Derived from the betting so far, assuming players follow a stored strategy whose accuracy is NOT validated',
    'observed-tendencies': 'Estimated from this opponent\'s observed action frequencies (a statistical estimate)',
    manual: 'Entered manually',
    'assumed-any-two-cards': 'Assumption: every two-card hand equally likely (the 0.30 default model)',
    unknown: 'Unknown: not enough information to build a range',
  });

  /* ---------- combos and classes (independent enumeration, same order as EightMax) ---------- */
  const C1 = new Uint8Array(1326), C2 = new Uint8Array(1326), IDX = new Int16Array(52 * 52).fill(-1), CLASS = new Array(1326);
  { let k = 0; for (let a = 0; a < 52; a++) for (let b = a + 1; b < 52; b++) { C1[k] = a; C2[k] = b; IDX[a * 52 + b] = k; IDX[b * 52 + a] = k; CLASS[k] = classNameOf(a, b); k++; } }
  function classNameOf(a, b) { const ra = a >> 2, rb = b >> 2, hi = Math.max(ra, rb), lo = Math.min(ra, rb); return hi === lo ? RANKS[hi] + RANKS[lo] : RANKS[hi] + RANKS[lo] + ((a & 3) === (b & 3) ? 's' : 'o'); }
  const CLASS_NAMES = [...new Set(CLASS)].sort((x, y) => classRank(y) - classRank(x));
  function classRank(c) { const hi = RANKS.indexOf(c[0]), lo = RANKS.indexOf(c[1]); return hi * 100 + lo * 4 + (c.length === 2 ? 3 : c[2] === 's' ? 2 : 1); }
  const CLASS_COMBOS = new Map(); for (let i = 0; i < 1326; i++) { if (!CLASS_COMBOS.has(CLASS[i])) CLASS_COMBOS.set(CLASS[i], []); CLASS_COMBOS.get(CLASS[i]).push(i); }
  const cardId = (s) => { if (typeof s === 'number') return s; const r = RANKS.indexOf(String(s)[0].toUpperCase()), u = SUITS.indexOf(String(s)[1].toLowerCase()); ok(r >= 0 && u >= 0, 'Bad card ' + s); return r * 4 + u; };
  const cardStr = (c) => RANKS[c >> 2] + SUITS[c & 3];
  const comboIndex = (a, b) => { a = cardId(a); b = cardId(b); ok(a !== b, 'A combination needs two different cards'); return IDX[a * 52 + b]; };
  const comboStr = (i) => cardStr(C2[i]) + cardStr(C1[i]);

  /* ---------- weighted range ---------- */
  class WeightedRange {
    constructor(weights, meta = {}) {
      ok(weights && weights.length === 1326, 'A range needs 1,326 weights');
      this.w = Float64Array.from(weights); for (let i = 0; i < 1326; i++) ok(Number.isFinite(this.w[i]) && this.w[i] >= 0, 'Range weights must be finite and non-negative');
      this.provenance = meta.provenance || PROVENANCE.MANUAL; this.source = meta.source || null; this.events = (meta.events || []).slice(); this.unsupported = (meta.unsupported || []).slice(); this.invalid = meta.invalid || null;
    }
    static anyTwo() { return new WeightedRange(new Float64Array(1326).fill(1), { provenance: PROVENANCE.ANY_TWO, source: 'any-two-cards-v1' }); }
    static unknown(reason) { return new WeightedRange(new Float64Array(1326).fill(1), { provenance: PROVENANCE.UNKNOWN, invalid: reason || 'unknown' }); }
    /** Class-level weights: { 'AKs': 0.5, 'QQ': 1, ... } (missing classes 0). */
    static fromClassWeights(map, meta) { const w = new Float64Array(1326); for (const [c, v] of Object.entries(map)) { const combos = CLASS_COMBOS.get(c); ok(combos, 'Unknown hand class ' + c); for (const i of combos) w[i] = v; } return new WeightedRange(w, meta); }
    /** EightMax range text (uses the engine's parser so the result is exactly what a study would use). */
    static fromText(EM, text, meta = {}) { const f = EM.parseRange(text); return new WeightedRange(Array.from(f), { provenance: PROVENANCE.MANUAL, source: text, ...meta }); }
    clone() { return new WeightedRange(this.w, this); }
    total() { let s = 0; for (const x of this.w) s += x; return s; }
    combos() { let n = 0; for (const x of this.w) if (x > 0) n++; return n; }
    normalized() { const t = this.total(); ok(t > 0, 'Empty range'); return Float64Array.from(this.w, (x) => x / t); }
    /** Remove every combination that contains one of the cards (board or known cards). Returns this. */
    removeCards(cards, reason) {
      const ids = cards.map(cardId), before = this.total(); let removed = 0;
      for (let i = 0; i < 1326; i++) if (this.w[i] > 0 && (ids.includes(C1[i]) || ids.includes(C2[i]))) { removed += this.w[i]; this.w[i] = 0; }
      this.events.push({ kind: 'card-removal', cards: ids.map(cardStr), reason: reason || 'known cards', massBefore: +before.toFixed(6), massRemoved: +removed.toFixed(6) });
      if (this.total() <= 0) this.invalid = this.invalid || 'No combination remains after removing known cards';
      return this;
    }
    /**
     * Bayesian update with per-combo likelihoods (Float64Array 1326, entries in [0,1] or NaN = no data for that combo).
     * NaN combos keep their weight and are recorded as unsupported. A zero-mass posterior marks the range invalid (the observed
     * action was impossible under the assumed strategy) and keeps the prior, so nothing silently pretends to be informed.
     */
    condition(lik, event = {}) {
      ok(lik && lik.length === 1326, 'Likelihoods for 1,326 combinations required');
      const before = this.total(), next = new Float64Array(1326); let unsupportedCombos = 0, unsupportedMass = 0;
      for (let i = 0; i < 1326; i++) {
        const x = this.w[i]; if (!x) continue; const l = lik[i];
        if (Number.isNaN(l)) { next[i] = x; unsupportedCombos++; unsupportedMass += x; continue; }
        ok(l >= -1e-12 && l <= 1 + 1e-9, 'Likelihood outside [0,1] for ' + comboStr(i)); next[i] = x * Math.max(0, Math.min(1, l));
      }
      const after = next.reduce((a, b) => a + b, 0), rec = { kind: 'action', ...event, massBefore: +before.toFixed(6), massAfter: +after.toFixed(6), actionProbability: before > 0 ? +(after / before).toFixed(6) : null, unsupportedCombos, unsupportedMassShare: before > 0 ? +(unsupportedMass / before).toFixed(6) : 0 };
      if (after <= 1e-15) { rec.rejected = 'The observed action has probability zero for every remaining combination under the assumed strategy'; this.events.push(rec); this.invalid = rec.rejected; return this; }
      this.w = next; this.events.push(rec); if (unsupportedCombos) this.unsupported.push({ event: event.label || event.action || 'action', combos: unsupportedCombos, massShare: rec.unsupportedMassShare });
      return this;
    }
    /** Checks: finite, non-negative, non-empty, no impossible combos given dead cards. */
    validate(deadCards = []) {
      const problems = [], dead = deadCards.map(cardId);
      for (let i = 0; i < 1326; i++) { const x = this.w[i]; if (!Number.isFinite(x) || x < 0) { problems.push('Invalid weight for ' + comboStr(i)); break; } if (x > 0 && (dead.includes(C1[i]) || dead.includes(C2[i]))) { problems.push('Combination ' + comboStr(i) + ' contains a dead card'); break; } }
      if (!(this.total() > 0)) problems.push('Range is empty');
      if (this.invalid) problems.push(this.invalid);
      return { valid: problems.length === 0, problems };
    }
    /** Per-class summary for display: class -> { weight share, combos live }. */
    classSummary() {
      const t = this.total() || 1, out = [];
      for (const c of CLASS_NAMES) { let s = 0, live = 0; const cs = CLASS_COMBOS.get(c); for (const i of cs) { s += this.w[i]; if (this.w[i] > 0) live++; } if (s > 0) out.push({ cls: c, share: s / t, avgWeight: s / cs.length, combosLive: live, combosTotal: cs.length }); }
      return out;
    }
    /** Share of combos (by weight) in the strongest x% of classes (by a fixed preflop order) — a quick width indicator. */
    width() { let n = 0; for (const x of this.w) if (x > 1e-9) n++; return { combos: n, pctOfAllCombos: +(n / 1326 * 100).toFixed(2) }; }
    /**
     * Range text for an EightMax study: weights scaled so the largest is 1, rounded to `quantum`; weights that round to 0 are
     * dropped. Uses EightMax's own formatter; the result is parsed back and the error is REPORTED (never hidden).
     */
    toStudyText(EM, o = {}) {
      const q = o.quantum || 0.01, mx = Math.max(...this.w); ok(mx > 0, 'Empty range');
      const f = new Float32Array(1326); let dropped = 0, kept = 0, maxErr = 0;
      for (let i = 0; i < 1326; i++) { const v = this.w[i] / mx, r = Math.round(v / q) * q; f[i] = r; if (r === 0) dropped += v; else kept += v; }
      const text = EM.rangeToString(f), back = EM.parseRange(text);
      for (let i = 0; i < 1326; i++) maxErr = Math.max(maxErr, Math.abs(back[i] - this.w[i] / mx));
      return { text, quantum: q, droppedMassShare: +(dropped / (dropped + kept)).toFixed(6), maxAbsWeightError: +maxErr.toFixed(6), combos: back.reduce((n, x) => n + (x > 0 ? 1 : 0), 0) };
    }
    /** Comparison with another range: total-variation distance of the normalised ranges and overlap. */
    compare(other) { const a = this.normalized(), b = other.normalized(); let tv = 0, ov = 0; for (let i = 0; i < 1326; i++) { tv += Math.abs(a[i] - b[i]); ov += Math.min(a[i], b[i]); } return { totalVariation: +(tv / 2).toFixed(6), overlap: +ov.toFixed(6) }; }
    describe() { return { provenance: this.provenance, provenanceText: PROVENANCE_TEXT[this.provenance], source: this.source, combos: this.combos(), totalWeight: +this.total().toFixed(6), invalid: this.invalid, unsupported: this.unsupported, events: this.events }; }
  }

  /* ---------- likelihoods from stored strategies ---------- */
  /**
   * Per-combo likelihood of taking slot `slot` at node `key` for study seat `seat`, read from a prepared study / snapshot
   * (`averageAt(key, board, seat, {id,a,b,w})`). `rows` maps combo index -> study row [id,a,b,w]. Combos without a row or without a
   * stored strategy get NaN. With `poolClasses` (valid ONLY without a board, i.e. preflop: suits are symmetric) a combo with no row
   * takes the mean strategy of the stored combos of its class, and the class mean is used for every combo (removes sampling noise).
   * `perm` (optional): suit permutation applied to cards before lookup (library boards stored in canonical suits).
   */
  function strategyLikelihood(game, board, seat, key, slot, rows, o = {}) {
    const lik = new Float64Array(1326).fill(NaN), perm = o.perm, map = (c) => (perm ? (c & ~3) | perm[c & 3] : c);
    const probOf = (i) => { const a = map(C1[i]), b = map(C2[i]), r = rows.get(IDX[a * 52 + b]); if (!r) return null; const p = game.averageAt(key, board, seat, { id: r[0], a: r[1], b: r[2], w: r[3] }); return p ? p[slot] : null; };
    if (o.poolClasses) {
      for (const [, combos] of CLASS_COMBOS) { let s = 0, n = 0; for (const i of combos) { const p = probOf(i); if (p !== null && p !== undefined) { s += p; n++; } } if (n) for (const i of combos) lik[i] = s / n; }
    } else for (let i = 0; i < 1326; i++) { const p = probOf(i); if (p !== null && p !== undefined) lik[i] = p; }
    return lik;
  }
  /** Map from combo index to study row (rows are [id, a, b, w] with engine card ids). */
  function rowMap(rows) { const m = new Map(); for (const r of rows) m.set(IDX[r[1] * 52 + r[2]], r); return m; }

  /**
   * Preflop ranges of every seat from the eight-handed linked preflop study (src/solver-tree.js PreflopTreeSource).
   * req: a decision request (button, actions [{seat,type,amount,street}], board ignored). Uses only actions with street 'preflop'
   * (or untagged actions before any board). Returns { ranges: Map(simSeat -> WeightedRange), status, reason, studyId, path }.
   */
  function preflopRanges(source, req, o = {}) {
    const study = source.study, prepared = study.prepared, ST = o.ST || require('./solver-tree.js');
    study.seatOrder = ST.preflopSeatOrder(req.button);
    const pre = req.actions.filter((a) => a.street === undefined ? true : a.street === 'preflop');
    const provenance = o.strategyValidated ? PROVENANCE.VALIDATED : PROVENANCE.APPROXIMATE, out = new Map();
    const priorText = prepared.options.config.ranges, EM = study.EM;
    study.seatOrder.forEach((sim, s) => { const r = WeightedRange.fromText(EM, priorText[s], { provenance, source: 'preflop study ' + (study.id || '') + ' (seat ' + s + ' prior "' + priorText[s] + '")' }); out.set(sim, r); });
    const w = study._walk(pre);
    if (w.error) { for (const [sim] of out) out.set(sim, WeightedRange.unknown('Preflop history could not be mapped onto the preflop study: ' + w.error)); return { ranges: out, status: 'unknown', reason: w.error, code: w.code }; }
    const rowsBySeat = new Map(); prepared.spec.hands.forEach((rows, s) => rowsBySeat.set(s, rowMap(rows)));
    for (let i = 0; i < pre.length; i++) {
      const steps = w.steps.slice(0, i), key = 'r' + steps.join(''), v = study._view(steps), slot = w.steps[i], sim = study.seatOrder[v.seat];
      const lik = strategyLikelihood(prepared.game, prepared.spec.board, v.seat, key, slot, rowsBySeat.get(v.seat), { poolClasses: true });
      out.get(sim).condition(lik, { street: 'preflop', seat: sim, action: pre[i].type, amount: pre[i].amount, label: 'preflop ' + v.labels[slot], node: key });
    }
    const invalid = [...out.values()].find((r) => r.invalid);
    return { ranges: out, status: invalid ? 'invalid' : 'ok', reason: invalid ? invalid.invalid : null, studyId: study.id, path: w.key };
  }

  /**
   * Condition street-start ranges on the actions of one finished street, using that street's stored study (library snapshot).
   * studyGame: snapshot/prepared game with view/averageAt; seatOrder: sim seats in study seat order; actions: that street's actions;
   * perm: suit permutation used to store the study board (or null). Returns { status, reason } and updates the ranges in place.
   */
  function conditionOnStreet(ranges, studyGame, spec, seatOrder, actions, o = {}) {
    const steps = []; const rowsBySeat = new Map(spec.hands.map((rows, s) => [s, rowMap(rows)]));
    const labelsOf = (v) => (v.actions || []).map((a) => a.label);
    for (const a of actions) {
      const v = studyGame.view(steps); if (v.kind !== 'player') return { status: 'unknown', reason: 'Street history continues past a ' + v.kind + ' node' };
      const sim = seatOrder[v.seat]; if (sim !== a.seat) return { status: 'unknown', reason: 'Action by seat ' + a.seat + ' does not match the study\'s acting seat ' + sim };
      const parsed = labelsOf(v).map(o.parseLabel || defaultParseLabel()); let slot = -1;
      if (['fold', 'check', 'call'].includes(a.type)) slot = parsed.findIndex((p) => p.kind === a.type);
      else slot = parsed.findIndex((p) => (p.kind === 'bet' || p.kind === 'raise' || p.kind === 'allin') && p.to !== null && p.to !== undefined && Math.abs(p.to - a.amount) <= 0.51);
      if (slot < 0 && a.type === 'allin') slot = parsed.findIndex((p) => p.kind === 'allin');
      if (slot < 0) return { status: 'unknown', reason: 'Action ' + a.type + (a.amount ? ' to ' + a.amount / 100 + ' bb' : '') + ' is not in the study menu (' + labelsOf(v).join(' / ') + ')' };
      const key = 'r' + steps.join(''), lik = strategyLikelihood(studyGame, spec.board, v.seat, key, slot, rowsBySeat.get(v.seat), { perm: o.perm });
      ranges.get(sim).condition(lik, { street: o.street, seat: sim, action: a.type, amount: a.amount, label: o.street + ' ' + labelsOf(v)[slot], node: key });
      if (o.provenance) ranges.get(sim).provenance = worse(ranges.get(sim).provenance, o.provenance);
      steps.push(slot);
    }
    return { status: 'ok' };
  }
  /** Weaker of two provenances (a range is only as well-founded as the least-founded strategy used to build it). */
  const ORDER = [PROVENANCE.VALIDATED, PROVENANCE.APPROXIMATE, PROVENANCE.OBSERVED, PROVENANCE.MANUAL, PROVENANCE.ANY_TWO, PROVENANCE.UNKNOWN];
  function worse(a, b) { return ORDER.indexOf(a) >= ORDER.indexOf(b) ? a : b; }
  /** Menu labels are parsed by the same function the decision path uses (src/solver-tree.js; amounts in chips). */
  function defaultParseLabel() { if (typeof require !== 'function') throw new Error('Pass o.parseLabel in the browser'); return require('./solver-tree.js').parseLabel; }

  /**
   * Range for an opponent from observed tendencies: the top `pct` of hand classes by a fixed preflop strength order, weighted by
   * how many times it has been observed (confidence). This is a STATISTICAL ESTIMATE, labelled as such, with a binomial interval.
   * stats: { hands, vpip } (counts). Needs at least `minHands` observations; otherwise unknown.
   */
  function fromTendencies(stats, o = {}) {
    const minHands = o.minHands || 30; if (!stats || !(stats.hands >= minHands)) return { range: WeightedRange.unknown('Fewer than ' + minHands + ' observed hands for this opponent'), interval: null };
    const p = stats.vpip / stats.hands, z = 1.96, n = stats.hands, den = 1 + z * z / n, centre = (p + z * z / (2 * n)) / den, half = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den;
    const order = o.order || strengthOrder(o.EM), target = p * 1326, w = new Float64Array(1326); let acc = 0;
    for (const c of order) { if (acc >= target) break; for (const i of CLASS_COMBOS.get(c)) w[i] = 1; acc += CLASS_COMBOS.get(c).length; }
    const r = new WeightedRange(w, { provenance: PROVENANCE.OBSERVED, source: 'observed VPIP ' + (p * 100).toFixed(1) + '% over ' + n + ' hands' });
    return { range: r, interval: { vpip: p, ci95: [Math.max(0, centre - half), Math.min(1, centre + half)], hands: n, method: 'Wilson score interval' } };
  }

  /** Hand classes ordered by all-in equity against a random hand (EightMax's class equity table, combo-weighted). */
  let ORDER_CACHE = null;
  function strengthOrder(EM) {
    if (ORDER_CACHE) return ORDER_CACHE; ok(EM && EM.classEquity && EM.CLASS_NAMES, 'A strength order needs the EightMax card library (or pass o.order)');
    const n = EM.CLASS_NAMES.length, score = EM.CLASS_NAMES.map((_, a) => { let s = 0, t = 0; for (let b = 0; b < n; b++) { const w = EM.CLASS_NCOMBOS[b]; s += EM.classEquity(a, b) * w; t += w; } return s / t; });
    return (ORDER_CACHE = EM.CLASS_NAMES.map((c, k) => [c, score[k]]).sort((x, y) => y[1] - x[1]).map((x) => x[0]));
  }

  /**
   * Per-hand tracker: one weighted range per seat, carried from preflop to the river. Folded players leave the active set (their
   * cards stay unknown, not dead); all-in players stay in the pot without further conditioning.
   */
  class RangeTracker {
    constructor(table, hand) { this.table = table; this.hand = hand; this.ranges = null; this.byStreet = {}; this.status = 'empty'; this.notes = []; this.conditionedStreets = []; }
    startPreflop(result) { this.ranges = result.ranges; this.status = result.status; if (result.reason) this.notes.push(result.reason); this.byStreet.preflop = snapshotOf(this.ranges); }
    /** Ranges of the given live seats at the start of `street`, with board removal applied. */
    streetStart(street, board, liveSeats) {
      const out = new Map(); for (const s of liveSeats) { const r = this.ranges && this.ranges.get(s) ? this.ranges.get(s).clone() : WeightedRange.unknown('No range tracked for seat ' + s); r.removeCards(board, 'board'); out.set(s, r); }
      this.byStreet[street] = snapshotOf(out); return out;
    }
    applyStreet(street, result, ranges) { if (result.status === 'ok') { this.conditionedStreets.push(street); for (const [s, r] of ranges) this.ranges.set(s, r); } else this.notes.push(street + ': ' + result.reason); }
    view(knownCards = [], board = []) {
      const out = {}; if (!this.ranges) return { table: this.table, hand: this.hand, status: this.status, seats: out, notes: this.notes };
      for (const [s, r] of this.ranges) { const v = r.clone(); v.removeCards(board.concat(knownCards), 'board and cards known to the viewer'); out[s] = { ...v.describe(), events: undefined, history: r.events, top: v.total() > 0 ? v.classSummary().sort((a, b) => b.share - a.share).slice(0, 25) : [] }; }
      return { table: this.table, hand: this.hand, status: this.status, conditionedStreets: this.conditionedStreets, byStreet: this.byStreet, seats: out, notes: this.notes };
    }
  }
  function snapshotOf(ranges) { const o = {}; for (const [s, r] of ranges) o[s] = { combos: r.combos(), provenance: r.provenance, invalid: r.invalid }; return o; }

  return { PROVENANCE, PROVENANCE_TEXT, C1, C2, IDX, CLASS, CLASS_NAMES, CLASS_COMBOS, cardId, cardStr, comboIndex, comboStr, classNameOf, WeightedRange, strategyLikelihood, rowMap, preflopRanges, conditionOnStreet, fromTendencies, strengthOrder, RangeTracker, worse };
});
