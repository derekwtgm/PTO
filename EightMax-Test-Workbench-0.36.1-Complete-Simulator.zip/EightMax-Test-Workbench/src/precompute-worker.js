'use strict';
/* 0.30: one training job in a worker thread, so the JavaScript part of a job (state import, snapshot export) runs in parallel
 * with other jobs instead of on the queue's thread. Messages: in {spot, options} / 'abort'; out {progress} / {ok, body, meta, training} / {error}. */
const { parentPort, workerData } = require('node:worker_threads');
const LS = require('./library-source.js');
const controller = new AbortController();
parentPort.on('message', (m) => { if (m === 'abort') controller.abort(); });
const o = workerData.options, run = o.adaptive
  ? require('./adaptive-training.js').trainAdaptive(workerData.spot, { ...o, signal: controller.signal, onProgress: (i) => parentPort.postMessage({ type: 'progress', done: Math.min(i.updates, o.maxUpdates || i.updates), total: o.maxUpdates || i.updates }) })   // 0.31 quality-targeted
  : LS.trainSpot(workerData.spot, { ...o, signal: controller.signal, onProgress: (d, t) => parentPort.postMessage({ type: 'progress', done: d, total: t }) });
run.then((r) => { const body = r.body, linked = r.linked || null; parentPort.postMessage({ type: 'done', ok: true, body, linked, meta: { playerNodes: r.meta.playerNodes, rows: r.meta.rows }, training: r.training, quality: r.quality || null }, linked ? [body.buffer, linked.buffer] : [body.buffer]); },
    (e) => parentPort.postMessage({ type: 'done', ok: false, code: e.code || 'failed', message: e.message }));
