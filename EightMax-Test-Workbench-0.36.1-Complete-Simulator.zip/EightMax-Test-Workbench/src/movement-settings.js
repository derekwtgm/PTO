/* Reproducible bounded left/right test curves. Requires the 0.36.1 native motion capability. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./input-motion.js'));else root.WorkbenchMovementSettings=factory(root.WorkbenchInputMotion);})(typeof globalThis!=='undefined'?globalThis:this,function(M){
 'use strict';
 const DEFAULTS=Object.freeze({pattern:'straight',variation:1,seed:1,direction:'left',minCurvature:null,maxCurvature:null});
 function validate(o={}) {
  const v={...DEFAULTS,...o};
  if(!['straight','fixed','random'].includes(v.pattern))throw Error('Unknown movement pattern');
  if(!Number.isFinite(v.variation)||v.variation<0||v.variation>1)throw Error('Curvature variation must be 0–1');
  if(!Number.isInteger(v.seed)||v.seed<1||v.seed>4294967295)throw Error('Random seed must be 1–4294967295');
  if(!['left','right'].includes(v.direction))throw Error('Curve direction must be left or right');
  for(const k of ['minCurvature','maxCurvature'])if(v[k]!==null&&(!Number.isFinite(v[k])||v[k]<0||v[k]>.25))throw Error(k+' must be 0–0.25');
  if(v.minCurvature!==null&&v.maxCurvature!==null&&v.minCurvature>v.maxCurvature)throw Error('Minimum curvature exceeds maximum');
  return {pattern:v.pattern,variation:v.variation,seed:v.seed,direction:v.direction,minCurvature:v.minCurvature,maxCurvature:v.maxCurvature};
 }
 class Sequence {
  constructor(options){this.options=validate(options);this.state=this.options.seed;this.index=0;}
  next(profile){
   const p=M.profile(profile),before=this.state,o=this.options;
   const max=o.maxCurvature===null?Math.abs(p.arc):o.maxCurvature,min=o.minCurvature===null?max*(1-o.variation):o.minCurvature;
   if(min>max)throw Error('Minimum curvature exceeds maximum');
   p.arc=(o.direction==='left'?1:-1)*max;
   if(o.pattern==='straight')p.arc=0;
   if(o.pattern==='random') {const draw=()=>{let x=this.state;x^=x<<13;x^=x>>>17;x^=x<<5;this.state=x>>>0;return this.state/4294967296;};const magnitude=min+(max-min)*draw();p.arc=(draw()<.5?-1:1)*magnitude;}
   return {profile:p,trace:{pattern:o.pattern,seed:o.seed,index:this.index++,stateBefore:before,stateAfter:this.state,arc:p.arc}};
  }
 }
 return {DEFAULTS,validate,Sequence};
});
