/* EightMax Test Workbench 0.33: EXACT full-width CFR+ for restricted HEADS-UP FLOP games (flop -> turn -> river).
 *
 * Game solved (identical to src/fast-multistreet.js, which is the INDEPENDENT evaluator of this solver's output):
 *   the heads-up postflop game of a study - starting flop, two weighted ranges (joint deal with card removal, weight = product of
 *   combo weights), the study's betting menus on every street, every turn and river card dealt uniformly from the cards not held by
 *   either player and not on the board, chip utility (chips won from the pot minus chips put in from the study root). An all-in before
 *   the river is a terminal valued by the exact average over every remaining runout. Nothing is sampled.
 *
 * Why a separate engine (0.32 measured ~45x a turn solve with src/fast-multistreet.js): this one keeps regrets and averages in flat
 * typed arrays per (decision node, public-card context) - contexts: flop 1, turn 52 slots, river 52 x 52 slots - instead of Maps,
 * accumulates the average strategy during the regret traversal (no second pass), precomputes each river board's showdown order once,
 * keeps exact runout-equity matrices for all-ins, and reuses value buffers (no per-call allocation in the hot path).
 *
 * Parallelism (deterministic): the TURN CARDS are partitioned over worker threads. Every value in the tree is linear in the chance
 * subtrees, so a flop decision's per-action values are the SUM of the workers' partial values; each worker returns its partial regret
 * INCREMENTS for flop nodes, the coordinator adds them in worker order and applies the RM+ floor once (exactly what a single thread
 * computes, up to floating-point summation order, which is fixed). Turn and river tables are owned by exactly one worker. Flop
 * terminals and the flop average strategy are handled by worker 0 only.
 *
 * Algorithm: two-player CFR+ (alternating updates, regret matching+, linear average weighting t), as in fast-multistreet.cfrPlus.
 * Exploitability is NOT computed here: callers evaluate the average strategy with src/fast-multistreet.js (independent code path:
 * its own traversal, own showdown, own best response) - see tools/flop-solver-benchmark-033.cjs and tests/flop-033.test.cjs.
 *
 * Exposed: createCore(game, spec, o), solve(game, spec, o) (single thread), solveParallel(config, o) (worker threads; async),
 *          checkpoint serialize/restore, strategy accessors usable by fast-multistreet.evaluate and linked-study.exportLinked. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./exploitability.js'), require('./fast-multistreet.js'));
  else root.WorkbenchFlopSolver = factory(root.WorkbenchExploitability, root.WorkbenchFastMultiStreet);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (X, MS) {
  'use strict';
  const ok = (x, m) => { if (!x) throw new Error(m); };
  const FORMAT = 'eightmax-flop-cfr-checkpoint', VERSION = 1;

  /** Builds the solver state for one game. o.ownTurn(card) -> bool selects the turn cards this core traverses (default: all);
   *  o.flopTerminals (default true) counts flop-street terminals; o.flopAverage (default true) accumulates flop averages. */
  function createCore(game, spec, o = {}) {
    const g = MS.buildTree(game, spec, { verifyCards: o.verifyCards === undefined ? 2 : o.verifyCards });
    ok(g.n === 2, 'The flop solver is heads-up only (' + g.n + ' players)');
    const board0 = g.board; ok(board0.length === 3, 'The flop solver needs a three-card starting board (use src/fast-multistreet.js for turns and rivers)');
    const H = [0, 1].map((p) => g.hands[p].filter((r) => !board0.includes(r[1]) && !board0.includes(r[2])).map((r) => ({ row: r, id: r[0], a: r[1], b: r[2], w: r[3] })));
    ok(H[0].length && H[1].length, 'A range is empty after removing the board cards');
    const N = [H[0].length, H[1].length];
    const ownTurn = o.ownTurn || (() => true), flopTerminals = o.flopTerminals !== false, flopAverage = o.flopAverage !== false;
    const key = (h) => Math.min(h.a, h.b) * 64 + Math.max(h.a, h.b);
    const same = [0, 1].map((p) => { const m = new Map(H[1 - p].map((h, i) => [key(h), i])); return Int32Array.from(H[p], (h) => (m.has(key(h)) ? m.get(key(h)) : -1)); });
    const holding = [0, 1].map((p) => { const L = Array.from({ length: 52 }, () => []); H[p].forEach((h, i) => { L[h.a].push(i); L[h.b].push(i); }); return L.map((x) => Int32Array.from(x)); });
    const HA = [0, 1].map((p) => Int32Array.from(H[p], (h) => h.a)), HB = [0, 1].map((p) => Int32Array.from(H[p], (h) => h.b));
    const turnCards = []; for (let c = 0; c < 52; c++) if (!board0.includes(c)) turnCards.push(c);

    // ---- nodes: decision tables per street context ----
    const nodes = [], dec = [];
    (function walk(x) { nodes[x.id] = x; if (x.kind === 'player') { dec.push(x); x.children.forEach(walk); } else if (x.kind === 'chance') walk(x.child); })(g.tree);
    const ctxCount = (street) => (street === 3 ? 1 : street === 4 ? 52 : 2704);
    let cells = 0; for (const d of dec) { d.width = N[d.seat] * d.k; d.cells = ctxCount(d.street) * d.width; d.base = cells; cells += d.cells; }
    // only the contexts this core owns are allocated: flop always; turn/river contexts lazily (subarrays of per-context blocks)
    const REG = new Map(), AVG = new Map();   // node id -> Float64Array(ctxCount * width), allocated on first use
    const table = (M, d) => { let a = M.get(d.id); if (!a) { a = new Float64Array(d.cells); M.set(d.id, a); } return a; };
    for (const d of dec) if (d.street === 3) { table(REG, d); table(AVG, d); }
    const ctxOf = (street, t, r) => (street === 3 ? 0 : street === 4 ? t : t * 52 + r);

    // ---- terminal utilities ----
    const util = new Map();
    function termUtil(node, p) {
      const k = node.id * 2 + p; let u = util.get(k); if (u) return u;
      if (node.live.filter(Boolean).length < 2) u = { fold: X.payoff(node, [0, 0], g.common)[p] };
      else { const sc = (mine, theirs) => (p === 0 ? [mine, theirs] : [theirs, mine]); u = { win: X.payoff(node, sc(2, 1), g.common)[p], lose: X.payoff(node, sc(1, 2), g.common)[p], tie: X.payoff(node, sc(1, 1), g.common)[p] }; }
      util.set(k, u); return u;
    }
    // ---- river showdown tables (built once per river board this core visits) ----
    // o.score7(cards) -> comparable integer; default: the engine's fast evaluator when available (tests check that it orders hands
    // exactly like exploitability.score7, which the independent evaluator uses), else exploitability.score7
    const score7 = o.score7 || defaultScorer();
    const river = new Map();
    function riverInfo(t, r) {
      const k = t * 52 + r; let b = river.get(k); if (b) return b;
      const full = board0.concat([t, r]);
      const sc = [0, 1].map((p) => Int32Array.from(H[p], (h) => (h.a === t || h.b === t || h.a === r || h.b === r ? -1 : score7([...full, h.a, h.b]))));
      const order = [0, 1].map((p) => Int32Array.from(H[p].map((_, i) => i).filter((i) => sc[p][i] >= 0).sort((x, y) => sc[p][x] - sc[p][y])));
      b = { sc, order }; river.set(k, b); return b;
    }
    const scratch = [0, 1].map((p) => ({ R: new Float64Array(52), Rb: new Float64Array(52), Ra: new Float64Array(52), comp: new Float64Array(N[p]), win: new Float64Array(N[p]), lose: new Float64Array(N[p]) }));
    function compInto(p, r, comp) {
      const q = 1 - p, R = scratch[p].R.fill(0); let total = 0; const A = HA[q], B = HB[q];
      for (let j = 0; j < N[q]; j++) { const x = r[j]; if (!x) continue; total += x; R[A[j]] += x; R[B[j]] += x; }
      const sm = same[p], a = HA[p], b = HB[p]; for (let i = 0; i < N[p]; i++) { const s = sm[i]; comp[i] = total - R[a[i]] - R[b[i]] + (s >= 0 ? r[s] : 0); }
      return comp;
    }
    function showdown(p, r, t, rc, out, dead, u) {
      const q = 1 - p, B = riverInfo(t, rc), comp = compInto(p, r, scratch[p].comp), win = scratch[p].win, lose = scratch[p].lose;
      const oo = B.order[q], mo = B.order[p], so = B.sc[q], sm = B.sc[p], OA = HA[q], OB = HB[q], MA = HA[p], MB = HB[p];
      let k = 0, below = 0; const Rb = scratch[p].Rb.fill(0);
      for (let x = 0; x < mo.length;) { const s0 = sm[mo[x]]; while (k < oo.length && so[oo[k]] < s0) { const j = oo[k], v = r[j]; if (v) { below += v; Rb[OA[j]] += v; Rb[OB[j]] += v; } k++; } let y = x; while (y < mo.length && sm[mo[y]] === s0) { const i = mo[y]; win[i] = below - Rb[MA[i]] - Rb[MB[i]]; y++; } x = y; }
      k = oo.length - 1; let above = 0; const Ra = scratch[p].Ra.fill(0);
      for (let x = mo.length - 1; x >= 0;) { const s0 = sm[mo[x]]; while (k >= 0 && so[oo[k]] > s0) { const j = oo[k], v = r[j]; if (v) { above += v; Ra[OA[j]] += v; Ra[OB[j]] += v; } k--; } let y = x; while (y >= 0 && sm[mo[y]] === s0) { const i = mo[y]; lose[i] = above - Ra[MA[i]] - Ra[MB[i]]; y--; } x = y; }
      for (let i = 0; i < N[p]; i++) { if (dead[i] || sm[i] < 0) { out[i] = 0; continue; } const tie = comp[i] - win[i] - lose[i]; out[i] = u.win * win[i] + u.lose * lose[i] + u.tie * tie; }
    }
    // ---- exact runout equity (player 0 vs player 1) for all-ins on the flop (all turn/river pairs) and on each turn (all rivers) ----
    const equity = new Map(); let equityBytes = 0;
    function equityOf(t) {   // t = -1: flop all-in
      let E = equity.get(t); if (E) return E;
      const n0 = N[0], n1 = N[1], W = new Float64Array(n0 * n1), T = new Float64Array(n0 * n1), L = new Float64Array(n0 * n1);
      const add = (tc, rc, w) => { const B = riverInfo(tc, rc), s0 = B.sc[0], s1 = B.sc[1]; for (let i = 0; i < n0; i++) { const a = s0[i]; if (a < 0) continue; const ai = HA[0][i], bi = HB[0][i], base = i * n1; for (let j = 0; j < n1; j++) { const b = s1[j]; if (b < 0) continue; const aj = HA[1][j], bj = HB[1][j]; if (aj === ai || aj === bi || bj === ai || bj === bi) continue; if (a > b) W[base + j] += w; else if (a === b) T[base + j] += w; else L[base + j] += w; } } };
      if (t < 0) { const w = 1 / (45 * 44); for (const tc of turnCards) for (let rc = 0; rc < 52; rc++) if (rc !== tc && !board0.includes(rc)) add(tc, rc, w); }
      else { const w = 1 / 44; for (let rc = 0; rc < 52; rc++) if (rc !== t && !board0.includes(rc)) add(t, rc, w); }
      E = { W, T, L }; equity.set(t, E); equityBytes += n0 * n1 * 24; return E;
    }
    function allIn(p, r, t, out, dead, u) {
      const E = equityOf(t), comp = compInto(p, r, scratch[p].comp), n1 = N[1], n0 = N[0], dw = u.win - u.lose, dt = u.tie - u.lose;
      if (p === 0) for (let i = 0; i < n0; i++) { if (dead[i]) { out[i] = 0; continue; } let sw = 0, st = 0; const base = i * n1; for (let j = 0; j < n1; j++) { const x = r[j]; if (x) { sw += x * E.W[base + j]; st += x * E.T[base + j]; } } out[i] = u.lose * comp[i] + dw * sw + dt * st; }
      else { const sw = scratch[1].win.fill(0), st = scratch[1].lose.fill(0); for (let j = 0; j < n0; j++) { const x = r[j]; if (!x) continue; const base = j * n1; for (let i = 0; i < n1; i++) { st[i] += x * E.T[base + i]; sw[i] += x * E.L[base + i]; } } for (let i = 0; i < n1; i++) out[i] = dead[i] ? 0 : u.lose * comp[i] + dw * sw[i] + dt * st[i]; }
    }
    // ---- buffer pool (vectors of length N[0] or N[1]) ----
    const pool = [[], []], take = (n) => { const l = n === N[0] ? pool[0] : pool[1]; return l.length ? l.pop().fill(0) : new Float64Array(n); }, give = (a) => { const l = a.length === N[0] ? pool[0] : pool[1]; if (l.length < 4096) l.push(a); };
    const deadPool = [[], []], takeDead = (p, src) => { const l = deadPool[p]; const d = l.length ? l.pop() : new Uint8Array(N[p]); d.set(src); return d; }, giveDead = (p, d) => deadPool[p].push(d);

    const flopInc = new Map();   // flop decision node id -> Float64Array(width): regret increments of the current pass
    let work = 0; const signal = o.signal || null;
    const tick = () => { if ((++work & 4095) === 0 && signal && signal.aborted) { const e = new Error('Solve cancelled'); e.code = 'cancelled'; throw e; } };
    /** One traversal for traverser p at iteration t (average weight t). Returns p's value vector at the root (partial when partitioned). */
    function pass(p, t) {
      const q = 1 - p; for (const d of dec) if (d.street === 3 && d.seat === p) { let a = flopInc.get(d.id); if (!a) { a = new Float64Array(d.width); flopInc.set(d.id, a); } else a.fill(0); }
      const cur = (d, ctx, seat, out) => {   // regret matching+ current strategy of seat at (d, ctx) into out (N[seat] * k)
        const R = table(REG, d), k = d.k, base = ctx * d.width; for (let i = 0; i < N[seat]; i++) { let s = 0; const o2 = base + i * k; for (let a = 0; a < k; a++) s += R[o2 + a]; if (s > 0) for (let a = 0; a < k; a++) out[i * k + a] = R[o2 + a] / s; else for (let a = 0; a < k; a++) out[i * k + a] = 1 / k; }
        return out; };
      const curBuf = new Map(), curOf = (d, depth) => { const k2 = depth * 8 + d.k; let b = curBuf.get(k2); const need = N[d.seat] * d.k; if (!b || b.length < need) { b = new Float64Array(need); curBuf.set(k2, b); } return b; };
      const rec = (node, r, t1, r1, dead, depth) => {
        tick(); const n = N[p], out = take(n);
        if (node.kind === 'terminal') {
          if (node.street === 3 && !flopTerminals) return out;
          const u = termUtil(node, p);
          if (u.fold !== undefined) { const comp = compInto(p, r, scratch[p].comp); for (let i = 0; i < n; i++) out[i] = dead[i] ? 0 : u.fold * comp[i]; return out; }
          if (node.street === 5) { showdown(p, r, t1, r1, out, dead, u); return out; }
          allIn(p, r, node.street === 3 ? -1 : t1, out, dead, u); return out;
        }
        if (node.kind === 'chance') {
          const cw = 1 / (48 - node.street);
          for (let c = 0; c < 52; c++) {
            if (board0.includes(c) || c === t1) continue;
            if (node.street === 3 && !ownTurn(c)) continue;
            const r2 = take(r.length); r2.set(r); for (const j of holding[q][c]) r2[j] = 0;
            const d2 = takeDead(p, dead); for (const i of holding[p][c]) d2[i] = 1;
            const v = node.street === 3 ? rec(node.child, r2, c, -1, d2, depth + 1) : rec(node.child, r2, t1, c, d2, depth + 1);
            for (let i = 0; i < n; i++) out[i] += cw * v[i]; give(v); give(r2); giveDead(p, d2);
          }
          return out;
        }
        const d = node, k = d.k, ctx = ctxOf(d.street, t1, r1);
        if (d.seat === p) {
          const s = cur(d, ctx, p, curOf(d, depth)), vals = new Array(k);
          for (let a = 0; a < k; a++) { const v = rec(d.children[a], r, t1, r1, dead, depth + 1); vals[a] = v; for (let i = 0; i < n; i++) out[i] += s[i * k + a] * v[i]; }
          if (d.street === 3) { const inc = flopInc.get(d.id); for (let i = 0; i < n; i++) { if (dead[i]) continue; for (let a = 0; a < k; a++) inc[i * k + a] += vals[a][i] - out[i]; } }
          else { const R = table(REG, d), base = ctx * d.width; for (let i = 0; i < n; i++) { if (dead[i]) continue; const o2 = base + i * k; for (let a = 0; a < k; a++) { const x = R[o2 + a] + vals[a][i] - out[i]; R[o2 + a] = x > 0 ? x : 0; } } }
          for (const v of vals) give(v); return out;
        }
        const s = cur(d, ctx, q, curOf(d, depth)), nq = N[q];
        if (d.street > 3 || flopAverage) { const A = table(AVG, d), base = ctx * d.width; for (let j = 0; j < nq; j++) { const x = r[j]; if (!x) continue; const o2 = base + j * k; for (let a = 0; a < k; a++) A[o2 + a] += t * x * s[j * k + a]; } }
        for (let a = 0; a < k; a++) {
          const r2 = take(nq); let any = false; for (let j = 0; j < nq; j++) { const x = r[j] * s[j * k + a]; r2[j] = x; if (x) any = true; }
          if (any) { const v = rec(d.children[a], r2, t1, r1, dead, depth + 1); for (let i = 0; i < n; i++) out[i] += v[i]; give(v); }
          give(r2);
        }
        return out;
      };
      const r0 = Float64Array.from(H[q], (h) => h.w), v = rec(g.tree, r0, -1, -1, new Uint8Array(N[p]), 0);
      return v;
    }
    /** Applies summed flop increments (RM+ floor once). incs: Map node id -> Float64Array (already summed over partitions). */
    function applyFlop(p, incs) { for (const d of dec) { if (d.street !== 3 || d.seat !== p) continue; const R = table(REG, d), inc = incs.get(d.id); for (let x = 0; x < d.width; x++) { const y = R[x] + inc[x]; R[x] = y > 0 ? y : 0; } } }
    const flopNodes = dec.filter((d) => d.street === 3);
    function getFlopRegrets() { return flopNodes.map((d) => table(REG, d)); }
    function setFlopRegrets(list) { flopNodes.forEach((d, i) => table(REG, d).set(list[i])); }

    /** Normalised average strategy (or the current RM+ strategy when the information set has no average weight). */
    function averageRow(d, ctx, i) {
      const k = d.k, A = AVG.get(d.id), R = REG.get(d.id), base = ctx * d.width + i * k, out = new Float64Array(k);
      let s = 0; if (A) for (let a = 0; a < k; a++) s += A[base + a];
      if (s > 0) { for (let a = 0; a < k; a++) out[a] = A[base + a] / s; return out; }
      let t = 0; if (R) for (let a = 0; a < k; a++) t += R[base + a]; for (let a = 0; a < k; a++) out[a] = t > 0 ? R[base + a] / t : 1 / k; return out;
    }
    const byPath = new Map(dec.map((d) => [d.path, d])), idx = [0, 1].map((p) => new Map(H[p].map((h, i) => [h.id, i])));
    const ctxFromBoard = (board) => { const t = board.length > 3 ? board[3] : -1, r = board.length > 4 ? board[4] : -1; return { t, r }; };
    /** Strategy object for fast-multistreet.evaluate (rows(node, seat, board)) and linked-study export (averageAt). */
    function strategy() {
      return {
        rows(node, seat, board) { const d = nodes[node.id], { t, r } = ctxFromBoard(board), ctx = ctxOf(d.street, t, r), out = new Array(N[seat]); for (let i = 0; i < N[seat]; i++) out[i] = averageRow(d, ctx, i); return out; },
        get(node, seat, i, board) { const d = nodes[node.id], { t, r } = ctxFromBoard(board); return averageRow(d, ctxOf(d.street, t, r), i); },
        averageAt(path, board, seat, hand) { const d = byPath.get(path); if (!d) return null; const i = idx[seat].get(hand.id); if (i === undefined) return null; if (board.includes(hand.a) || board.includes(hand.b)) return null; const { t, r } = ctxFromBoard(board); return averageRow(d, ctxOf(d.street, t, r), i); } };
    }
    function estimateBytes() { let c = 0; for (const d of dec) c += (d.street === 3 ? 1 : d.street === 4 ? 49 : 49 * 48) * d.width; return { cells: c, bytes: c * 16, allocatedUpperBound: cells * 16 }; }
    /** Tables this core owns (for checkpoints and for gathering partitions): [[nodeId, ctx, reg slice, avg slice], ...] compacted to used contexts. */
    function exportTables() {
      const parts = []; for (const d of dec) { const R = REG.get(d.id), A = AVG.get(d.id); if (!R && !A) continue; const nctx = ctxCount(d.street);
        for (let c = 0; c < nctx; c++) { const b = c * d.width; let used = false; for (let x = 0; x < d.width && !used; x++) if ((R && R[b + x]) || (A && A[b + x])) used = true; if (used) parts.push([d.id, c, R ? R.slice(b, b + d.width) : new Float64Array(d.width), A ? A.slice(b, b + d.width) : new Float64Array(d.width)]); } }
      return parts; }
    function importTables(parts, which = 'both') { for (const [id, c, Rs, As] of parts) { const d = nodes[id]; if (which !== 'avg') table(REG, d).set(Rs, c * d.width); if (which !== 'reg') table(AVG, d).set(As, c * d.width); } }
    function allocatedBytes() { let b = 0; for (const a of REG.values()) b += a.byteLength; for (const a of AVG.values()) b += a.byteLength; return b + equityBytes; }
    return { tree: g, hands: H, nodes, dec, flopNodes, pass, applyFlop, flopInc, getFlopRegrets, setFlopRegrets, strategy, estimateBytes, exportTables, importTables, allocatedBytes, turnCards, board0 };
  }

  function defaultScorer() { try { if (typeof require === 'function') { const EM = require('../tests/load-solver.cjs'); if (EM && typeof EM.evalCards === 'function') return (c) => EM.evalCards(c); } } catch (e) { /* browser or missing engine */ } return X.score7; }
  // ---- checkpoints: deterministic binary (header JSON + tables), SHA-256 over everything ----
  function serialize(core, meta) {
    const crypto = require('node:crypto'), parts = core.exportTables();
    const head = Buffer.from(JSON.stringify({ format: FORMAT, version: VERSION, ...meta, parts: parts.map((x) => [x[0], x[1], x[2].length]) }), 'utf8');
    const bufs = [Buffer.alloc(4), head]; bufs[0].writeUInt32LE(head.length, 0);
    for (const [, , R, A] of parts) { bufs.push(Buffer.from(R.buffer, R.byteOffset, R.byteLength), Buffer.from(A.buffer, A.byteOffset, A.byteLength)); }
    const body = Buffer.concat(bufs), digest = crypto.createHash('sha256').update(body).digest();
    return Buffer.concat([Buffer.from('EMFC', 'latin1'), digest, body]);
  }
  function deserialize(buf) {
    const crypto = require('node:crypto'); ok(buf.length > 40 && buf.toString('latin1', 0, 4) === 'EMFC', 'Not a flop-solver checkpoint');
    const body = buf.subarray(36); ok(crypto.createHash('sha256').update(body).digest().equals(buf.subarray(4, 36)), 'Flop checkpoint checksum mismatch (corrupt or truncated)');
    const hl = body.readUInt32LE(0), meta = JSON.parse(body.subarray(4, 4 + hl).toString('utf8')); ok(meta.format === FORMAT && meta.version === VERSION, 'Unsupported flop checkpoint version');
    let p = 4 + hl; const parts = meta.parts.map(([id, c, w]) => { const R = new Float64Array(w), A = new Float64Array(w); Buffer.from(R.buffer).set(body.subarray(p, p + w * 8)); p += w * 8; Buffer.from(A.buffer).set(body.subarray(p, p + w * 8)); p += w * 8; return [id, c, R, A]; });
    ok(p === body.length, 'Flop checkpoint has trailing data'); return { meta, parts };
  }
  const gameDigest = (spec) => require('node:crypto').createHash('sha256').update(JSON.stringify({ board: spec.board, hands: spec.hands, rules: spec.rules || null, nodes: spec.nodes ? spec.nodes.length : null, studyId: spec.studyId || null })).digest('hex');

  /** Single-thread solve. o: iterations, every (evaluate every N iterations), target (exploitability in chips), deadline (ms epoch),
   *  maxBytes (refused up front), signal, onCheckpoint(t, evaluation), resume (checkpoint Buffer), evaluate (default true). */
  function solve(game, spec, o = {}) {
    const core = createCore(game, spec, { signal: o.signal }), est = core.estimateBytes();
    if (o.maxBytes && est.bytes > o.maxBytes) { const e = new Error('Flop solve needs about ' + Math.round(est.bytes / 1048576) + ' MiB, above the ' + Math.round(o.maxBytes / 1048576) + ' MiB limit'); e.code = 'memory-limit'; throw e; }
    const digest = gameDigest(spec); let start = 0;
    if (o.resume) { const c = deserialize(o.resume); ok(c.meta.gameDigest === digest, 'Checkpoint belongs to a different game'); core.importTables(c.parts); start = c.meta.iterations; }
    const evaluator = o.evaluate === false ? null : MS.prepare(game, spec, o.evalOptions || {});
    const curve = [], t0 = Date.now(); let done = start, stopped = 'complete', last = null;
    for (let t = start + 1; t <= (o.iterations || 1000); t++) {
      if (o.signal && o.signal.aborted) { stopped = 'cancelled'; break; }
      if (o.deadline && Date.now() > o.deadline && done > start) { stopped = 'time-limit'; break; }
      for (let p = 0; p < 2; p++) { core.pass(p, t); core.applyFlop(p, core.flopInc); }
      done = t;
      if (evaluator && o.every && (t % o.every === 0 || t === o.iterations)) { last = evaluator.evaluate(core.strategy()); curve.push({ iterations: t, exploitability: last.exploitability, pctPot: last.exploitabilityPctPot, ms: Date.now() - t0 }); if (o.onCheckpoint) o.onCheckpoint(t, last, () => serialize(core, { iterations: t, gameDigest: digest })); if (o.target !== undefined && last.exploitability <= o.target) { stopped = 'target-reached'; break; } }
    }
    const final = evaluator ? (last && curve.length && curve[curve.length - 1].iterations === done ? last : evaluator.evaluate(core.strategy())) : null;
    return { ...(final || {}), iterations: done, stopped, curve, solveMs: Date.now() - t0, estimate: est, allocatedBytes: core.allocatedBytes(), strategy: core.strategy(), core, checkpoint: () => serialize(core, { iterations: done, gameDigest: digest }),
      method: 'flop-solver 0.33: full-width CFR+ (alternating, RM+, linear averaging), exact chance enumeration; evaluated by src/fast-multistreet.js' };
  }

  /** Worker-thread solve over a study CONFIG (each worker rebuilds the identical game). o.threads (default min(4, cores)). Async.
   *  Deterministic for a fixed thread count; results across thread counts differ only by floating-point summation order. */
  async function solveParallel(config, o = {}) {
    const { Worker } = require('node:worker_threads'), path = require('node:path'), os = require('node:os');
    const W = Math.max(1, Math.min(o.threads || Math.min(4, os.cpus().length), 49));
    const A = require('./study-adapter.js'), EM = require('../tests/load-solver.cjs'), prep = A.prepare(EM, { config, iterations: 1 });
    const main = createCore(prep.game, prep.spec, { flopTerminals: false, flopAverage: false, ownTurn: () => false }), est = main.estimateBytes();
    if (o.maxBytes && est.bytes > o.maxBytes) { const e = new Error('Flop solve needs about ' + Math.round(est.bytes / 1048576) + ' MiB, above the ' + Math.round(o.maxBytes / 1048576) + ' MiB limit'); e.code = 'memory-limit'; throw e; }
    const workers = Array.from({ length: W }, (_, w) => new Worker(path.join(__dirname, 'flop-solver-worker.js'), { workerData: { config, w, W } }));
    const pending = new Map(); let seq = 0;
    for (const wk of workers) { wk.on('message', (m) => { const f = pending.get(m.seq); if (f) { pending.delete(m.seq); m.error ? f.reject(new Error(m.error)) : f.resolve(m); } }); wk.on('error', (e) => { for (const f of pending.values()) f.reject(e); pending.clear(); }); }
    const call = (wk, msg) => new Promise((resolve, reject) => { const s = ++seq; pending.set(s, { resolve, reject }); wk.postMessage({ ...msg, seq: s }); });
    const evaluator = o.evaluate === false ? null : MS.prepare(prep.game, prep.spec, o.evalOptions || {});
    const gather = async () => { const all = await Promise.all(workers.map((wk) => call(wk, { cmd: 'export' }))); const g2 = createCore(prep.game, prep.spec); for (const m of all) g2.importTables(m.parts); g2.setFlopRegrets(main.getFlopRegrets()); return g2; };
    const curve = [], t0 = Date.now(); let done = 0, stopped = 'complete', last = null, gathered = null;
    try {
      if (o.resume) { const c = deserialize(o.resume); ok(c.meta.gameDigest === gameDigest(prep.spec), 'Checkpoint belongs to a different game'); main.importTables(c.parts.filter(([id]) => main.nodes[id].street === 3), 'reg'); await Promise.all(workers.map((wk) => call(wk, { cmd: 'import', parts: c.parts }))); done = c.meta.iterations; }
      for (let t = done + 1; t <= (o.iterations || 1000); t++) {
        if (o.signal && o.signal.aborted) { stopped = 'cancelled'; break; }
        if (o.deadline && Date.now() > o.deadline && done > 0) { stopped = 'time-limit'; break; }
        for (let p = 0; p < 2; p++) {
          const flop = main.getFlopRegrets(), res = await Promise.all(workers.map((wk) => call(wk, { cmd: 'pass', p, t, flop })));
          const incs = new Map(); for (const m of res) for (const [id, arr] of m.incs) { const a = incs.get(id); if (!a) incs.set(id, Float64Array.from(arr)); else for (let x = 0; x < a.length; x++) a[x] += arr[x]; }
          main.applyFlop(p, incs);
        }
        done = t;
        if (evaluator && o.every && (t % o.every === 0 || t === o.iterations)) { gathered = await gather(); last = evaluator.evaluate(gathered.strategy()); curve.push({ iterations: t, exploitability: last.exploitability, pctPot: last.exploitabilityPctPot, ms: Date.now() - t0 }); if (o.onCheckpoint) { const gg = gathered; o.onCheckpoint(t, last, () => serialize(gg, { iterations: t, gameDigest: gameDigest(prep.spec) })); } if (o.target !== undefined && last.exploitability <= o.target) { stopped = 'target-reached'; break; } }
      }
      if (!gathered || !curve.length || curve[curve.length - 1].iterations !== done) gathered = await gather();
      const final = evaluator ? (last && curve.length && curve[curve.length - 1].iterations === done ? last : evaluator.evaluate(gathered.strategy())) : null;
      const g3 = gathered, digest = gameDigest(prep.spec);
      return { ...(final || {}), iterations: done, stopped, curve, solveMs: Date.now() - t0, threads: W, estimate: est, strategy: g3.strategy(), core: g3, prepared: prep, checkpoint: () => serialize(g3, { iterations: done, gameDigest: digest }),
        method: 'flop-solver 0.33: full-width CFR+ (alternating, RM+, linear averaging), exact chance enumeration, turn cards partitioned over ' + W + ' worker thread(s); evaluated by src/fast-multistreet.js' };
    } finally { await Promise.all(workers.map((wk) => wk.terminate())); }
  }
  return { createCore, solve, solveParallel, serialize, deserialize, gameDigest, FORMAT, VERSION };
});
