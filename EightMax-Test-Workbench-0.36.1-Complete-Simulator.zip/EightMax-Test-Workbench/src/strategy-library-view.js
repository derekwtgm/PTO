/* EightMax Test Workbench 0.30: plain-language view of the strategy library status (pure; used by the dashboard and the tests). */
(function (root, factory) { if (typeof module === 'object' && module.exports) module.exports = factory(); else root.WorkbenchLibraryView = factory(); })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const esc = (s) => String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const mb = (b) => (b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.round((b || 0) / 1024) + ' KB');
  const MISSING_TEXT = 'No trained strategy is available for this situation. Add it to the training queue (Precompute Strategies trains the situations your simulations needed most).';
  const CODE_TEXT = {
    'library-miss': MISSING_TEXT,
    'hand-not-in-range': 'The stored strategy does not include this hand (it is outside the range the study assumed).',
    'off-tree-wager': 'A bet on this street has a size the trained action tree does not contain, so no strategy applies.',
    'no-stored-row': 'The study never reached this hand at this point during training; more training is needed.',
    'player-count-unsupported': 'Too many players are still in the hand for the studies in this release (postflop: at most 6).',
    'stakes-or-stack-mismatch': 'The stacks or blinds are outside what the studies cover.',
    'state-mismatch': 'The table does not match the trained situation exactly (pot or stacks differ), so the strategy is not used.',
    'street-not-covered': 'No study covers this betting round.',
    'invalid-observation': 'The table reading is incomplete, so no decision is made.',
    'checksum': 'A stored strategy file is damaged and was refused. Run Verify Strategies.',
    'engine-mismatch': 'A stored strategy was trained by a different engine build and was refused.',
    'identity-mismatch': 'A stored strategy does not match this situation exactly and was refused.',
  };
  function explain(code) { return CODE_TEXT[code] || 'No strategy is available for this situation (' + code + ').'; }
  /** Short provenance suffix for a decision line: where the strategy came from, cache, latency, accuracy status. */
  function decisionProvenance(d) {
    if (!d) return '';
    const parts = [];
    if (d.strategySource) parts.push('source: ' + ({ 'library-memory': 'strategy library (memory)', 'library-disk': 'strategy library (loaded from disk)', 'library-shared': 'strategy library (shared memory)', 'trained-now': 'trained just now (Study Mode)' }[d.strategySource] || d.strategySource));
    if (d.cache) parts.push('cache ' + d.cache);
    if (d.timings && Number.isFinite(d.timings.totalMs)) parts.push('lookup ' + d.timings.totalMs.toFixed(1) + ' ms');
    if (d.isomorphism) parts.push('suit-relabelled (exact)');
    parts.push('accuracy: ' + (d.convergence && d.convergence.verdict === 'within-target' ? 'measured within target' : 'not proven (completed training is not proof of GTO)'));
    return ' · ' + esc(parts.join(' · '));
  }
  /** Turn a status.json (tools/strategy-library.cjs) into dashboard fields. */
  function view(st) {
    if (!st || st.available === false) return { available: false, headline: 'No strategy library yet', detail: (st && st.message) || 'Run Record Situations, then Precompute Strategies.', rows: [] };
    const pc = st.precompute || null, c = pc ? pc.counts : null, run = pc && pc.running ? pc.running : [];
    const rows = [
      ['Available strategies', String(st.records)],
      ['By betting round', ['flop', 'turn', 'river'].map((k) => k + ' ' + ((st.byStreet || {})[k] || 0)).join(' · ')],
      ['Heads-up / multiway', Object.entries(st.byPlayers || {}).map(([k, v]) => k + ' ' + v).join(' · ') || '—'],
      ['Stack depth', Object.entries(st.byStackCategory || {}).map(([k, v]) => k + ' ' + v).join(' · ') || '—'],
      ['Accuracy status', Object.entries(st.byConvergence || {}).map(([k, v]) => (k === 'unproven' ? 'not proven' : k) + ' ' + v).join(' · ') + ' (training completed; not GTO-certified)'],
      ['Quality-gate status (0.31)', st.byQuality ? Object.entries(st.byQuality).map(([k, v]) => k + ' ' + v).join(' · ') + ' (see Strategy quality)' : 'not recorded'],
      ['Opponent range models', st.byRangeModel ? Object.entries(st.byRangeModel).map(([k, v]) => k.replace(/\[.*$/, '') + ' ' + v).join(' · ') : '—'],
      ['Storage on disk', mb(st.storageBytes) + ' (' + mb(st.rawBytes) + ' uncompressed)'],
      ['Situations waiting for training', String(st.pendingMisses || 0)],
      ['Training queue', c ? 'queued ' + c.queued + ' · running ' + (run.length) + ' · done ' + c.complete + ' · failed ' + c.failed + ' · memory-limited ' + c['memory-limited'] + ' · cancelled ' + c.cancelled : 'not started'],
      ['Training progress', run.length ? run.map((j) => j.street + ' ' + j.players + 'p ' + Math.round((j.progress || 0) * 100) + '%').join(' · ') : (pc && pc.paused ? 'paused' : 'idle')],
      ['Memory plan', st.resources ? 'cache ' + st.resources.cacheMiB + ' MiB · ' + st.resources.trainingJobs + ' training job(s) · ' + st.resources.freeMiB + ' MiB free' : (st.cache ? 'cache budget ' + mb(st.cache.budgetBytes) : '—')],
      ['Last verification', st.lastVerify ? st.lastVerify.ok + ' of ' + st.lastVerify.checked + ' records intact' + (st.lastVerify.damaged.length ? ' · ' + st.lastVerify.damaged.length + ' DAMAGED (refused)' : '') : 'not run yet'],
      ['Last updated', st.writtenAt ? new Date(st.writtenAt).toLocaleString() : '—'],
    ];
    const warn = st.lastVerify && st.lastVerify.damaged.length ? 'Some stored strategies are damaged; they are never used. Re-train them with Precompute Strategies.' : null;
    return { available: true, headline: st.records + ' stored strategies', detail: 'Folder: ' + st.dir, rows, warning: warn };
  }
  return { view, explain, decisionProvenance, MISSING_TEXT, esc };
});
