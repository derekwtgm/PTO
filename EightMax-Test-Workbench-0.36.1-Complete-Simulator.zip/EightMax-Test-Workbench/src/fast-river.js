/* EightMax Test Workbench 0.31: vectorised EXACT evaluation and CFR+ for heads-up single-street (river) games.
 *
 * Same game, same definitions and same independence as src/exploitability.js (own hand evaluator, own payouts from the tree
 * geometry, own best response). The difference is the algorithm: instead of enumerating every joint deal (about 1.07 million
 * for two any-two-cards ranges) it works on per-hand vectors. At a showdown the opponent mass that a hand beats, loses to
 * and ties with is computed from opponent hands sorted by strength, with card-removal handled exactly by inclusion-exclusion:
 *   compatible(h) = total - R[c1] - R[c2] + r[h]    (R[c] = opponent mass holding card c; r[h] = the identical combo)
 * so every quantity is exactly the joint-deal sum of exploitability.js (tests/fast-river-031 checks equality to 1e-9).
 *
 * Exposed: prepare(game, spec) -> { evaluate(S), exact(), cfrPlus(iterations, o) }, plus exact(game, spec) for convenience.
 * Two players only. Multiway games use exploitability.js (NashConv by joint deals).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./exploitability.js'));
  else root.WorkbenchFastRiver = factory(root.WorkbenchExploitability);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (X) {
  'use strict';
  const ok = (x, m) => { if (!x) throw new Error(m); };

  function prepare(game, spec) {
    const g = X.buildTree(game, spec); ok(g.n === 2, 'Vectorised evaluation is heads-up only (' + g.n + ' players)');
    const boardIds = Array.isArray(g.board) ? g.board.slice() : (String(g.board).match(/../g) || []).map(X.parse);
    const H = [0, 1].map((p) => g.hands[p].filter((r) => !boardIds.includes(r[1]) && !boardIds.includes(r[2])).map((r) => ({ row: r, a: r[1], b: r[2], w: r[3], score: X.score7([...boardIds, r[1], r[2]]) })));
    // index of the identical combo in the other player's list (or -1), for the +r[h] term of inclusion-exclusion
    const comboKey = (h) => Math.min(h.a, h.b) * 64 + Math.max(h.a, h.b);
    const same = [0, 1].map((p) => { const m = new Map(H[1 - p].map((h, i) => [comboKey(h), i])); return H[p].map((h) => (m.has(comboKey(h)) ? m.get(comboKey(h)) : -1)); });
    // strength order of the opponent list and own list
    const order = [0, 1].map((p) => H[p].map((_, i) => i).sort((x, y) => H[p][x].score - H[p][y].score));

    /** For own player p and opponent reach r (length H[1-p]): per own hand {comp, win, lose} masses. */
    function masses(p, r) {
      const O = H[1 - p], M = H[p], n = M.length, comp = new Float64Array(n), win = new Float64Array(n), lose = new Float64Array(n);
      let total = 0; const R = new Float64Array(52); for (let j = 0; j < O.length; j++) { const x = r[j]; if (!x) continue; total += x; R[O[j].a] += x; R[O[j].b] += x; }
      for (let i = 0; i < n; i++) { const h = M[i], s = same[p][i]; comp[i] = total - R[h.a] - R[h.b] + (s >= 0 ? r[s] : 0); }
      // weaker opponent mass: sweep both lists by score
      const oo = order[1 - p], mo = order[p]; let k = 0, below = 0; const Rb = new Float64Array(52);
      for (let t = 0; t < n;) {
        const sc = M[mo[t]].score;
        while (k < oo.length && O[oo[k]].score < sc) { const j = oo[k], x = r[j]; if (x) { below += x; Rb[O[j].a] += x; Rb[O[j].b] += x; } k++; }
        let t2 = t; while (t2 < n && M[mo[t2]].score === sc) { const i = mo[t2], h = M[i]; win[i] = below - Rb[h.a] - Rb[h.b]; t2++; }   // identical combo has equal score: never in "below"
        t = t2;
      }
      // stronger opponent mass: sweep from the top
      k = oo.length - 1; let above = 0; const Ra = new Float64Array(52);
      for (let t = n - 1; t >= 0;) {
        const sc = M[mo[t]].score;
        while (k >= 0 && O[oo[k]].score > sc) { const j = oo[k], x = r[j]; if (x) { above += x; Ra[O[j].a] += x; Ra[O[j].b] += x; } k--; }
        let t2 = t; while (t2 >= 0 && M[mo[t2]].score === sc) { const i = mo[t2], h = M[i]; lose[i] = above - Ra[h.a] - Ra[h.b]; t2--; }
        t = t2;
      }
      return { comp, win, lose };
    }
    // terminal utilities for player p: fold terminals are constant; showdowns depend on win / lose / tie only
    const util = new Map();
    function termUtil(node, p) {
      const key = node.path + '|' + p; let u = util.get(key); if (u) return u;
      const live = node.live.filter(Boolean).length;
      if (live < 2) u = { fold: X.payoff(node, [0, 0], g.common)[p] };
      else { const sc = (mine, theirs) => (p === 0 ? [mine, theirs] : [theirs, mine]); u = { win: X.payoff(node, sc(2, 1), g.common)[p], lose: X.payoff(node, sc(1, 2), g.common)[p], tie: X.payoff(node, sc(1, 1), g.common)[p] }; }
      util.set(key, u); return u;
    }
    /** Counterfactual value vector of player p's hands at a terminal given opponent reach r (chance weights included in r). */
    function termValues(node, p, r) {
      const u = termUtil(node, p), m = masses(p, r), n = H[p].length, out = new Float64Array(n);
      if (u.fold !== undefined) for (let i = 0; i < n; i++) out[i] = u.fold * m.comp[i];
      else for (let i = 0; i < n; i++) { const tie = m.comp[i] - m.win[i] - m.lose[i]; out[i] = u.win * m.win[i] + u.lose * m.lose[i] + u.tie * tie; }
      return out;
    }
    // normaliser: total joint weight of compatible deals
    const wsum = (() => { const m = masses(0, H[1].map((h) => h.w)); let s = 0; for (let i = 0; i < H[0].length; i++) s += H[0][i].w * m.comp[i]; return s; })();
    ok(wsum > 0, 'No compatible deals: ranges are empty after card removal');

    /** Strategy matrix of seat at node: Float64Array[k] per hand. S.get(node, seat, i) like exploitability.js. */
    function rowsAt(S, node, seat) { const out = new Array(H[seat].length); for (let i = 0; i < out.length; i++) out[i] = S.get(node, seat, i); return out; }
    /** Value vector for player p (per own hand, chance-weighted by the opponent only) under strategy S; br=true: p best-responds. */
    function walk(node, p, r, S, br) {
      if (node.kind === 'terminal') return termValues(node, p, r);
      const n = H[p].length;
      if (node.seat === p) {
        const rows = br ? null : rowsAt(S, node, p), out = new Float64Array(n); if (br) out.fill(-Infinity);
        for (let a = 0; a < node.k; a++) { const v = walk(node.children[a], p, r, S, br); for (let i = 0; i < n; i++) { if (br) { if (v[i] > out[i]) out[i] = v[i]; } else out[i] += rows[i][a] * v[i]; } }
        return out;
      }
      const o = 1 - p, rows = rowsAt(S, node, o), out = new Float64Array(n);
      for (let a = 0; a < node.k; a++) { const r2 = new Float64Array(r.length); let any = false; for (let j = 0; j < r.length; j++) { r2[j] = r[j] * rows[j][a]; if (r2[j]) any = true; } if (!any) continue; const v = walk(node.children[a], p, r2, S, br); for (let i = 0; i < n; i++) out[i] += v[i]; }
      return out;
    }
    function evaluate(S) {
      const values = [0, 0], brs = [0, 0];
      for (let p = 0; p < 2; p++) {
        const r = Float64Array.from(H[1 - p], (h) => h.w), v = walk(g.tree, p, r, S, false), b = walk(g.tree, p, r, S, true);
        for (let i = 0; i < H[p].length; i++) { values[p] += H[p][i].w * v[i] / wsum; brs[p] += H[p][i].w * b[i] / wsum; }
      }
      const gains = brs.map((b, p) => b - values[p]), nashConv = gains[0] + gains[1];
      return { players: 2, values, bestResponses: brs, gains, nashConv, exploitability: nashConv / 2, exploitabilityPctPot: nashConv / 2 / g.common * 100, commonPot: g.common, constantSum: +(values[0] + values[1]).toFixed(9), method: 'vectorised exact (sorted showdown, inclusion-exclusion card removal)' };
    }
    /** Strategy accessor over a game-like object (trained game or snapshot): missing rows uniform, counted. */
    function strategyOf(gameLike) {
      const cache = new Map(), missing = new Set();
      return { missing, get(node, seat, i) { const key = node.path + '|' + seat + '|' + i; let s = cache.get(key); if (s) return s; const r = H[seat][i].row; s = gameLike.averageAt(node.path, g.board, seat, { id: r[0], a: r[1], b: r[2], w: r[3] }); if (!s) { missing.add(key); s = new Float64Array(node.k).fill(1 / node.k); } else s = Float64Array.from(s); cache.set(key, s); return s; } };
    }
    function exact(gameLike) { const S = strategyOf(gameLike || game), t0 = Date.now(); const r = evaluate(S); return { ...r, treeNodes: g.nodes, hands: [H[0].length, H[1].length], missingRows: S.missing.size, evalMs: Date.now() - t0 }; }

    /** Full-width two-player CFR+ (alternating, regret matching+, linear averaging) on per-hand vectors. o.onCheckpoint(t, evaluation) every o.every iterations. */
    function cfrPlus(iterations, o = {}) {
      const reg = new Map(), avg = new Map();
      const slot = (m, node, p) => { let a = m.get(node.path); if (!a) { a = Array.from({ length: H[p].length }, () => new Float64Array(node.k)); m.set(node.path, a); } return a; };
      const current = (node, p) => { const R = slot(reg, node, p); return R.map((r) => { let s = 0; for (const x of r) s += x; const out = new Float64Array(node.k); for (let a = 0; a < node.k; a++) out[a] = s > 0 ? r[a] / s : 1 / node.k; return out; }); };
      const curMemo = new Map(), curOf = (node, seat) => { let c = curMemo.get(node.path); if (!c) { c = current(node, seat); curMemo.set(node.path, c); } return c; };
      const Savg = { get(node, seat, i) { const A = avg.get(node.path); if (!A) return new Float64Array(node.k).fill(1 / node.k); const r = A[i]; let s = 0; for (const x of r) s += x; return r.map((x) => (s > 0 ? x / s : 1 / node.k)); } };
      const curve = [];
      for (let t = 1; t <= iterations; t++) {
        for (let p = 0; p < 2; p++) {
          curMemo.clear();
          const upd = (node, r) => {
            if (node.kind === 'terminal') return termValues(node, p, r);
            const n = H[p].length;
            if (node.seat === p) {
              const cur = curOf(node, p), vals = [], out = new Float64Array(n);
              for (let a = 0; a < node.k; a++) { const v = upd(node.children[a], r); vals.push(v); for (let i = 0; i < n; i++) out[i] += cur[i][a] * v[i]; }
              const R = slot(reg, node, p); for (let i = 0; i < n; i++) for (let a = 0; a < node.k; a++) R[i][a] = Math.max(0, R[i][a] + vals[a][i] - out[i]);
              return out;
            }
            const q = 1 - p, cur = curOf(node, q), out = new Float64Array(n);
            for (let a = 0; a < node.k; a++) { const r2 = new Float64Array(r.length); let any = false; for (let j = 0; j < r.length; j++) { r2[j] = r[j] * cur[j][a]; if (r2[j]) any = true; } if (any) { const v = upd(node.children[a], r2); for (let i = 0; i < n; i++) out[i] += v[i]; } }
            return out;
          };
          upd(g.tree, Float64Array.from(H[1 - p], (h) => h.w));
          // linear average for the OTHER player's current strategy, weighted by its own reach (as exploitability.cfrPlus)
          curMemo.clear(); const q = 1 - p;
          const acc = (node, reach) => { if (node.kind === 'terminal') return; if (node.seat === q) { const cur = curOf(node, q), A = slot(avg, node, q); for (let j = 0; j < reach.length; j++) if (reach[j]) for (let a = 0; a < node.k; a++) A[j][a] += t * reach[j] * cur[j][a]; for (let a = 0; a < node.k; a++) acc(node.children[a], reach.map((x, j) => x * cur[j][a])); } else for (let a = 0; a < node.k; a++) acc(node.children[a], reach); };
          acc(g.tree, new Float64Array(H[q].length).fill(1));
        }
        if (o.every && (t % o.every === 0 || t === iterations)) { const e = evaluate(Savg); curve.push({ iterations: t, exploitability: e.exploitability }); if (o.onCheckpoint) o.onCheckpoint(t, e); if (o.target !== undefined && e.exploitability <= o.target) { iterations = t; break; } }
      }
      return { ...evaluate(Savg), iterations, curve, strategy: Savg, method: 'vectorised full-width CFR+ (alternating, RM+, linear averaging)' };
    }
    return { tree: g, hands: H, wsum, evaluate, exact, strategyOf, cfrPlus };
  }
  const exact = (game, spec) => prepare(game, spec).exact(game);
  return { prepare, exact };
});
