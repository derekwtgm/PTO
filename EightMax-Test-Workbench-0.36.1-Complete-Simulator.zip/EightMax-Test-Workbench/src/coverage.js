'use strict';
/* 0.31: classification of postflop decisions for coverage reports. Exact, abstracted, solved-on-demand and unavailable are kept
 * apart and never added together without saying so. An action row is the compact tuple logged by tools/pipeline-worker.cjs:
 *   [street, livePlayers, effectiveStackChips, source ('solver'|'scripted'), strategySource, unavailableCode, decideMs, cache, quality, rangeModel, fingerprint, rangeFallback] */
function classifyAction(a) { if (a[3] !== 'solver') return 'unavailable'; if (a[4] === 'solved-on-demand') return 'solvedOnDemand'; if (/approximate/.test(a[4] || '')) return 'abstracted'; return 'exact'; }
function classify(actions) {
  const post = actions.filter((a) => a[0] !== 'preflop'), c = { postflopDecisions: post.length, exact: 0, abstracted: 0, solvedOnDemand: 0, unavailable: 0, byStreet: {}, unavailableCodes: {}, qualityOfUsed: {} };
  for (const a of post) {
    const k = classifyAction(a), key = a[0] + (a[1] === 2 ? ' heads-up' : ' multiway'); c[k]++;
    const b = c.byStreet[key] || (c.byStreet[key] = { decisions: 0, exact: 0, abstracted: 0, solvedOnDemand: 0, unavailable: 0 }); b.decisions++; b[k]++;
    if (k === 'unavailable') c.unavailableCodes[a[5] || 'n/a'] = (c.unavailableCodes[a[5] || 'n/a'] || 0) + 1; else c.qualityOfUsed[a[8] || 'n/a'] = (c.qualityOfUsed[a[8] || 'n/a'] || 0) + 1;
  }
  c.exactShare = +(c.exact / Math.max(1, c.postflopDecisions)).toFixed(4); c.anyStrategyShare = +((c.exact + c.abstracted + c.solvedOnDemand) / Math.max(1, c.postflopDecisions)).toFixed(4);
  // 0.32: Wilson 95% intervals (decisions within a hand are not independent, so these understate the true uncertainty somewhat)
  c.exactShareCi95 = wilson(c.exact, c.postflopDecisions); c.anyStrategyShareCi95 = wilson(c.exact + c.abstracted + c.solvedOnDemand, c.postflopDecisions);
  c.validatedShare = +(((c.qualityOfUsed.validated || 0)) / Math.max(1, c.postflopDecisions)).toFixed(4);
  return c;
}
function wilson(k, n, z = 1.96) { if (!n) return null; const p = k / n, d = 1 + z * z / n, c = (p + z * z / (2 * n)) / d, h = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d; return [+Math.max(0, c - h).toFixed(4), +Math.min(1, c + h).toFixed(4)]; }
module.exports = { classify, classifyAction, wilson };
