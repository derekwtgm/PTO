'use strict';
/* EightMax Test Workbench 0.30: one copy of each loaded strategy for all table worker threads.
 *
 * The host (main thread) owns a StrategyLibrary opened with sharedMemory:true, so each verified record body is decoded into a
 * SharedArrayBuffer. A worker that misses in its own small cache asks the host over a MessagePort; the host loads the record
 * once (all integrity and identity checks happen there) and posts the SharedArrayBuffer. Posting a SharedArrayBuffer shares
 * the memory, it does not copy it, so ten tables on four workers read the same bytes. The data is never written after it
 * is loaded (records are immutable), so readers need no locks. Workers still re-check the identity they asked for against
 * the record header before using it.
 */
const { MessageChannel, Worker, receiveMessageOnPort } = require('node:worker_threads');
const path = require('node:path'), fs = require('node:fs');
const SID = require('./strategy-identity.js'), SNAP = require('./strategy-snapshot.js');
const nowMs = () => Number(process.hrtime.bigint()) / 1e6;

class SharedStrategyHost {
  constructor(library) {
    if (!library.o.sharedMemory) throw new Error('Open the host library with sharedMemory:true');
    this.lib = library; this.ports = []; this.stats = { requests: 0, served: 0, misses: 0, refused: 0, sharedBytes: 0, sharedRecords: 0 }; this.shared = new Map();
  }
  /** A port to hand to one worker (put it in workerData and in the Worker transferList). */
  port() {
    const ch = new MessageChannel(); this.ports.push(ch.port1);
    ch.port1.on('message', (m) => {
      if (!m || m.type !== 'fetch') return; this.stats.requests++;
      const r = this.lib.get(m.identity, m.fingerprint);
      if (!r.ok) { if (r.code === 'library-miss') this.stats.misses++; else this.stats.refused++; ch.port1.postMessage({ type: 'fetched', id: m.id, ok: false, code: r.code, reason: r.reason }); return; }
      const body = r.slot && r.slot.body; if (!body || !(body.buffer instanceof SharedArrayBuffer)) { ch.port1.postMessage({ type: 'fetched', id: m.id, ok: false, code: 'not-shared', reason: 'Record not held in shared memory' }); return; }
      if (!this.shared.has(m.fingerprint)) { this.shared.set(m.fingerprint, body.byteLength); this.stats.sharedBytes += body.byteLength; this.stats.sharedRecords++; }
      this.stats.served++; ch.port1.postMessage({ type: 'fetched', id: m.id, ok: true, sab: body.buffer, header: r.header, diskMs: r.timings.diskMs });
    });
    ch.port1.unref && ch.port1.unref();
    return ch.port2;
  }
  info() { return { kind: 'v1-main-thread-host', ...this.stats, cacheBytes: this.lib.cacheUsed, cacheEntries: this.lib.cache.size }; }
  /** Load every record into shared memory (benchmark "fully cached" workload). */
  prewarm() { const L = require('./strategy-library.js'); let n = 0; for (const e of this.lib.list()) { try { const rec = L.decodeRecord(fs.readFileSync(this.lib.file(e.fingerprint)), e.fingerprint, true); if (this.lib.get(rec.header.identity, e.fingerprint).ok) n++; } catch (err) { /* refused on request */ } } return n; }
  close() { for (const p of this.ports) p.close(); }
}

class SharedStrategyClient {
  constructor(port) { this.port = port; this.next = 0; this.waiting = new Map(); this.stats = { fetches: 0, hits: 0, misses: 0, ms: 0 };
    port.on('message', (m) => { const w = this.waiting.get(m.id); if (w) { this.waiting.delete(m.id); if (!this.waiting.size && port.unref) port.unref(); w(m); } }); port.unref && port.unref(); }
  static fromWorker() {
    const { workerData } = require('node:worker_threads'); const p = workerData && (workerData.libraryPort || (workerData.job && workerData.job.libraryPort)); if (!p) return null;
    const svc = workerData.libraryService || (workerData.job && workerData.job.libraryService);
    return svc ? new SharedStrategyClientV2(p, svc) : new SharedStrategyClient(p);
  }
  /** Resolves { game, header, ms } or null on a miss/refusal. */
  fetch(fingerprint, identity) {
    const id = ++this.next, t0 = nowMs(); this.stats.fetches++;
    return new Promise((res) => {
      this.waiting.set(id, (m) => {
        const ms = nowMs() - t0; this.stats.ms += ms;
        if (!m.ok) { this.stats.misses++; return res(null); }
        if (SID.diff(m.header.identity, identity).length) { this.stats.misses++; return res(null); }   // never trust a mismatched answer
        const game = SNAP.decode(new Uint8Array(m.sab)); game.shared = true; game.bytes = 0;            // memory is accounted by the host
        this.stats.hits++; res({ game, header: m.header, ms, diskMs: m.diskMs });
      });
      if (this.port.ref) this.port.ref(); this.port.postMessage({ type: 'fetch', id, fingerprint, identity });
    });
  }
}

/* ---------- 0.31: dedicated strategy-service thread + synchronous clients ----------
 * 0.30 measured 107-126 ms P95 for a shared fetch under ten-table load. The host's own work was small; the time was spent with the
 * reply waiting in the busy table worker's event-loop queue. v2 removes that wait:
 *   - the library lives in its own thread (src/strategy-service-worker.js), never blocked by tables or by the main thread;
 *   - a client posts the request and blocks in Atomics.wait on its own signal word; the service raises the word after posting
 *     the reply, and the client takes the reply with receiveMessageOnPort() - no event-loop turn in between;
 *   - a shared DIRECTORY (src/strategy-directory.js) lists stored fingerprints, so a miss is answered locally without a round trip;
 *   - the SharedArrayBuffer body is still shared, not copied; the service still applies every library check, and the client
 *     still re-checks the identity it asked for against the record header. A wait longer than `timeoutMs` is a miss (safe). */
class SharedStrategyService {
  constructor(dir, o = {}) {
    const D = require('./strategy-directory.js');
    this.dir = dir; this.directory = D.Directory.create(o.directoryCapacity || 1 << 17); this.next = 0; this.pending = new Map(); this.ports = [];
    this.worker = new Worker(path.join(__dirname, 'strategy-service-worker.js'), { workerData: { dir, cacheBytes: o.cacheBytes || 512 * 1048576, directory: this.directory.sab, readOnly: !!o.readOnly, refreshMs: o.refreshMs || 500 } });
    this._ready = new Promise((res, rej) => { this.worker.once('error', rej); this.worker.on('message', (m) => { if (m.type === 'ready') return res(); const w = this.pending.get(m.id); if (w) { this.pending.delete(m.id); w(m); } }); });
  }
  ready() { return this._ready; }
  _ask(type) { const id = ++this.next; return new Promise((res) => { this.pending.set(id, res); this.worker.postMessage({ type, id }); }); }
  /** A port for one client thread; put it in workerData.libraryPort (transferList) together with workerData.libraryService = service.descriptor(). */
  port() { const ch = new MessageChannel(); this.worker.postMessage({ type: 'port', port: ch.port1 }, [ch.port1]); this.ports.push(ch.port2); return ch.port2; }
  descriptor() { return { kind: 'v2', directory: this.directory.sab }; }
  async prewarm() { return (await this._ask('prewarm')).records; }
  async refresh() { await this._ask('refresh'); }
  async infoAsync() { return (await this._ask('info')).info; }
  info() { return this._lastInfo || { kind: 'v2-service-thread' }; }
  async close() { try { this._lastInfo = { kind: 'v2-service-thread', ...(await this.infoAsync()) }; await this._ask('close'); } finally { await this.worker.terminate(); } }
}
class SharedStrategyClientV2 {
  constructor(port, svc, o = {}) {
    const D = require('./strategy-directory.js');
    this.port = port; this.directory = new D.Directory(svc.directory); this.sig = new SharedArrayBuffer(4); this.sigView = new Int32Array(this.sig); this.next = 0; this.timeoutMs = o.timeoutMs || 2000;
    this.stats = { fetches: 0, hits: 0, misses: 0, directoryMisses: 0, timeouts: 0, ms: 0 };
  }
  _roundTrip(msg) {
    const id = ++this.next; Atomics.store(this.sigView, 0, 0); this.port.postMessage({ ...msg, id, sig: this.sig });
    const deadline = Date.now() + this.timeoutMs;
    while (true) {
      const got = receiveMessageOnPort(this.port); if (got && got.message && got.message.id === id) return got.message;
      const left = deadline - Date.now(); if (left <= 0) { this.stats.timeouts++; return null; }
      Atomics.wait(this.sigView, 0, 0, Math.min(left, 50));   // woken by the service right after it posts the reply
      if (Atomics.load(this.sigView, 0) === id) { const r = receiveMessageOnPort(this.port); if (r && r.message && r.message.id === id) return r.message; }
    }
  }
  /** Synchronous fetch: { game, header, ms, diskMs } or null (miss, refusal, identity mismatch or timeout). */
  fetchSync(fingerprint, identity) {
    const t0 = nowMs(); this.stats.fetches++;
    if (!this.directory.nearlyFull() && !this.directory.has(fingerprint)) { this.stats.misses++; this.stats.directoryMisses++; this.stats.ms += nowMs() - t0; return null; }
    const m = this._roundTrip({ type: 'fetch', fingerprint, identity }), ms = nowMs() - t0; this.stats.ms += ms;
    if (!m || !m.ok) { this.stats.misses++; return null; }
    if (SID.diff(m.header.identity, identity).length) { this.stats.misses++; return null; }   // never trust a mismatched answer
    const game = SNAP.decode(new Uint8Array(m.sab, m.byteOffset || 0, m.byteLength === undefined ? m.sab.byteLength : m.byteLength)); game.shared = true; game.bytes = 0;
    this.stats.hits++; return { game, header: m.header, ms, diskMs: m.diskMs, serviceMs: m.serviceMs };
  }
  fetch(fingerprint, identity) { return Promise.resolve(this.fetchSync(fingerprint, identity)); }
  /** After this thread stored a record: make the service add it to the directory before the next lookup. */
  noteStored() { this._roundTrip({ type: 'refresh' }); }
}
module.exports = { SharedStrategyHost, SharedStrategyClient, SharedStrategyService, SharedStrategyClientV2 };
