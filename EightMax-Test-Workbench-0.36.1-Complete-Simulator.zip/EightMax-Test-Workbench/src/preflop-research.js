'use strict';
/* EightMax Test Workbench 0.32: eight-handed PREFLOP research - information-set coverage, training modes, multiple seeds,
 * continuation, and independent-of-coverage accuracy evidence (restricted best responses with confidence intervals).
 *
 * What each number is (reports keep these labels; nothing is upgraded):
 *   coverage (exact count)      rows actually stored in the native state for each preflop decision state, counted from the file
 *   reach (sampled estimate)    probability of each preflop node under the stored strategy, by Monte-Carlo line sampling
 *                               (n deals, fixed seed); reach-weighted coverage inherits that sampling error
 *   restricted gain (lower bound, sampled evaluation)   mwcli --verify method=restricted: best response of ONE seat restricted to its
 *                               PREFLOP decisions (postflop play follows the study), evaluated on an independent sample stream;
 *                               a LOWER BOUND on that seat's unilateral gain inside the study abstraction, with a 95% interval
 *   one-decision gain (sampled) mwcli --verify method=sampled: best one-shot deviation at one decision node per seat (estimate)
 *   seed distance / stability   mean L1 distance between average strategies of independent seeds (mwcli --compare); equilibria of
 *                               multiplayer games are not unique, so stability is reported, never used as an accuracy measure
 *   full-game exploitability    NOT computed. For eight players there is no two-player exploitability; "NashConv" over the whole
 *                               linked tree is not feasible here. Reports say "unavailable", never 0.
 * Game: 8 seats, equal stacks (configurable), SB 0.5 / BB 1 / ante 0.1 BB per player (classic), chip EV, linked preflop tree
 * (fold / call / open 2.2 / all-in, up to 3 bets) continuing to the river with the study's single-size postflop menu.
 */
const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process');

const POSITIONS = Object.freeze(['UTG', 'UTG+1 (early position)', 'MP (middle position)', 'HJ (hijack)', 'CO (cutoff)', 'BTN (button)', 'SB (small blind)', 'BB (big blind)']);
const SHORT = Object.freeze(['UTG', 'UTG+1', 'MP', 'HJ', 'CO', 'BTN', 'SB', 'BB']);

/** Training modes. A mode NAME never implies accuracy: every report states the measured coverage and gains, and the
 *  "high-accuracy" mode is only reported as meeting its targets when the measurements do. */
const MODES = Object.freeze({
  fast: Object.freeze({ name: 'fast', label: 'Fast Reference Study', updates: 200000, seeds: [8], gainSamples: 4000, gainMethods: ['sampled'], lineSamples: 4000, purpose: 'application testing and low-cost research; not accurate' }),
  standard: Object.freeze({ name: 'standard', label: 'Standard Research Study', updates: 2000000, seeds: [8, 108], gainSamples: 20000, gainMethods: ['restricted', 'sampled'], lineSamples: 12000, purpose: 'improved coverage and detailed diagnostics (the 0.31 default length)' }),
  'high-accuracy': Object.freeze({ name: 'high-accuracy', label: 'High-Accuracy Research Study', startUpdates: 2000000, maxUpdates: 10000000, growth: 2, seeds: [8, 108, 208], gainSamples: 40000, gainMethods: ['restricted', 'sampled'], lineSamples: 20000,
    targets: Object.freeze({ reachWeightedClassCoverage: 0.995, maxRestrictedGainUpperBB: 0.05 }), purpose: 'continues training and evaluation inside time and memory budgets until the measured targets are met or a limit stops it' }),
});
function modeOf(m) { const x = typeof m === 'string' ? MODES[m] : m; if (!x) throw new Error('Unknown preflop study mode ' + m + ' (use ' + Object.keys(MODES).join(', ') + ')'); return x; }

const RANKS = '23456789TJQKA';
function classOfCards(a, b) { const hi = Math.max(a >> 2, b >> 2), lo = Math.min(a >> 2, b >> 2); return RANKS[hi] + RANKS[lo] + (hi === lo ? '' : (a & 3) === (b & 3) ? 's' : 'o'); }

/** Path string of a preflop state from the store's tree table. */
function pathOf(store, s) { let p = ''; while (s !== 0) { const sl = store.slot[s]; p = (sl === 7 ? 'c' : String(sl)) + p; s = store.parent[s]; } return 'r' + p; }

/**
 * Information-set coverage of the stored preflop strategy, by exact count, plus node reach by line sampling.
 * store: StrategyStore of the native state; prepared: the prepared study (tree view + range rows).
 * o: samples (deals), seed, reachFloor (nodes below this sampled reach are not listed as missing branches)
 */
function coverage(store, prepared, o = {}) {
  const hands = prepared.spec.hands, n = hands.length, samples = o.samples || 8000, floor = o.reachFloor === undefined ? 0.001 : o.reachFloor;
  const classOfRow = hands.map((rows) => rows.map((r) => classOfCards(r[1], r[2])));
  const classSize = hands.map((rows, s) => { const m = new Map(); for (const c of classOfRow[s]) m.set(c, (m.get(c) || 0) + 1); return m; });
  // exact per-state counts
  const states = new Map();
  for (let s = 0; s < store.stateCount; s++) {
    if (store.kind[s] !== 0 || store.length[s] !== 0) continue;
    const seat = store.actor[s], rows = store.rowsAt(s), classes = new Set();
    for (const key of rows.keys()) { const h = +key.split('|')[0]; if (classOfRow[seat][h]) classes.add(classOfRow[seat][h]); }
    states.set(s, { state: s, path: pathOf(store, s), seat, k: store.k[s], combos: rows.size, combosInRange: hands[seat].length, classes: classes.size, classesInRange: classSize[seat].size, reach: 0, visits: 0 });
  }
  // reach by Monte-Carlo line sampling (class-pooled lookups for line generation only; uniform when a class has no row)
  const g = prepared.game, view = (steps) => g.view(steps); let x = (o.seed || 12345) >>> 0; const rnd = () => { x = (Math.imul(x, 1103515245) + 12345) >>> 0; return x / 4294967296; };
  const rowIndex = hands.map((rows) => new Map(rows.map((r, i) => [Math.min(r[1], r[2]) * 64 + Math.max(r[1], r[2]), i])));
  const classRows = hands.map((rows, s) => { const m = new Map(); rows.forEach((r, i) => { const c = classOfRow[s][i]; if (!m.has(c)) m.set(c, []); m.get(c).push(i); }); return m; });
  const vcache = new Map(), V = (steps) => { const k = steps.join(','); let v = vcache.get(k); if (!v) { const w = view(steps); v = { kind: w.kind, seat: w.seat, k: w.actions ? w.actions.length : 0, live: w.live }; vcache.set(k, v); } return v; };
  let reachedFlop = 0, missingLookups = 0, lookups = 0;
  for (let d = 0; d < samples; d++) {
    const deck = Array.from({ length: 52 }, (_, i) => i); for (let i = 51; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
    const steps = []; let v = V(steps), path = 'r';
    while (v.kind === 'player') {
      const seat = v.seat, a = deck[2 * seat], b = deck[2 * seat + 1], st = store.stateOf(path); const e = st === null ? null : states.get(st); if (e) e.visits++;
      let p = null; lookups++;
      if (st !== null) { const hi = rowIndex[seat].get(Math.min(a, b) * 64 + Math.max(a, b)); if (hi !== undefined) p = store.averageAt(path, seat, hi);
        if (!p) { missingLookups++; const cls = classOfCards(a, b), list = classRows[seat].get(cls) || []; let sum = null, m = 0; for (const i of list) { const q = store.averageAt(path, seat, i); if (!q) continue; if (!sum) sum = new Float64Array(q.length); for (let t = 0; t < q.length; t++) sum[t] += q[t]; m++; } if (m) p = sum.map((y) => y / m); } }
      if (!p) p = new Float64Array(v.k).fill(1 / v.k);
      let r = rnd(), act = 0; while (act < p.length - 1 && r >= p[act]) { r -= p[act]; act++; }
      steps.push(act); path += String(act); v = V(steps);
    }
    if (v.kind === 'chance') reachedFlop++;
  }
  const list = [...states.values()]; for (const e of list) e.reach = e.visits / samples;
  const wsum = (f, sel = () => true) => { let a = 0, w = 0; for (const e of list) if (sel(e) && e.reach > 0) { a += e.reach * f(e); w += e.reach; } return w ? a / w : null; };
  const perSeat = SHORT.slice(0, n).map((label, seat) => ({ seat, position: POSITIONS[seat], decisionStates: list.filter((e) => e.seat === seat).length,
    reachWeightedComboCoverage: round(wsum((e) => e.combos / e.combosInRange, (e) => e.seat === seat)), reachWeightedClassCoverage: round(wsum((e) => e.classes / e.classesInRange, (e) => e.seat === seat)),
    reachedStatesWithMissingClasses: list.filter((e) => e.seat === seat && e.reach >= floor && e.classes < e.classesInRange).length }));
  const missing = list.filter((e) => e.reach >= floor && e.classes < e.classesInRange).sort((a, b) => b.reach - a.reach).slice(0, o.listMissing || 25)
    .map((e) => ({ path: e.path, position: SHORT[e.seat], reach: round(e.reach), classesStored: e.classes, classesInRange: e.classesInRange, combosStored: e.combos, combosInRange: e.combosInRange }));
  const allCombos = list.reduce((a, e) => a + e.combos, 0), allPossible = list.reduce((a, e) => a + e.combosInRange, 0);
  return {
    format: 'eightmax-preflop-coverage', version: 1, iterations: store.header.iterations,
    exactCounts: { preflopDecisionStates: list.length, storedRows: allCombos, possibleRows: allPossible, unweightedComboCoverage: round(allCombos / allPossible), statesWithAllClasses: list.filter((e) => e.classes === e.classesInRange).length, statesWithNoRow: list.filter((e) => e.combos === 0).length },
    sampled: { method: 'Monte-Carlo line sampling from the stored average strategy (class-pooled for line generation; uniform where a class has no row)', deals: samples, seed: o.seed || 12345, dealsReachingFlop: reachedFlop, lookups, lookupsWithoutOwnRow: missingLookups, shareOfDecisionsWithoutOwnRow: round(missingLookups / Math.max(1, lookups)),
      reachWeightedComboCoverage: round(wsum((e) => e.combos / e.combosInRange)), reachWeightedClassCoverage: round(wsum((e) => e.classes / e.classesInRange)), reachedStates: list.filter((e) => e.reach > 0).length },
    perSeat, missingBranches: missing, reachFloor: floor,
    incomplete: list.some((e) => e.reach >= floor && e.classes < e.classesInRange),
    note: 'Coverage is a necessary condition for a usable strategy table, not evidence of accuracy (see restricted gains).',
  };
}
const round = (v, d = 6) => (v === null || v === undefined || !Number.isFinite(v) ? null : +v.toFixed(d));

/** Run mwcli --verify (restricted / sampled response gains) and return the parsed report, or { error }. */
function verifyGains(cli, specFile, stateFile, o = {}) {
  const args = ['--verify', specFile, stateFile, 'method=' + (o.method || 'restricted'), 'samples=' + (o.samples || 20000), 'seed=' + (o.seed || 1), 'timeMs=' + (o.timeMs || 600000), 'threads=' + (o.threads || 2), 'memory=' + (o.memoryMiB || 4096)];
  const t0 = Date.now(), r = cp.spawnSync(cli, args, { encoding: 'utf8', maxBuffer: 64 << 20, timeout: (o.timeMs || 600000) + 120000 });
  let doc = null; try { doc = JSON.parse(String(r.stdout).trim().split('\n').pop()); } catch (e) { return { error: 'mwcli --verify printed no report (' + (r.status === null ? r.signal : r.status) + '): ' + String(r.stderr || r.stdout).slice(-400), wallMs: Date.now() - t0 }; }
  if (doc.error) return { error: doc.error, attempts: doc.attempts, wallMs: Date.now() - t0 };
  return { ...summarizeGains(doc), wallMs: Date.now() - t0, raw: o.keepRaw ? doc : undefined };
}
function summarizeGains(doc) {
  const seats = (doc.seats || []).map((s) => ({ seat: s.seat, position: POSITIONS[s.seat] || s.position, engineLabel: s.position, available: s.available, gainBB: s.gain, stdErrBB: s.stdErr, ci95BB: s.ci95, simultaneousCi95BB: s.simultaneousCi, policyValueBB: s.policyValue }));
  return { method: doc.methodUsed, mode: doc.mode, resultClass: doc.resultClass, classification: doc.methodUsed === 'restricted' ? 'restricted-evaluation (lower bound; sampled evaluation with 95% interval)' : doc.methodUsed === 'sampled' ? 'sampled estimate of a lower bound (one-decision deviations)' : doc.methodUsed === 'exact' ? 'exact inside the abstraction' : 'unknown',
    samples: doc.samples, seed: doc.seed, seats, aggregate: doc.aggregate, utilityModel: doc.utilityModel, engineSeconds: doc.seconds, limitations: doc.limitations,
    fullGameExploitability: 'unavailable: not computed for the eight-handed game (no two-player formula applies; the restricted gains above are lower bounds only)' };
}

/** First-in decision of every position: everyone before it folds (BB: SB completes, the only way BB acts first-in). */
function firstInPaths(prepared) {
  const g = prepared.game, out = [];
  for (let seat = 0; seat < 8; seat++) {
    let steps = []; const v0 = () => g.view(steps);
    for (let i = 0; i < seat; i++) { const v = v0(); const f = v.actions.findIndex((a) => a.label === 'Fold'); if (seat === 7 && i === 6) { const c = v.actions.findIndex((a) => /^Call/.test(a.label)); steps = steps.concat(c); } else steps = steps.concat(f); }
    const v = v0(); out.push({ seat, position: SHORT[seat], path: steps, labels: v.actions.map((a) => a.label), actor: v.seat });
  }
  return out;
}
/** Sampled one-decision deviation gain of one seat at one node (mwcli --gain method=sampled, path). Lower-bound ESTIMATE with 95% CI. */
function deviationGain(cli, specFile, stateFile, seat, nodePath, o = {}) {
  const dir = o.dir || require('node:os').tmpdir(), req = path.join(dir, 'gain-' + process.pid + '-' + seat + '-' + Date.now() + '.json');
  fs.writeFileSync(req, JSON.stringify({ method: 'sampled', samples: o.samples || 2000, seed: o.seed || 1, timeLimitMs: o.timeMs || 600000, seats: [seat], path: nodePath, threads: o.threads || 1 }));
  const t0 = Date.now(), r = cp.spawnSync(cli, ['--gain', specFile, stateFile, req, String(o.memoryMiB || 6000)], { encoding: 'utf8', maxBuffer: 256 << 20, timeout: (o.timeMs || 600000) + 120000 }); fs.rmSync(req, { force: true });
  const t = String(r.stdout || ''); let j; try { j = JSON.parse(t.slice(t.indexOf('{'), t.lastIndexOf('}') + 1)); } catch (e) { return { seat, position: SHORT[seat], error: 'mwcli --gain failed (' + r.status + '): ' + String(r.stderr || t).slice(-300), wallMs: Date.now() - t0 }; }
  const x = (j.seats || [])[0] || {};
  if (!x.available) return { seat, position: SHORT[seat], available: false, reason: x.reason || x.unavailable || 'not available', wallMs: Date.now() - t0 };
  return { seat, position: SHORT[seat], node: nodePath, classification: 'sampled estimate of a LOWER BOUND (best one-shot deviation at this node; later play follows the study)', conditionalGainBB: x.conditionalGain, reachProbability: x.reachProbability, gainBB: x.gain,
    evaluationSamples: x.evaluationSamples, selectionSamplesPerHand: x.selectionSamplesPerHand, policyLookups: x.policyLookups, fallbackLookups: x.fallbackLookups, fallbackShare: x.policyLookups ? +(x.fallbackLookups / x.policyLookups).toFixed(4) : null, wallMs: Date.now() - t0 };
}

/** Seed stability at given nodes: mean total-variation distance (L1 / 2) between two studies' average strategies over the range
 *  rows both have stored, per node. Reported as STABILITY, never as accuracy (8-player equilibria need not be unique). */
function stability(snapA, snapB, nodes, rangeSize = 1326) {
  return nodes.map((nd) => { let sum = 0, n = 0, onlyA = 0, onlyB = 0; const path = 'r' + nd.path.join('');
    for (let h = 0; h < rangeSize; h++) { const a = snapA.averageAt(path, nd.seat, h), b = snapB.averageAt(path, nd.seat, h); if (a && b) { let d = 0; for (let k = 0; k < a.length; k++) d += Math.abs(a[k] - b[k]); sum += d / 2; n++; } else if (a) onlyA++; else if (b) onlyB++; }
    return { position: nd.position, path, rowsCompared: n, rowsOnlyInA: onlyA, rowsOnlyInB: onlyB, meanTotalVariation: n ? +(sum / n).toFixed(4) : null }; });
}

/** mwcli --compare between two states of the same game (seed stability, continuation). gains=none by default (fast). */
function compareStates(cli, specFile, stateA, stateB, o = {}) {
  const r = cp.spawnSync(cli, ['--compare', specFile, stateA, stateB, 'gains=' + (o.gains || 'none'), 'memory=' + (o.memoryMiB || 4096)], { encoding: 'utf8', maxBuffer: 64 << 20, timeout: o.timeoutMs || 1800000 });
  try { return JSON.parse(String(r.stdout).trim().split('\n').pop()); } catch (e) { return { error: 'mwcli --compare failed: ' + String(r.stderr || r.stdout).slice(-400) }; }
}

/** Classify a set of measurements for a study (what may be said about it). */
function assess(mode, cov, gains) {
  const m = modeOf(mode), out = { mode: m.name, label: m.label, statements: [], targetsMet: null };
  out.statements.push('Coverage: ' + (cov ? (100 * cov.sampled.reachWeightedClassCoverage).toFixed(2) + '% reach-weighted hand-class coverage (sampled reach), ' + cov.exactCounts.statesWithNoRow + ' decision states without any stored row (exact count)' : 'not measured'));
  const restricted = (gains || []).find((g) => g.method === 'restricted' && !g.error);
  if (restricted) { const worst = restricted.seats.filter((s) => Array.isArray(s.ci95BB)).sort((a, b) => b.ci95BB[1] - a.ci95BB[1])[0]; out.worstSeat = worst ? { position: worst.position, gainBB: worst.gainBB, ci95BB: worst.ci95BB } : null;
    out.statements.push('Restricted preflop best-response gains (lower bounds): largest upper 95% bound ' + (worst ? worst.ci95BB[1].toFixed(4) + ' bb (' + worst.position + ')' : 'n/a')); }
  else out.statements.push('Restricted best-response gains: not available for this study');
  out.statements.push('Full eight-handed exploitability / NashConv: not computed (unavailable, not zero). No equilibrium claim is made.');
  if (m.targets) {
    const covOk = cov && cov.sampled.reachWeightedClassCoverage >= m.targets.reachWeightedClassCoverage, worstUpper = out.worstSeat ? out.worstSeat.ci95BB[1] : Infinity, gainOk = worstUpper <= m.targets.maxRestrictedGainUpperBB;
    out.targetsMet = !!(covOk && gainOk); out.statements.push('High-accuracy targets (' + JSON.stringify(m.targets) + '): ' + (out.targetsMet ? 'met by measurement' : 'NOT met (coverage ' + (covOk ? 'ok' : 'below target') + ', restricted gains ' + (gainOk ? 'ok' : out.worstSeat ? 'above target' : 'not available (not evaluated or not feasible)') + ')'));
  }
  return out;
}

module.exports = { POSITIONS, SHORT, MODES, modeOf, classOfCards, pathOf, coverage, verifyGains, summarizeGains, firstInPaths, deviationGain, stability, compareStates, assess };
