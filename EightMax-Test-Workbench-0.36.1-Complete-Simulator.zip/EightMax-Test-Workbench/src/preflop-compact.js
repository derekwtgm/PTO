'use strict';
/* EightMax Test Workbench 0.33: COMPACT eight-handed preflop research (solver modes A-D).
 *
 * Measured problem (reports/0.33-preflop-memory.json, tools/state-anatomy-033.cjs): the 0.32 linked preflop study (Mode A) trains the
 * whole hand; at 2,000,000 updates half of its 23.3 million information-set rows are postflop rows keyed by an EXACT board and an exact
 * private hand, and 99.98 % of those rows are the only row in their (betting state, board) context - each was created by one sampled
 * deal and is essentially never revisited. They cost memory without giving the preflop strategy a trained continuation.
 *
 * Modes (each is a DIFFERENT, explicitly defined game; results of different modes are never mixed or relabelled):
 *   A  full-linked        0.32 reference: preflop tree (fold / call / open 2.2 / all-in, 3x raises, cap 3) + flop/turn/river with one
 *                         50 %-pot bet and fold/call on every street; exact-hand rows everywhere. Unchanged; still the reference.
 *   B  checkdown          same preflop tree; after preflop betting closes with two or more players, NO postflop betting: the board
 *                         is dealt and hands go to showdown (chip EV = pot share by showdown result, side pots by contribution).
 *                         Defined through the study's own street menus (empty bet lists), so the EightMax 5.1 engine is unchanged:
 *                         single-action postflop states create no rows.
 *   B169 checkdown-class  Mode B with preflop rows keyed by the 169 hand classes (EightMax "compact" grouping; deals, card removal and
 *                         showdowns stay physical). LOSSLESS for Mode B: preflop decisions see only the own hole cards and the game is
 *                         suit-symmetric, so suit-isomorphic hands face isomorphic situations and have equal action values against any
 *                         class-constant profile; an equilibrium of the class-keyed game is an equilibrium of Mode B. (With postflop
 *                         decisions the same grouping would also group postflop hands - lossy - so it is only offered with Mode B.)
 *   C  restricted-flop    preflop tree + ONE flop betting round (Mode A's flop menu), then check-down turn and river. Exact-hand rows.
 *   D  comparison         runs identical preflop situations (same seed, same updates) through A, B/B169 and C and reports memory, speed,
 *                         coverage, seed stability and strategy distance (tools/preflop-modes-033.cjs).
 *
 * WHAT B/B169/C ARE NOT: check-down is an APPROXIMATION of strategic postflop play. Raw showdown equity is not strategic value:
 * position, initiative and fold equity are ignored (calibrated against exact flop equilibria in reports/0.33-checkdown-calibration.json).
 * Strategies from B/B169/C are labelled "approximate (compact continuation)" and never "solved" or "GTO".
 */
const fs = require('node:fs'), path = require('node:path');

const NOBET = Object.freeze({ bets: '', raises: '', maxBets: 1 });
const MODES = Object.freeze({
  A: Object.freeze({ id: 'A', name: 'full-linked', label: 'Mode A - full linked research (0.32 reference)', abstraction: 'exact', postflop: 'study menus on flop, turn and river', accuracy: 'research model (sampled continuation; convergence not proven)' }),
  B: Object.freeze({ id: 'B', name: 'checkdown', label: 'Mode B - compact preflop, check-down continuation', abstraction: 'exact', postflop: 'none (check-down to showdown)', accuracy: 'approximate (compact continuation: check-down)' }),
  B169: Object.freeze({ id: 'B169', name: 'checkdown-class', label: 'Mode B169 - compact preflop, check-down, 169 hand classes', abstraction: 'compact', postflop: 'none (check-down to showdown)', accuracy: 'approximate (compact continuation: check-down); class keys lossless for this game' }),
  C: Object.freeze({ id: 'C', name: 'restricted-flop', label: 'Mode C - restricted postflop continuation (one flop betting round)', abstraction: 'exact', postflop: 'flop menu of Mode A, then check-down', accuracy: 'approximate (restricted continuation)' }),
});
function modeOf(id) { const m = MODES[id]; if (!m) throw new Error('Unknown preflop solver mode ' + id + ' (use ' + Object.keys(MODES).join(', ') + ')'); return m; }

/** Study config of a mode, built from the linked reference config (stacks, seed, antes etc. come from `base`). */
function configFor(mode, base) {
  const m = modeOf(mode), s = base.streets || {};
  if (m.id === 'A') return { ...base };
  if (m.id === 'C') return { ...base, streets: { flop: s.flop, turn: NOBET, river: NOBET } };
  return { ...base, streets: { flop: NOBET, turn: NOBET, river: NOBET } };
}
/** Native spec of a mode. Modes A/B/C go through the workbench adapter (exact keys); B169 builds the engine game with compact grouping. */
function specFor(mode, base, EM, A) {
  const m = modeOf(mode), cfg = configFor(mode, base);
  if (m.abstraction === 'exact') { const p = A.prepare(EM, { config: cfg, iterations: 1000, timeMs: 600000, strategyBudgetMiB: 32 }); return { spec: A.nativeJob(p, 'train').spec, prepared: p, config: cfg }; }
  const o = A.input({ config: cfg, iterations: 1000, timeMs: 600000 }), g = EM.MultiwayGame({ ...o.config, abstraction: 'compact' });
  return { spec: { ...g.nativeSpec(), device: 'cpu', gpuMiB: 128 }, game: g, config: cfg };
}
/** Game definition text recorded with every result. */
function gameDefinition(mode, base) {
  const m = modeOf(mode), st = base.stacks || [];
  return { mode: m.id, name: m.name, seats: st.length, stacksBB: st, blinds: 'SB 0.5 / BB 1', ante: 'classic 0.1 BB per player', objective: 'chip EV', preflop: base.preflop, postflop: m.postflop, keys: m.abstraction === 'compact' ? '169 preflop hand classes (lossless by suit symmetry in this game)' : 'exact private hands (1,326)', accuracyClass: m.accuracy };
}

// ---------------- streaming preflop reader (both EMMW4 row layouts) ----------------
const SHORT = Object.freeze(['UTG', 'UTG+1', 'MP', 'HJ', 'CO', 'BTN', 'SB', 'BB']);
/** Reads every PREFLOP information set of a native state, aggregated to the 169 hand classes, in COMPACT form:
 *  per preflop decision state (typed arrays): actor, distinct classes stored (169-bit set), combos stored, summed average mass;
 *  full class strategies (mean of the class's normalised combo strategies; class-keyed layouts: the class row) ONLY for the states
 *  named in o.keepPaths (default: every state whose path has at most o.keepDepth (default 8) actions). spec: needed for exact layouts. */
function readPreflop(stateFile, spec, EM, o = {}) {
  const fd = fs.openSync(stateFile, 'r'), size = fs.fstatSync(fd).size, keepDepth = o.keepDepth === undefined ? 8 : o.keepDepth;
  try {
    const rd = (pos, len) => { const b = Buffer.allocUnsafe(len); let got = 0; while (got < len) { const n = fs.readSync(fd, b, got, len - got, pos + got); if (n <= 0) throw new Error('truncated state'); got += n; } return b; };
    const top = rd(0, 12); if (top.toString('latin1', 0, 5) !== 'EMMW4') throw new Error('not an EMMW4 state');
    const hl = top.readUInt32LE(8), head = JSON.parse(rd(12, hl).toString('utf8')), keyed = head.rowKeys === 1;
    if (head.rowSync !== undefined) throw new Error('DCFR row layout is not supported by the compact reader');
    let p = 12 + hl; const sc = rd(p, 4).readUInt32LE(0); p += 4; const tb = rd(p, sc * 9); p += sc * 9;
    const parent = new Uint32Array(sc), slot = new Uint8Array(sc), kind = new Uint8Array(sc), actor = new Uint8Array(sc), len = new Uint8Array(sc), kk = new Uint8Array(sc), depth = new Uint16Array(sc);
    const pre = new Int32Array(sc).fill(-1); let np = 0;
    for (let i = 0; i < sc; i++) { const q = i * 9; parent[i] = tb.readUInt32LE(q); slot[i] = tb[q + 4]; kind[i] = tb[q + 5]; actor[i] = tb[q + 6]; len[i] = tb[q + 7]; kk[i] = tb[q + 8]; if (i) depth[i] = depth[parent[i]] + 1; if (len[i] === 0 && kind[i] === 0) pre[i] = np++; }
    const pathOf = (s) => { let x = ''; while (s !== 0) { x = (slot[s] === 7 ? 'c' : String(slot[s])) + x; s = parent[s]; } return 'r' + x; };
    const keepSet = o.keepPaths ? new Set(o.keepPaths) : null, keep = new Map();   // state id -> { k, cls: Map(class -> {sum, n, mass}) }
    const bits = new Uint8Array(np * 22), classes = new Uint16Array(np), combos = new Uint32Array(np), mass = new Float64Array(np), hasRows = new Uint8Array(np);
    const rowCount = rd(p, 4).readUInt32LE(0); p += 4;
    const CH = 8 << 20, buf = Buffer.allocUnsafe(CH); let carry = Buffer.alloc(0), pos = p, seen = 0, preflopRows = 0;
    const add = (st, cls, k, data, off) => {
      const ix = pre[st]; if (ix < 0) return; let m = 0; for (let a = 0; a < k; a++) m += data.readDoubleLE(off + 8 * a);
      const byte = ix * 22 + (cls >> 3), bit = 1 << (cls & 7); if (!(bits[byte] & bit)) { bits[byte] |= bit; classes[ix]++; }
      combos[ix]++; mass[ix] += m; hasRows[ix] = 1; preflopRows++;
      let ks = keep.get(st);
      if (ks === undefined) { const path = keepSet ? pathOf(st) : null; ks = (keepSet ? keepSet.has(path) : depth[st] <= keepDepth) ? { k, cls: new Map(), path: path || pathOf(st) } : null; keep.set(st, ks); }
      if (!ks) return; let c = ks.cls.get(cls); if (!c) { c = { sum: new Float64Array(k), n: 0, mass: 0 }; ks.cls.set(cls, c); }
      if (m > 0) for (let a = 0; a < k; a++) c.sum[a] += data.readDoubleLE(off + 8 * a) / m; else for (let a = 0; a < k; a++) c.sum[a] += 1 / k;
      c.n++; c.mass += m;
    };
    while (seen < rowCount) {
      const n = pos < size ? fs.readSync(fd, buf, 0, Math.min(CH, size - pos), pos) : 0; if (n <= 0) throw new Error('truncated rows');
      pos += n; const data = carry.length ? Buffer.concat([carry, buf.subarray(0, n)]) : buf.subarray(0, n); let q = 0;
      while (seen < rowCount) {
        if (keyed) {
          if (q + 6 > data.length) break; const kl = data.readUInt16LE(q + 4); if (q + 7 + kl > data.length) break; const k = data[q + 6 + kl], L = 7 + kl + 16 * k; if (q + L > data.length) break;
          const st = data.readUInt32LE(q); if (len[st] === 0) { const key = Number(data.toString('latin1', q + 6, q + 6 + kl)); if (!(key >= 0 && key < 169)) throw new Error('Unexpected preflop key ' + key + ' (class keys 0-168 expected)'); add(st, key, k, data, q + 7 + kl + 8 * k); }
          q += L;
        } else {
          if (q + 12 > data.length) break; const k = data[q + 11], L = 12 + 16 * k; if (q + L > data.length) break;
          const st = data.readUInt32LE(q); if (len[st] === 0) { const hi = data.readUInt16LE(q + 4), id = spec.hands[actor[st]][hi][0]; add(st, EM.CLS[id], k, data, q + 12 + 8 * k); }
          q += L;
        }
        seen++;
      }
      carry = Buffer.from(data.subarray(q));
    }
    const byPath = new Map(); for (const [st, ks] of keep) if (ks) byPath.set(ks.path, { id: st, actor: actor[st], k: ks.k, cls: ks.cls, path: ks.path });
    let preflopDecisionStates = 0, statesWithRows = 0; for (let i = 0; i < np; i++) statesWithRows += hasRows[i]; for (let i = 0; i < sc; i++) if (len[i] === 0 && kind[i] === 0 && kk[i] > 1) preflopDecisionStates++;
    /** iterate per preflop state with rows: fn(actor, classesStored, combosStored, mass) */
    const eachState = (fn) => { for (let i = 0; i < sc; i++) { const ix = pre[i]; if (ix >= 0 && hasRows[ix]) fn(actor[i], classes[ix], combos[ix], mass[ix]); } };
    return { header: head, keyed, byPath, eachState, preflopRows, statesWithRows, preflopDecisionStates, totalStates: sc, totalRows: rowCount, fileBytes: size,
      get states() { return { size: statesWithRows }; },
      classStrategy(pathStr, cls) { const s = byPath.get(pathStr); if (!s) return null; const c = s.cls.get(cls); if (!c) return null; return Array.from(c.sum, (x) => x / c.n); } };
  } finally { fs.closeSync(fd); }
}

/** Position-level coverage from a preflop read: per acting position, decision states with rows, mean class coverage (plain and
 *  average-mass weighted), states with every class, first-in node coverage. Exact counts from the state (no sampling). */
function positionCoverage(read, firstIn, EM) {
  const per = SHORT.map((pos, seat) => ({ position: pos, seat, statesWithRows: 0, statesAllClasses: 0, classCoverageMean: 0, classCoverageMassWeighted: 0, mass: 0, combosStored: 0 }));
  read.eachState((actor, ncls, ncombos, m) => { const e = per[actor], cov = ncls / 169; e.statesWithRows++; e.classCoverageMean += cov; e.classCoverageMassWeighted += cov * m; e.mass += m; e.combosStored += ncombos; if (ncls === 169) e.statesAllClasses++; });
  for (const e of per) { e.classCoverageMean = e.statesWithRows ? +(e.classCoverageMean / e.statesWithRows).toFixed(4) : null; e.classCoverageMassWeighted = e.mass ? +(e.classCoverageMassWeighted / e.mass).toFixed(4) : null; delete e.mass; }
  if (firstIn) for (const f of firstIn) { const s = read.byPath.get('r' + f.path.join('')), e = per[f.seat]; e.firstInPath = 'r' + f.path.join(''); e.firstInClassesStored = s ? s.cls.size : 0; e.firstInMissingClasses = s ? 169 - s.cls.size : 169; }
  return per;
}

/** Mean total-variation distance between two reads at given paths, over hand classes stored in both (combo-weighted: pairs 6,
 *  suited 4, offsuit 12). Also returns the per-class action-frequency difference of the most frequent action. */
function compareReads(a, b, paths, EM) {
  return paths.map((f) => {
    const p = typeof f === 'string' ? f : 'r' + f.path.join(''), sa = a.byPath.get(p), sb = b.byPath.get(p);
    if (!sa || !sb) return { path: p, position: f.position, rowsCompared: 0, meanTotalVariation: null, reason: !sa ? 'missing in first' : 'missing in second' };
    let sum = 0, w = 0, n = 0, maxTv = 0;
    for (let cls = 0; cls < 169; cls++) { const x = a.classStrategy(p, cls), y = b.classStrategy(p, cls); if (!x || !y) continue; let tv = 0; for (let k = 0; k < x.length; k++) tv += Math.abs(x[k] - y[k]); tv /= 2; const cw = EM.CLASS_NCOMBOS ? EM.CLASS_NCOMBOS[cls] : 1; sum += cw * tv; w += cw; n++; if (tv > maxTv) maxTv = tv; }
    return { path: p, position: f.position, classesCompared: n, meanTotalVariation: w ? +(sum / w).toFixed(4) : null, maxClassTotalVariation: +maxTv.toFixed(4) };
  });
}
/** Action frequencies (combo-weighted over all 169 classes; classes without rows are counted as missing) of one node. */
function nodeFrequencies(read, pathStr, labels, EM) {
  const s = read.byPath.get(pathStr); if (!s) return null; const f = new Float64Array(s.k); let w = 0, missing = 0;
  for (let cls = 0; cls < 169; cls++) { const x = read.classStrategy(pathStr, cls), cw = EM.CLASS_NCOMBOS[cls]; if (!x) { missing += cw; continue; } for (let k = 0; k < x.length; k++) f[k] += cw * x[k]; w += cw; }
  return { labels, frequencies: Array.from(f, (x) => +(x / Math.max(1e-12, w)).toFixed(4)), combosWithoutRows: missing };
}
/** 0.33: shared preflop SNAPSHOT (src/preflop-snapshot.js, format version 2) built directly from a class-keyed (Mode B169) state:
 *  same state table and lookup contract as the 0.32 snapshot, rows keyed by class (u16 0-168) with a per-seat range-index -> class map
 *  in the header. Two streaming passes over the state (count, then fill); values are normalised exactly like the 0.32 builder
 *  (max(0, a) / sum, 1/k when the sum is 0). o: studyId, shared, sourceSha256. */
function buildClassSnapshot(stateFile, spec, EM, o = {}) {
  const PS = require('./preflop-snapshot.js'), fd = fs.openSync(stateFile, 'r'), size = fs.fstatSync(fd).size;
  try {
    const rd = (pos, len) => { const b = Buffer.allocUnsafe(len); let got = 0; while (got < len) { const n = fs.readSync(fd, b, got, len - got, pos + got); if (n <= 0) throw new Error('truncated state'); got += n; } return b; };
    const top = rd(0, 12); if (top.toString('latin1', 0, 5) !== 'EMMW4') throw new Error('not an EMMW4 state');
    const hl = top.readUInt32LE(8), head = JSON.parse(rd(12, hl).toString('utf8')); if (head.rowKeys !== 1) throw new Error('Not a class-keyed state (use src/preflop-snapshot.js build for exact layouts)');
    let p = 12 + hl; const sc = rd(p, 4).readUInt32LE(0); p += 4; const tb = rd(p, sc * 9); p += sc * 9;
    const sp = new Uint32Array(sc), sl = new Uint8Array(sc), kd = new Uint8Array(sc), ac = new Uint8Array(sc), ln = new Uint8Array(sc), kk = new Uint8Array(sc);
    for (let i = 0; i < sc; i++) { const q = i * 9; sp[i] = tb.readUInt32LE(q); sl[i] = tb[q + 4]; kd[i] = tb[q + 5]; ac[i] = tb[q + 6]; ln[i] = tb[q + 7]; kk[i] = tb[q + 8]; }
    const id = new Int32Array(sc).fill(-1), states = []; for (let s = 0; s < sc; s++) if (ln[s] === 0 && (s === 0 || ln[sp[s]] === 0)) { id[s] = states.length; states.push(s); }
    const n = states.length, rowCountA = new Uint32Array(n), rowsStart = p + 4, rowCount = rd(p, 4).readUInt32LE(0);
    const stream = (fn) => { const CH = 8 << 20, buf = Buffer.allocUnsafe(CH); let carry = Buffer.alloc(0), pos = rowsStart, seen = 0;
      while (seen < rowCount) { const m = fs.readSync(fd, buf, 0, Math.min(CH, size - pos), pos); if (m <= 0) throw new Error('truncated rows'); pos += m; const data = carry.length ? Buffer.concat([carry, buf.subarray(0, m)]) : buf.subarray(0, m); let q = 0;
        while (seen < rowCount) { if (q + 6 > data.length) break; const kl = data.readUInt16LE(q + 4); if (q + 7 + kl > data.length) break; const k = data[q + 6 + kl], L = 7 + kl + 16 * k; if (q + L > data.length) break;
          const st = data.readUInt32LE(q); if (id[st] >= 0 && kd[st] === 0) fn(id[st], Number(data.toString('latin1', q + 6, q + 6 + kl)), k, data, q + 7 + kl + 8 * k); q += L; seen++; }
        carry = Buffer.from(data.subarray(q)); } };
    stream((i) => { rowCountA[i]++; });
    const rowStart = new Uint32Array(n), valueStart = new Uint32Array(n); let rows = 0, vals = 0;
    for (let i = 0; i < n; i++) { rowStart[i] = rows; valueStart[i] = vals; rows += rowCountA[i]; vals += rowCountA[i] * kk[states[i]]; }
    const keys = new Uint16Array(rows), values = new Float64Array(vals), fill = new Uint32Array(n);
    stream((i, cls, k, data, off) => { if (!(cls >= 0 && cls < 169)) throw new Error('Unexpected preflop key ' + cls); const r = rowStart[i] + fill[i], v = valueStart[i] + fill[i] * k; fill[i]++; keys[r] = cls; let t = 0; for (let a = 0; a < k; a++) { const x = Math.max(0, data.readDoubleLE(off + 8 * a)); values[v + a] = x; t += x; } for (let a = 0; a < k; a++) values[v + a] = t ? values[v + a] / t : 1 / k; });
    // sort each state's rows by class (keys and values together)
    for (let i = 0; i < n; i++) { const c = rowCountA[i]; if (c < 2) continue; const k = kk[states[i]], r0 = rowStart[i], v0 = valueStart[i], ord = Array.from({ length: c }, (_, j) => j).sort((a, b) => keys[r0 + a] - keys[r0 + b]); const ks = ord.map((j) => keys[r0 + j]), vs = ord.flatMap((j) => Array.from(values.subarray(v0 + j * k, v0 + j * k + k))); keys.set(ks, r0); values.set(vs, v0); }
    const parent = new Uint32Array(n), slot = new Uint8Array(n), actor = new Uint8Array(n), kind = new Uint8Array(n), K = new Uint8Array(n);
    for (let i = 0; i < n; i++) { const s = states[i]; parent[i] = s === 0 ? 0xffffffff : id[sp[s]]; slot[i] = sl[s]; actor[i] = ac[s]; kind[i] = kd[s]; K[i] = kk[s]; }
    const cs = new Uint32Array(n + 1); for (let i = 1; i < n; i++) cs[parent[i] + 1]++; for (let i = 0; i < n; i++) cs[i + 1] += cs[i];
    const cl = new Uint32Array(Math.max(1, cs[n])), f2 = cs.slice(0, n); for (let i = 1; i < n; i++) cl[f2[parent[i]]++] = i;
    const classOfRangeIndex = spec.hands.map((rows2) => rows2.map((r) => EM.CLS[r[0]]));
    const header = { format: 'eightmax-preflop-snapshot', version: PS.VERSION_CLASS, keyedBy: 'class', classOfRangeIndex, studyId: o.studyId || null, iterations: head.iterations, sourceStateSha256: o.sourceSha256 || null, sourceRowCrc32: head.rowCrc32 || null,
      states: n, rows, values: vals, children: cs[n], createdBy: 'EightMax Test Workbench 0.33', meaning: 'normalised average strategy of every stored PREFLOP information set of a class-keyed (Mode B169) study; a hand answers with its class row', accuracy: 'approximate (compact continuation: check-down)' };
    const tableU32 = 4 * n + (n + 1) + cl.length, bytesU8 = 4 * n;
    return PS.assemble(header, values, [parent, rowStart, rowCountA, valueStart, cs, cl], [slot, actor, kind, K], keys, tableU32, bytesU8, o.shared, PS.VERSION_CLASS);
  } finally { fs.closeSync(fd); }
}
module.exports = { buildClassSnapshot, MODES, NOBET, modeOf, configFor, specFor, gameDefinition, readPreflop, positionCoverage, compareReads, nodeFrequencies, SHORT };
