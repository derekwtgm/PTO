'use strict';
/* EightMax Test Workbench 0.31: body of the dedicated strategy-service thread (see SharedStrategyService in shared-strategy-cache.js).
 * Owns one StrategyLibrary opened with sharedMemory:true. Every record it serves passes the library's full checks (checksum,
 * identity, engine build, completeness) here; the body is decoded once into a SharedArrayBuffer and shared, never copied.
 * Requests arrive on per-client MessagePorts. After posting a reply it raises the client's signal word (Atomics.notify), so a
 * client blocked in Atomics.wait can take the reply synchronously with receiveMessageOnPort() without returning to its event loop.
 * It also maintains the shared DIRECTORY (fingerprints of stored records) so clients can answer misses without a round trip. */
const { parentPort, workerData } = require('node:worker_threads');
const fs = require('node:fs'), path = require('node:path');
const L = require('./strategy-library.js'), D = require('./strategy-directory.js');
const nowMs = () => Number(process.hrtime.bigint()) / 1e6;
const lib = L.StrategyLibrary.open(workerData.dir, { sharedMemory: true, cacheBytes: workerData.cacheBytes || 512 * 1048576, readOnly: !!workerData.readOnly });
const dir = new D.Directory(workerData.directory), stats = { requests: 0, served: 0, misses: 0, refused: 0, sharedBytes: 0, sharedRecords: 0, refreshes: 0, serviceMs: [] }, shared = new Map();
let indexMtime = 0;
function refresh() {
  try { const st = fs.statSync(path.join(workerData.dir, 'index.json')); if (st.mtimeMs === indexMtime) return; indexMtime = st.mtimeMs; } catch (e) { return; }
  for (const e of lib.list()) dir.add(e.fingerprint); dir.bump(); stats.refreshes++;
}
function serve(port, m) {
  const t0 = nowMs(); stats.requests++; let reply;
  const r = lib.get(m.identity, m.fingerprint);
  if (!r.ok) { if (r.code === 'library-miss') stats.misses++; else stats.refused++; reply = { type: 'fetched', id: m.id, ok: false, code: r.code, reason: r.reason }; }
  else {
    const body = r.slot && r.slot.body;
    if (!body || !(body.buffer instanceof SharedArrayBuffer)) reply = { type: 'fetched', id: m.id, ok: false, code: 'not-shared', reason: 'Record not held in shared memory' };
    else { if (!shared.has(m.fingerprint)) { shared.set(m.fingerprint, body.byteLength); stats.sharedBytes += body.byteLength; stats.sharedRecords++; } stats.served++; reply = { type: 'fetched', id: m.id, ok: true, sab: body.buffer, byteOffset: body.byteOffset, byteLength: body.byteLength, header: r.header, diskMs: r.timings.diskMs }; }
  }
  const ms = nowMs() - t0; stats.serviceMs.push(ms); if (stats.serviceMs.length > 20000) stats.serviceMs.splice(0, 10000); reply.serviceMs = ms;
  port.postMessage(reply);
  if (m.sig) { const s = new Int32Array(m.sig); Atomics.store(s, 0, m.id); Atomics.notify(s, 0); }
}
function attach(port) { port.on('message', (m) => { if (!m) return; if (m.type === 'fetch') serve(port, m); else if (m.type === 'refresh') { refresh(); if (m.sig) { const s = new Int32Array(m.sig); Atomics.store(s, 0, m.id); Atomics.notify(s, 0); } } }); }
parentPort.on('message', (m) => {
  if (m.type === 'port') attach(m.port);
  else if (m.type === 'prewarm') { let n = 0; for (const e of lib.list()) { try { const rec = L.decodeRecord(fs.readFileSync(lib.file(e.fingerprint)), e.fingerprint, true); if (lib.get(rec.header.identity, e.fingerprint).ok) n++; } catch (err) { /* damaged record: library refuses it on request */ } } refresh(); parentPort.postMessage({ type: 'prewarmed', id: m.id, records: n }); }
  else if (m.type === 'refresh') { refresh(); parentPort.postMessage({ type: 'refreshed', id: m.id }); }
  else if (m.type === 'info') { const a = stats.serviceMs.slice().sort((x, y) => x - y), p = (q) => (a.length ? +a[Math.min(a.length - 1, Math.ceil(q * a.length) - 1)].toFixed(3) : null); parentPort.postMessage({ type: 'info', id: m.id, info: { ...stats, serviceMs: undefined, serviceMsP50: p(0.5), serviceMsP95: p(0.95), serviceMsP99: p(0.99), cacheBytes: lib.cacheUsed, cacheEntries: lib.cache.size, directoryEntries: dir.count() } }); }
  else if (m.type === 'close') { lib.close(); parentPort.postMessage({ type: 'closed', id: m.id }); }
});
refresh(); const poll = setInterval(refresh, workerData.refreshMs || 500); poll.unref();
parentPort.postMessage({ type: 'ready' });
