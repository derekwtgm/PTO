/* EightMax Test Workbench 0.31 - pure view functions for the "Strategy quality" and "Opponent ranges" panels (no DOM; unit-tested).
 * Wording rule: plain language first, the technical measure second, and never "GTO" for anything that was not validated. */
(function (root, factory) { if (typeof module === 'object' && module.exports) module.exports = factory(); else root.WorkbenchResearchView = factory(); })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const STATUS_TEXT = { validated: 'Validated', estimated: 'Estimated', 'restricted-evaluation': 'Restricted check', unverified: 'Unverified', 'failed-quality-check': 'Failed quality check' };
  const STATUS_HELP = {
    validated: 'An exact accuracy check of this specific game passed the selected target.',
    estimated: 'Accuracy was estimated from samples; the uncertainty is shown.',
    'restricted-evaluation': 'Checked only against limited responses or inside an approximation.',
    unverified: 'Not enough evidence about its accuracy. It may be used only in clearly labelled simulation experiments.',
    'failed-quality-check': 'Measured accuracy is worse than the target. It is refused for decisions.',
  };
  const pct = (x) => (x === null || x === undefined || !Number.isFinite(x) ? '—' : x.toFixed(x < 0.1 ? 3 : 2) + '% of the pot');
  /** Quality summary (GET /api/library/quality) -> headline, count rows, table rows. */
  function qualityView(sum) {
    if (!sum || sum.available === false) return { headline: 'No accuracy check has been run yet', detail: (sum && sum.message) || 'Press Validate Strategies.', counts: [], rows: [], policy: null };
    const by = sum.byStatus || {}, total = sum.records || 0, ok = by.validated || 0;
    const counts = Object.keys(STATUS_TEXT).map((k) => [STATUS_TEXT[k], by[k] || 0, STATUS_HELP[k]]);
    const rows = (sum.rows || []).slice(0, 200).map((r) => ({ situation: r.situation, status: STATUS_TEXT[r.status] || r.status, statusKey: r.status, accuracy: r.measureKind ? r.measureKind + ' ' + pct(r.measurePctPot) : 'not measurable from the record', solver: 'EightMax ' + (r.solver || '?') + (r.trainer ? ' · ' + r.trainer : ''), updates: r.updates === undefined || r.updates === null ? '—' : Number(r.updates).toLocaleString('en-US'), rangeModel: r.rangeModel || '—', players: r.players, checked: r.evaluatedAt ? String(r.evaluatedAt).slice(0, 10) : '—', why: r.reason || '' }));
    const p = sum.policy || {};
    return { headline: ok + ' of ' + total + ' stored strategies are validated', detail: 'Target "' + (p.name || '?') + '": heads-up ≤ ' + (p.headsUp ? p.headsUp.maxExploitabilityPctPot : '?') + '% of the pot (exploitability), 3+ players ≤ ' + (p.multiway ? p.multiway.maxNashConvPctPot : '?') + '% (NashConv, a different measure). Checked ' + String(sum.writtenAt || '').slice(0, 16).replace('T', ' ') + '.', counts, rows, policy: p, note: sum.note || '' };
  }
  const PROV = { 'derived-validated-strategy': 'From the betting, using a validated strategy', 'derived-approximate-strategy': 'From the betting, using a strategy that is NOT validated', 'observed-tendencies': 'Estimated from this player\'s habits', manual: 'Entered by hand', 'assumed-any-two-cards': 'Assumption: any two cards', unknown: 'Unknown (not enough information)' };
  /** One hand of range views (GET /api/ranges/latest -> hands[i]) -> per-seat cards for display. */
  function rangeHandView(h) {
    if (!h || !h.seats) return { title: 'No hand selected', seats: [] };
    const seats = Object.entries(h.seats).map(([seat, s]) => ({ seat: +seat, source: PROV[s.provenance] || s.provenance, provenance: s.provenance, combos: s.combos, unsupported: (s.unsupported || []).reduce((a, u) => a + u.massShare, 0),
      missing: (s.unsupported || []).length ? (s.unsupported || []).map((u) => u.combos + ' hands had no stored strategy at ' + u.event).join('; ') : '', invalid: s.invalid || '',
      top: (s.top || []).slice(0, 12).map((t) => ({ cls: t.cls, share: t.share })), history: (s.history || []).filter((e) => e.kind === 'action').map((e) => ({ street: e.street, action: e.label || e.action, probability: e.actionProbability })) }));
    const streets = Object.keys(h.byStreet || {});
    return { title: 'Table ' + h.table + ', hand ' + h.hand, conditioned: (h.conditionedStreets || []).join(', ') || 'preflop only', streets, seats, notes: (h.notes || []).filter((n) => !/^skip:/.test(n)) };
  }
  /** 13x13 grid (rows = first rank, columns = second; suited above the diagonal) of average combo weight per class, 0..1. */
  function rangeGrid(classSummary) {
    const R = 'AKQJT98765432', g = Array.from({ length: 13 }, () => new Array(13).fill(0)), m = new Map((classSummary || []).map((c) => [c.cls, c.avgWeight === undefined ? c.share : c.avgWeight]));
    let mx = 0; for (const v of m.values()) mx = Math.max(mx, v);
    for (let i = 0; i < 13; i++) for (let j = 0; j < 13; j++) { const a = R[Math.min(i, j)], b = R[Math.max(i, j)], cls = i === j ? a + a : i < j ? a + b + 's' : a + b + 'o'; g[i][j] = mx > 0 ? (m.get(cls) || 0) / mx : 0; }
    return { ranks: R.split(''), grid: g, label: (i, j) => { const a = R[Math.min(i, j)], b = R[Math.max(i, j)]; return i === j ? a + a : i < j ? a + b + 's' : a + b + 'o'; } };
  }
  return { STATUS_TEXT, STATUS_HELP, PROV, qualityView, rangeHandView, rangeGrid, pct };
});
