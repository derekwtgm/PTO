'use strict';
/* EightMax Test Workbench 0.32: compact, immutable, SHAREABLE snapshot of the preflop strategy of a native linked study.
 *
 * Why (measured, docs/0.32-validation-report.md section I): every table worker opened the native state with the lazy reader
 * (src/strategy-store.js). Its index covers the WHOLE linked tree (5.6 million states for the 500,000-update study, about 220 MB of
 * typed arrays) plus a 64 MB row cache, and each of the four workers built its own copy. Decisions and derived ranges only read
 * PREFLOP information sets. This module extracts exactly those, once, into one buffer:
 *
 *   header JSON (study id, iterations, source state SHA-256, counts)
 *   preflop state table   parent (i32), slot (u8), actor (u8), k (u8), rowStart (u32), rowCount (u32), valueStart (u32)
 *   child index           counting-sorted children per state (u32)
 *   keys                  range-row index of every stored row, sorted per state (u16)
 *   values                the NORMALISED average strategy of every row as IEEE-754 doubles, computed exactly like
 *                         StrategyStore.averageAt (max(0, a) / sum, 1/k when the sum is 0) - answers are bit-for-bit identical
 *
 * The buffer can be a SharedArrayBuffer: worker threads receive it through workerData without copying; every view on it is
 * read-only by convention and the snapshot is never written after build (immutable). Integrity: SHA-256 of the body is stored in
 * the header and verified when the file is loaded; workers verify the header fingerprint (study id + body SHA-256) they expect.
 * Binary: "EMPS" | u32 version | u32 headerLen | header JSON | pad to 8 | f64 values | u32 tables | u16 keys
 */
const fs = require('node:fs'), crypto = require('node:crypto');
const VERSION = 1, VERSION_CLASS = 2, MAGIC = [0x45, 0x4d, 0x50, 0x53];
class SnapshotError extends Error { constructor(code, m) { super(m); this.code = code; this.name = 'PreflopSnapshotError'; } }
const ok = (x, code, m) => { if (!x) throw new SnapshotError(code, m); };

/** Build from an open StrategyStore (src/strategy-store.js). o: studyId, sourceSha256, shared (allocate a SharedArrayBuffer). */
function build(store, o = {}) {
  const states = []; const id = new Int32Array(store.stateCount).fill(-1);
  for (let s = 0; s < store.stateCount; s++) if (store.length[s] === 0 && (s === 0 || store.length[store.parent[s]] === 0)) { id[s] = states.length; states.push(s); }
  const n = states.length, parent = new Int32Array(n), slot = new Uint8Array(n), actor = new Uint8Array(n), kind = new Uint8Array(n), K = new Uint8Array(n), rowStart = new Uint32Array(n), rowCount = new Uint32Array(n), valueStart = new Uint32Array(n);
  const keys = [], values = []; let rows = 0, vals = 0;
  for (let i = 0; i < n; i++) {
    const s = states[i]; parent[i] = s === 0 ? -1 : id[store.parent[s]]; slot[i] = store.slot[s]; actor[i] = store.actor[s]; kind[i] = store.kind[s]; K[i] = store.k[s];
    rowStart[i] = rows; valueStart[i] = vals;
    if (store.kind[s] !== 0) continue;
    const m = store.rowsAt(s), list = [];
    for (const [key, row] of m) { const [h, cards] = key.split('|'); if (cards !== '0,0,0,0,0') continue; list.push([+h, row.average]); }
    list.sort((a, b) => a[0] - b[0]);
    for (const [h, avg] of list) { const k = avg.length; ok(k === store.k[s], 'width', 'Row width differs from the state at ' + s); let t = 0; const q = new Float64Array(k); for (let a = 0; a < k; a++) { q[a] = Math.max(0, avg[a]); t += q[a]; } for (let a = 0; a < k; a++) values.push(t ? q[a] / t : 1 / k); keys.push(h); vals += k; }
    rowCount[i] = list.length; rows += list.length;
  }
  // children (counting sort over parents)
  const cs = new Uint32Array(n + 1); for (let i = 1; i < n; i++) cs[parent[i] + 1]++; for (let i = 0; i < n; i++) cs[i + 1] += cs[i];
  const cl = new Uint32Array(Math.max(1, cs[n])), fill = cs.slice(0, n); for (let i = 1; i < n; i++) cl[fill[parent[i]]++] = i;
  const header = { format: 'eightmax-preflop-snapshot', version: VERSION, studyId: o.studyId || null, iterations: store.header.iterations, sourceStateSha256: o.sourceSha256 || null, sourceRowCrc32: store.header.rowCrc32 || null,
    states: n, rows, values: vals, children: cs[n], createdBy: 'EightMax Test Workbench 0.32', meaning: 'normalised average strategy of every stored PREFLOP information set, bit-identical to StrategyStore.averageAt' };
  // tables: parent, rowStart, rowCount, valueStart, childStart(n+1), childList | bytes: slot, actor, kind, k
  const tableU32 = 4 * n + (n + 1) + cl.length, bytesU8 = 4 * n;
  return assemble(header, Float64Array.from(values), [Uint32Array.from(parent, (x) => x >>> 0), rowStart, rowCount, valueStart, cs, cl], [slot, actor, kind, K], Uint16Array.from(keys), tableU32, bytesU8, o.shared);
}
function assemble(header, values, u32parts, u8parts, keys, tableU32, bytesU8, shared, version) {
  const body = (u32s) => { const total = values.byteLength + u32s * 4 + bytesU8 + keys.byteLength; return total; };
  const bodyLen = body(tableU32);
  // body sha over the concatenated payload (computed on a temporary contiguous buffer)
  const payload = new Uint8Array(bodyLen); let o = 0; const put = (ta) => { payload.set(new Uint8Array(ta.buffer, ta.byteOffset, ta.byteLength), o); o += ta.byteLength; };
  put(values); for (const p of u32parts) put(p); for (const p of u8parts) put(p); put(keys);
  header.bodySha256 = crypto.createHash('sha256').update(payload).digest('hex'); header.bodyBytes = bodyLen;
  const ht = Buffer.from(JSON.stringify(header), 'utf8'), head = 12 + ht.length, pad = (8 - (head % 8)) % 8, total = head + pad + bodyLen;
  const buf = shared ? new SharedArrayBuffer(total) : new ArrayBuffer(total), u8 = new Uint8Array(buf);
  u8.set(MAGIC, 0); new DataView(buf).setUint32(4, version || VERSION, true); new DataView(buf).setUint32(8, ht.length, true); u8.set(ht, 12); u8.set(payload, head + pad);
  return buf;
}

/** Copy file bytes into a (Shared)ArrayBuffer and verify the body hash. */
function load(file, o = {}) {
  const b = fs.readFileSync(file), buf = o.shared ? new SharedArrayBuffer(b.length) : new ArrayBuffer(b.length); new Uint8Array(buf).set(b);
  const s = open(buf, { verify: o.verify !== false }); return { buffer: buf, snapshot: s };
}
function save(buf, file) { const tmp = file + '.tmp' + process.pid; fs.writeFileSync(tmp, new Uint8Array(buf)); fs.renameSync(tmp, file); }

/** Read-only view over a snapshot buffer (ArrayBuffer or SharedArrayBuffer). No copy is made. */
function open(buf, o = {}) {
  const u8 = new Uint8Array(buf); ok(u8.length >= 12 && MAGIC.every((m, i) => u8[i] === m), 'bad-magic', 'Not a preflop snapshot');
  const dv = new DataView(buf), ver = dv.getUint32(4, true); ok(ver === VERSION || ver === VERSION_CLASS, 'version', 'Unsupported preflop snapshot version');
  const hl = dv.getUint32(8, true); let header; try { header = JSON.parse(Buffer.from(u8.subarray(12, 12 + hl)).toString('utf8')); } catch (e) { throw new SnapshotError('bad-header', 'Snapshot header is not JSON'); }
  const head = 12 + hl, start = head + ((8 - (head % 8)) % 8); ok(start + header.bodyBytes === u8.length, 'truncated', 'Snapshot size does not match its header');
  if (o.verify) ok(crypto.createHash('sha256').update(u8.subarray(start)).digest('hex') === header.bodySha256, 'checksum', 'Preflop snapshot body is corrupt');
  if (o.expect) { ok(o.expect.bodySha256 === header.bodySha256, 'identity-mismatch', 'Snapshot is not the expected study (body SHA-256 differs)'); if (o.expect.studyId) ok(o.expect.studyId === header.studyId, 'identity-mismatch', 'Snapshot belongs to another study'); }
  const n = header.states; let p = start;
  const values = new Float64Array(buf, p, header.values); p += header.values * 8;
  const u32 = (len) => { const a = new Uint32Array(buf, p, len); p += len * 4; return a; };
  const parent = u32(n), rowStart = u32(n), rowCount = u32(n), valueStart = u32(n), childStart = u32(n + 1), childList = u32(Math.max(1, header.children));
  const u8v = (len) => { const a = new Uint8Array(buf, p, len); p += len; return a; };
  const slot = u8v(n), actor = u8v(n), kind = u8v(n), K = u8v(n), keys = new Uint16Array(buf, p, header.rows);
  return new PreflopSnapshot(header, { values, parent, rowStart, rowCount, valueStart, childStart, childList, slot, actor, kind, K, keys }, buf);
}

class PreflopSnapshot {
  constructor(header, t, buf) { this.header = header; this.t = t; this.buffer = buf;
    // 0.33 (version 2): rows keyed by the 169 hand classes (compact preflop Mode B169); a range index is mapped to its class first
    this.classOf = header.keyedBy === 'class' ? header.classOfRangeIndex.map((a) => Uint8Array.from(a)) : null; this.shared = typeof SharedArrayBuffer !== 'undefined' && buf instanceof SharedArrayBuffer; this.counters = { lookups: 0, misses: 0 }; this.pathCache = new Map(); }
  get iterations() { return this.header.iterations; }
  get bytes() { return this.buffer.byteLength; }
  /** Snapshot state of an action path ("r", "r1", "r120"); null when it is not a preflop path of the study. */
  stateOf(path) {
    if (typeof path !== 'string' || path[0] !== 'r') return null;
    const hit = this.pathCache.get(path); if (hit !== undefined) return hit;
    const t = this.t; let s = 0;
    for (let i = 1; i < path.length; i++) { const c = path[i], sl = c === 'c' ? 7 : c >= '0' && c <= '7' ? +c : -1; if (sl < 0) return null; let next = -1; for (let j = t.childStart[s]; j < t.childStart[s + 1]; j++) { const ch = t.childList[j]; if (t.slot[ch] === sl) { next = ch; break; } } if (next < 0) { this._remember(path, null); return null; } s = next; }
    this._remember(path, s); return s;
  }
  _remember(p, s) { if (this.pathCache.size > 50000) this.pathCache.clear(); this.pathCache.set(p, s); }
  /** Same contract as StrategyStore.averageAt(path, seat, handIndex). */
  averageAt(path, seat, handIndex) {
    this.counters.lookups++; const s = this.stateOf(path), t = this.t; if (s === null || t.kind[s] !== 0 || t.actor[s] !== seat) { this.counters.misses++; return null; }
    let lo = t.rowStart[s], hi = lo + t.rowCount[s] - 1; const k = t.K[s];
    if (this.classOf) { const map = this.classOf[seat]; if (!map || handIndex < 0 || handIndex >= map.length) { this.counters.misses++; return null; } handIndex = map[handIndex]; }
    while (lo <= hi) { const m = (lo + hi) >> 1, x = t.keys[m]; if (x === handIndex) { const off = t.valueStart[s] + (m - t.rowStart[s]) * k; return Float64Array.from(t.values.subarray(off, off + k)); } if (x < handIndex) lo = m + 1; else hi = m - 1; }
    this.counters.misses++; return null;
  }
  coverageAt(path, rangeSize) { const s = this.stateOf(path); if (s === null) return null; return { state: s, rows: this.t.rowCount[s], rangeSize, share: rangeSize ? this.t.rowCount[s] / rangeSize : null }; }
  fingerprint() { return { studyId: this.header.studyId, bodySha256: this.header.bodySha256, iterations: this.header.iterations }; }
  stats() { return { snapshotBytes: this.bytes, shared: this.shared, states: this.header.states, rows: this.header.rows, ...this.counters }; }
}

/** Lookup-only game for TreeStudy over a snapshot (tree shape from the cheap JavaScript game, strategies from the snapshot). */
function snapshotBackedGame(baseGame, prepared, snap) {
  const index = new Map(); prepared.spec.hands.forEach((rows, seat) => index.set(seat, new Map(rows.map((r, i) => [r[0], i]))));
  return {
    view: (steps) => baseGame.view(steps),
    averageAt(path, publicCards, seat, hand) {
      if (publicCards && publicCards.length) throw new SnapshotError('unsupported-street', 'The preflop snapshot covers preflop information sets only');
      const i = index.get(seat) && index.get(seat).get(hand.id); if (i === undefined) return null; return snap.averageAt(path, seat, i);
    },
    get iterations() { return snap.iterations; }, get limitReached() { return false; }, get strategyMiB() { return 0; }, snapshot: snap, lazy: true, shared: snap.shared,
  };
}

module.exports = { VERSION, VERSION_CLASS, assemble, build, open, load, save, PreflopSnapshot, snapshotBackedGame, SnapshotError };
