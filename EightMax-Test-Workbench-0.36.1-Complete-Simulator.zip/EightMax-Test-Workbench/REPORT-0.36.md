# EightMax 0.36 development delivery

**Status: partial development build. The requested “fully operational” acceptance has NOT passed.**

The requested archive name is retained for identification; “Complete-Simulator” in its filename is not a certification of completion. This package adds tested JavaScript/dashboard changes to the verified 0.35.0 Windows baseline. The desktop host, capture helpers, input driver, test-table executable, native solver and bundled Node runtime are reused unchanged. Their embedded versions and historical Windows build evidence remain 0.35.0. No fresh Windows build or Windows execution was performed here.

## Implemented

- An application decision router replaces the undocumented `window.EIGHTMAX_DECIDE` registration requirement. The dashboard connects automatically to the existing loaded preflop study source. Its existing native checkpoint import remains available through **Load / train EightMax study**.
- Strict mode requires engine 5.1/build `7d08acc7eb4577ee`, a matching state binding, and a `within-target` convergence verdict. Missing, incompatible, unvalidated and failed sources are reported and pause input. This is an existing study interface, not new general native or stored-strategy lookup.
- Explicit simulator practice mode produces `SCRIPTED SIMULATOR PRACTICE — non-GTO` decisions. It records the reason a compatible validated study could not be used. It runs only on the bundled controlled fixture, through the same observation, scheduler, input and confirmation path.
- Asynchronous decision callbacks are awaited with a bounded deadline. Stop/pause is checked after awaiting. Pipeline exceptions pause their table. Non-status-strip revalidation compares a fresh reconstructed state before submitting.
- Slow/Normal/Fast presets (600/1,200/2,000 px/s), a 400–2,800 px/s slider, acceleration and duration controls, keyboard timing, curve presets, random seed and variation controls.
- Straight, fixed positive arc and seeded variable positive arc motion use the existing native protocol. Each operation records its chosen arc and PRNG state. Duration estimates conservatively use the maximum configured arc; selected variation cannot shorten the native driver's physical speed/acceleration constraints.
- Saved settings are loaded from the desktop host on reopening; invalid bounds are rejected. Dedicated movement preview buttons use movement commands only. Preview, test click and wager testing are blocked while automated play is running.
- Concurrent Start clicks are guarded, and an old stopped run cannot overwrite the running status of a newer run.
- `START-EIGHTMAX.cmd` and `START-POKER-SIMULATOR.cmd` launch the existing host and a single controlled table, respectively. The dashboard also exposes the existing two-table launch command.

## Baseline and supplied Windows results

The supplied ZIP SHA-256 is `cdf207506cb2aef763198e40716e3d42ef25d382bef25cab8e1c7eb4dfa69b7e`. All **771/771** manifest entries matched before editing. The native solver SHA-256 remains `b3e675bfe2ae231e7d637de07886af6b511905d5225db96fe12ce2c3ccab2f72`.

The supplied `EightMax-Windows-Test-Results-20261120-143555.zip` was read, including its input acceptance, input self-test and simulator benchmark. Its hardware record is i7-13700F, approximately 15.8 GiB RAM, 3840×2160 at 150% scaling.

- Input acceptance: **29/29**.
- Input self-test: **10/11**; move-click reported cursor movement by someone else and registered zero clicks.
- Benchmark's own capacity calculation: **2 stress / 5 realistic tables**, not ten.

| Workload | Tables | Confirmed / attempted | Recorded deadline misses | Double-click detections | Benchmark reliable |
|---|---:|---:|---:|---:|---|
| Stress | 1 | 18/18 | 0 | 0 | Yes |
| Stress | 2 | 36/36 | 0 | 0 | Yes |
| Stress | 5 | 72/72 | 0 | 1 | No |
| Stress | 8 | 69/71 | 2 | 0 | No |
| Stress | 10 | 80/81 | 0 | 1 | No |
| Realistic | 1 | 7/7 | 0 | 0 | Yes |
| Realistic | 2 | 14/14 | 0 | 0 | Yes |
| Realistic | 5 | 35/35 | 0 | 0 | Yes |
| Realistic | 8 | 49/51 | 1 | 0 | No |
| Realistic | 10 | 58/59 | 0 | 0 | No |

Not every unconfirmed attempt is classified as a deadline miss. These are the report's actual fields. The double-click guard already exists in 0.35 source, yet the supplied benchmark still reports detections. No new root-cause reproduction or Windows fix is claimed. Cursor ownership checks remain enabled.

## Validation performed here

Environment: Linux, Node; no local Windows runtime, Mono compiler, or authenticated `gh` session. Local Chromium exists, but startup fails on the environment's forbidden process-singleton socket. No attempt was made to bypass that restriction.

- The new rendered-image pipeline test completes **three successive hands**, visits preflop/flop/turn/river, and compares every confirmed action's hand, seat, type and raise amount with the independent dealer log. The test uses genuine renderer pixels and the real recognition/state/decision/execution/confirmation modules, with a **fake host/input transport**. It is not Windows SendInput evidence.
- Decision tests cover strict rejection, engine and state mismatches, quality rejection, asynchronous success, explicit fallback provenance and reproducibility.
- Motion tests cover 300 seeded trajectories across three speeds, endpoint accuracy, analytic speed/acceleration bounds, conservative scheduler estimates, invalid configuration and move-only dry run routing.
- DOM logic tests verify saving and reopening speed, seed, curve mode and keyboard timing. These are not a real browser test.
- Existing tests were retained. The initial broad run had **876 tests: 797 passed, 7 failed, 72 skipped**. Two failures were the not-yet-regenerated manifest and new dynamic control IDs; those are corrected and rechecked separately. Five failures were browser-dependent/environment failures. The new real-browser settings test also fails at browser startup in this environment. A green full suite is not claimed.
- Final focused test totals are in `evidence/0.36/final-test-summary.json`; original logs are retained. Historical 0.35 Windows evidence has not been relabelled as 0.36 evidence.

## Outstanding acceptance items

| Requirement | Actual status |
|---|---|
| Full Windows GUI-to-SendInput operation for this package | Unrun; mandatory acceptance remains outstanding |
| Automatic general native CLI and stored pre/postflop strategy lookup | Not implemented; only existing loaded preflop source connected |
| Strict-mode end-to-end play with a quality-validated native strategy | Not demonstrated; default imported/quick studies remain unproven and pause |
| Advancing tournament, eliminations, configurable player count and stakes | Not implemented; bundled dealer still resets stacks for independent hands |
| Random curve direction and explicit maximum sideways deviation in pixels | Not implemented; variation is positive arc magnitude (0–0.25 of distance) |
| Cursor-ownership and unintended double-click fixes | Unresolved; no disabled safety checks or unsupported fix claim |
| Sustained 1/2/5/8/10-table matrix at all speeds/patterns | Not run; no new capacity certified or adaptive capacity limiter added |
| Full first-run setup wizard and verified installation health sequence | Not implemented; documented GUI steps and existing diagnostics remain |
| Separate simulator visual integration | Unverified; calibration controls alone do not establish recognition compatibility |
| Fresh Windows binary compilation, installation, uninstall and rollback | Not performed; baseline components retained |

## Operating the implemented path

Extract to a new folder. Launch `START-EIGHTMAX.cmd`, then `START-POKER-SIMULATOR.cmd`. Open **Simulator controls**, list windows and register **EightMax Test Table 01** through the existing authorization checkboxes. Set and save movement preferences, preview without clicking, then explicitly select **Simulator practice mode** and Start. This is the intended Windows path; it was not run here. Emergency stop remains **Ctrl+Alt+F12**.

The separate simulator is not certified. Do not treat old Windows results, analytic motion tests or mocked input as evidence that the new package satisfies full Windows acceptance.
