@echo off
setlocal
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0windows\Configure-Simulator.ps1" %*
endlocal
