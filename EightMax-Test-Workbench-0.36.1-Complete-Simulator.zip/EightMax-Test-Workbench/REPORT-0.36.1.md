# EightMax Test Workbench 0.36.1 development report

**Release status: DEVELOPMENT — fully operational acceptance has NOT passed.**

This is the highest locally checked source candidate produced from the supplied 0.36.0 archive. The changed Windows host, input driver and test-table sources have not been compiled or executed on Windows in this session. Their bundled executable files remain the baseline binaries. The dashboard deliberately refuses automation with an input driver that lacks the new movement capabilities. This package therefore must not be presented as a ready-to-use, completed Windows 0.36.1 release.

Date: 21 November 2026. Application/source version: `0.36.1-dev`. New assembly source version: `0.36.1.0`. Native solver: EightMax 5.1, build `7d08acc7eb4577ee`.

## A. Archive verification

- Original archive: `EightMax-Test-Workbench-0.36.0-Complete-Simulator.zip`.
- Original ZIP SHA-256: `d4b23c3ab7e34e9a47864d2e2aed5b246f23fdac45139f8a9ea1a003221b0b2a`.
- ZIP integrity check passed. Original archive contained 793 files; all 792 entries in its checksum manifest matched.
- Read `REPORT-0.36.md`, `release-036.json`, and the bundled historical build/test evidence before repairs. A separately named development report and target-PC test-results ZIP were not available among the supplied files; this limits investigation of the reported hardware defects.
- Preserved `native/mwcli.exe` byte-for-byte: SHA-256 `b3e675bfe2ae231e7d637de07886af6b511905d5225db96fe12ce2c3ccab2f72`. Vendored EightMax 5.1 provenance checks pass. No EightMax 5.4 integration or solver mathematics changes.
- Baseline Windows binary identity is not the current source identity. `desktop/COMPONENT-VERSIONS.json` distinguishes historical execution of each exact binary hash from whether it was built from this release's source. Historical evidence is retained with its original labels.

## B. Defect investigation

**The target-PC double-click and cursor-ownership root causes are not proven.** No fresh Windows event stream or supplied target-PC diagnostic archive was available. The changes below address plausible failure paths identified in source; zero unintended double-clicks has not been demonstrated.

The previous spatial click guard could depend on the most recent click location while controls/windows interleaved. The candidate uses conservative global single-click spacing based on the Windows double-click interval plus a margin, and records button-down/up events and operation IDs. This may reduce throughput; no capacity improvement is claimed.

`SendInput` movement is queued. An immediate cursor read can precede application of that movement. The candidate waits up to 50 ms for the commanded position to be observed within 2 px, without resending movement. Unexpected deviation records commanded/observed coordinates, step, DPI and raw-input context. Raw-input manual override remains enabled. Unacknowledged movement stops instead of retrying.

## C. Windows input implementation

Changes are in `desktop/input/Driver.cs`, `Motion.cs`, and the JavaScript driver adapter:

- Signed curvature and maximum sideways deviation are passed to the native planner.
- Quadratic-path coordinate extrema are checked against the virtual desktop before input starts.
- Movement scheduling avoids catch-up bursts after delayed steps.
- Cancellation/emergency-state checks and input-down operations share the held-input lock. Unicode key presses are tracked and released on stop.
- Button holds and key intervals are cancellation-aware. A final rounding correction also checks cancellation under the input lock.
- Input deadlines are checked during an operation, including before a button hold.
- Scheduler estimates reserve the driver's reported click guard; the fallback is conservative.

Authorization, executable binding, window identity, stale/duplicate rejection, focus validation and no blind action retries remain in the existing pipeline. Source review and JavaScript tests are not proof that these C# changes compile or work on Windows. Ctrl+Alt+F12, physical override and cleanup during an active Windows operation remain unverified.

## D. Mouse movement

Existing speed presets remain 600, 1,200 and 2,000 px/s, with custom 400–2,800 px/s. Added left/right fixed curves, independent minimum/maximum random curvature, maximum sideways deviation, and seeded direction/magnitude selection. Settings flow through persisted dashboard configuration, per-action planning and native motion parameters. Preview continues to move without clicking.

Analytic tests cover signed mirror symmetry, deviation caps, speed/acceleration bounds and deterministic random sequences. The same seed reproduces both direction and magnitude. The native planner uses the same signed-arc geometry and conservative duration bounds. Real cursor speed, acceleration, target accuracy, 4K/150% scaling and settings persistence across a Windows application restart have not been measured.

## E. Decision-source integration

Added a bounded host route, `/api/simulator/decision`, and lookup-only worker, `tools/simulator-library-decision.cjs`. It accepts reconstructed public state, checks the preserved native executable hash and actual `--build-id` startup, and queries the existing read-only strategy library. Requests and process lifetime are bounded; shutdown/timeout terminates the worker. The worker does not read the simulator oracle or train strategies inline.

Postflop lookup uses existing library identity/tree/information-set matching and strict quality gates. An accepted result must identify native CPU training, validated quality and `within-target` convergence. Preflop uses an already loaded study, with a native identity probe and native-backend check. Missing, incompatible or unvalidated records are refused.

This is exact supported-record lookup, not universal poker coverage. Existing library identities, range assumptions and restricted trees still determine which flop, turn or river states can match. General linked multi-street coverage has not been demonstrated. No compatible native reference study was trained and executed through Windows in this session. **Successful strict-mode Windows execution is unverified.** Rejection tests do not satisfy that acceptance criterion.

Explicit bundled-fixture practice remains labelled `SCRIPTED SIMULATOR PRACTICE — NON-GTO` and records its true fallback source. It does not constitute a genuine strict-mode action.

## F. Poker simulator

The dealer now enables persistent tournament stacks while preserving independent-hand behavior for other engine callers. Added funded-seat dealer advancement, zero-stack elimination, reduced-player handling, heads-up button/small-blind handling even with vacant seat slots, and terminal tournament detection. Forced ante/blind all-ins can settle and advance without an input event. Chip accounting, side-pot settlement, legal raises and showdown use the existing engine.

A new graphical launcher setup accepts table count, starting stack, small blind, big blind and individual ante. Defaults remain eight players, 25 BB each, 0.5/1 BB blinds and 0.1 BB individual ante. The launcher converts BB to integral chips and validates configuration before launching the dealer. This Windows Forms setup is source-only and unexecuted here.

Independent oracle records include button/blind positions, stacks, awards, eliminations and tournament completion. Normal Workbench decisions continue to consume rendered observations; oracle data remains for grading after actions.

Locally, 100 seeded short-stack tournaments conserved every chip and reached one winner without stack resets. Additional tests cover noncontiguous heads-up seats and ante-only automatic continuation. These are engine/dealer tests, not real Windows GUI proof.

## G. End-to-end Windows testing

**Not executed.** No Windows desktop is available in the local Linux environment. GitHub was connected for `derekwtgm`, but its available connector lacks repository creation. The authorized private-repository creation route requires an authenticated browser session for the existing derekwtgm account. The attempted Google sign-in led to new-account signup instead. A fresh browser check still shows GitHub's sign-in page. No private repository or Windows workflow run was created in this session.

Existing three-complete-hand rendered-screen tests pass using a fake input transport. They exercise recognition/reconstruction/decision/confirmation logic but do not meet the required launcher → dashboard → real capture → visible Windows input demonstration. No fresh Windows screenshots, native mouse/key acknowledgments or Windows oracle-certified hand histories are claimed.

## H. Multi-table results

| Tables | New Windows stress result | New realistic result | Speed/curve matrix |
|---:|---|---|---|
| 1 | Unexecuted | Unexecuted | Unexecuted |
| 2 | Unexecuted | Unexecuted | Unexecuted |
| 5 | Unexecuted | Unexecuted | Unexecuted |
| 8 | Unexecuted | Unexecuted | Unexecuted |
| 10 | Unexecuted | Unexecuted | Unexecuted |

The benchmark accepts speed, pattern, seed, direction and deviation, separates evidence by workload/table count, records completed hands/streets/wagers, and requires attempted/confirmed parity with no rejects, unmatched oracle actions or loop errors for reliability. `Test-0361.ps1 -Matrix` prepares the 3-speed × 3-pattern × 5-count matrix with stress and realistic workloads.

The user's reported prior two-table stress and five-table realistic results are baseline context, not revalidation. No new sustainable capacity is established. CPU/RAM, queue/travel/confirmation latency, deadlines and double-click outcomes need actual Windows runs.

## I. Regression testing

Final complete local run: **897 tests; 819 passed, 6 failed, 72 skipped; 122.65 seconds**. Log: `evidence/0.36.1/regression-delivery-0361.log`. Five failures could not launch the missing Playwright Chromium binary; `tests/ui.test.cjs` could not launch system Chromium because the environment refused its singleton Unix socket. These are unresolved environment failures, not passing browser checks. The earlier interrupted `regression-final-0361.log` has no completion summary and is not counted as a completed run. No source/version assertion failed in the final complete run.

Baseline full suite: 888 tests, 809 passed, 7 failed, 72 skipped. One failure was caused by placing the active test log inside the checksum-covered baseline; the log was moved out and the manifest test passed on rerun. The other six failures were browser environment failures. Subsequent test logs are written outside the package while tests run.

Interim candidate runs are retained as development history; they include stale-version assertions exposed by the new version and component metadata. Those assertions were updated to distinguish current source from historical binaries and to bind rebuilt-source claims to recorded source hashes. Browser host mocks were updated for the new capability check, without counting mocked capability responses as native verification.

Reproducible commands from the extracted root:

```text
python tools/build.py
python tools/make-components.py
python tools/release-manifest-0361.py
node --test tests/*.test.cjs
```

Use a log destination outside the extracted tree during the run, then copy the completed log into evidence and regenerate the manifest. Python is a developer build tool; normal packaged Windows operation uses bundled runtimes. Skipped tests remain skipped.

## J. Windows release acceptance

Prepared `.github/workflows/windows-0361.yml` for genuine Windows compilation and browser/regression testing, and `RUN-0361-ACCEPTANCE.cmd` for recorded local checks. The build script now records source hashes and application version alongside actual output hashes. No workflow ID, build output or new Windows acceptance evidence exists yet.

The acceptance runner verifies manifest and binary identity before input, then prepares native self-test/input acceptance and optional matrix runs. It deliberately reports fully-operational acceptance as false because it does not implement or establish all mandatory interactive checks. It is not a replacement for the required GUI demonstration.

Installation, uninstallation, a real two-version rollback, orphan-process checks, native strict execution, hotkey/manual override and exact target hardware acceptance are unexecuted. Capture helpers are preserved baseline binaries; their compatibility with rebuilt components must be checked on Windows.

## K. Remaining limitations and next actions

1. Complete GitHub authentication and create the authorized private repository. Upload source and required baseline assets, execute the Windows build, and fix any compiler/runtime failures.
2. Run the browser suite with installed Chromium on Windows; address application failures revealed there. Local missing-browser/sandbox failures cannot be called passes.
3. Demonstrate three consecutive hands through the launchers and graphical dashboard using real capture and input, including exact wager entry. Compare every action with the independent oracle and retain complete traces.
4. Train/load a tractable genuine native reference study meeting strict quality, bind it to an observed simulator state and demonstrate a confirmed strict action. Do not substitute practice output.
5. Diagnose double-click and cursor ownership using actual Windows events; prove zero unintended double-clicks and verify emergency stop/manual override during movement and key/button holds.
6. Complete the multi-table matrix, establish a measured capacity recommendation, and verify the previously reported five-table realistic workload.
7. Validate launcher configuration, tournament progression and reduced-player recognition on Windows, including terminal tournaments. Test Windows settings restart persistence and capture/calibration wizard behavior.
8. Run installation/uninstallation/two-version rollback and target-PC 3840×2160/150% checks; regenerate current evidence, binaries, report and hashes before classifying a completed release.

Separate-simulator compatibility is not established. The new native strategy route is available only after rebuilding the host. The old bundled input executable intentionally fails the dashboard capability gate. This development package is not a no-compilation, fully operational replacement for the requested Windows release.

## L. Final development package

Filename: `EightMax-Test-Workbench-0.36.1-Complete-Simulator.zip` (the requested filename does not imply completion).

The archive contains the application tree, full source changes, unchanged native EightMax 5.1/runtime/baseline Windows assets, developer Windows workflow, tests, actual local logs, this report, remaining-work status, and a regenerated per-file `SHA256SUMS.txt`. The manifest excludes only itself. The outer ZIP checksum is supplied separately to avoid a circular self-hash.

Final packaging checks validate every listed file, ensure manifest coverage, reopen the ZIP and run its CRC integrity check. These checks establish archive integrity, not Windows functionality.
