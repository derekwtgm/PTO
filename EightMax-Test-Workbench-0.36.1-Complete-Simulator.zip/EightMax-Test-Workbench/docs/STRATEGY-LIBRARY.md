# Precomputed strategy library (0.30.0)

## What it is
Version 0.29 trained a new postflop study while a simulated table waited for its decision (0.5–2 s each on the
development CPU), which produced the ~1.5 s worst-worker P95 at ten tables. 0.30 stores every trained postflop
study once, in a persistent library, and the decision path **looks strategies up instead of training them**.

| Mode | What happens on a missing strategy |
|---|---|
| **Decision Mode** (`decision`, default for simulation) | Lookup only. The decision is `unavailable` with code `library-miss`, the exact missing configuration (`missingStrategy`), and the situation is logged in `misses.jsonl` for training. No probabilities are invented. A simulation may then use the labelled scripted policy. |
| **Deadline policy** (`deadline`) | Lookup; trains inline only when the measured median training time for that player count is at most half of the request's remaining deadline and no other inline training is running. Otherwise as Decision Mode. |
| **Study Mode** (`study`) | Lookup; trains inline (no deadline), stores the result, then answers. This is the 0.29 behaviour, now persisted. |

Precomputation (`PRECOMPUTE-STRATEGIES.cmd`, `tools/strategy-library.cjs precompute`) runs separately from the tables.

## Files (default folder `%LOCALAPPDATA%\EightMax-Test-Workbench\StrategyLibrary`, or `EIGHTMAX_STRATEGY_LIBRARY`)
| File | Purpose |
|---|---|
| `LIBRARY.json` | format/version marker and engine build |
| `records/<fp[0:2]>/<fp>.emsl` | one immutable record per exact strategy identity |
| `index.json` | catalogue; rebuilt from the records when missing or damaged (never trusted for correctness) |
| `misses.jsonl` | situations asked for but not stored (frequency data for training) |
| `queue.json`, `work/` | precompute queue and per-job checkpoints |
| `status.json` | written by the tool; read by the dashboard through the desktop host |
| `quarantine/` | records that failed verification during recovery (never used) |

## Strategy identity (no silent substitution)
The fingerprint is SHA-256 over a canonical JSON identity containing: engine version and build, rules (variant, table
seats, small blind, big blind, ante, chip unit), street, board, player count, stacks behind of every live player in
action order, pot, effective stack, SPR, a statement of how prior history is summarised, the range model name and every
range text, the action tree (bet sizes, raise sizes, maximum bets per street), the abstraction (exact cards, external-
sampling MCCFR, linear weighting, regret matching, sampled private deals) and the training settings (updates, threads,
trainer, seed policy). Table number, hand number and hole cards are **not** part of it, so one study serves every table
and hand that reaches that exact situation.

A lookup recomputes the identity from the live table and compares **the whole stored identity**, not just the hash.
Any difference (one chip of stack, a board card, a tree size, the engine build) is a different study.

The only transformation is **suit isomorphism**: when no range names specific suits, relabelling suits maps a game onto
an identical game, so the board is stored in a canonical form and the hero's cards are relabelled with the same
permutation (reported in the decision as `isomorphism`). This is exact, not an approximation. 1,755 canonical flops
replace 22,100 dealt flops. Bucketing, board similarity, stack rounding and bet-size translation are **not** done by the
library.

## Record format and integrity
`"EMSL" | u32 version | u32 headerLen | header JSON | gzip(street snapshot)`. The header holds the identity, fingerprint,
payload sizes and SHA-256 of the compressed and raw payload, training metadata and the convergence verdict.
Every load checks: magic, version, fingerprint = SHA-256(identity) = file name, payload checksum, decompressed size,
snapshot structure, engine build, identity equality and status `complete`. Failures are refusals with codes
(`checksum`, `truncated`, `fingerprint-mismatch`, `identity-mismatch`, `engine-mismatch`, `not-complete`).

**Snapshot:** a full native state for one postflop study is 5–20 MB and importing it took 0.3–1.6 s (longer than training),
so the library stores only the street that the study answers: every decision node (seat, pot, stacks behind, live flags,
menu) and, for each stored hand, the engine's average strategy as IEEE-754 doubles copied from `averageAt()`. A snapshot
answers bit-for-bit like the trained game (tested on every node and row), and terminal geometry is kept for exact evaluation.

**Writes are transactional:** record → temporary file, `fsync`, atomic rename; then the index under an exclusive
`write.lock` (a lock left by a dead process is detected and taken over). An interrupted write leaves a temporary file that
the next open removes; a record written before a crash but missing from the index is re-indexed; a damaged index is rebuilt;
a damaged record is quarantined.

**Concurrency:** records are immutable, so readers need no lock. Inside one process a shared host (`src/shared-strategy-cache.js`)
loads each record once into a `SharedArrayBuffer` and table worker threads read that memory without copying it.

## Cache and memory
Per-process LRU cache with a byte budget (default 256 MiB, changeable at run time; entries larger than the budget are
used but not cached), hit/miss/eviction counters. `planResources()` reads total and free RAM at run time (it never assumes
16 GB is free) and reserves memory for Windows and other programs (max(3 GiB, 20 %)), the desktop host, image workers and
solver workers before sizing the cache and the number of concurrent training jobs.

## Precomputation
`src/precompute.js`: persistent priority queue (priority = observed miss count, or a catalogue priority), de-duplication,
already-stored detection, concurrency limit, per-job memory budget, free-memory reserve, an optional `pressure()` hook so the
decision workload can pause new training, cancellation of queued and running jobs, chunked native training with a
checkpoint after every chunk (an interrupted job resumes from the last chunk; the result is bit-identical to an
uninterrupted run), and optional worker-thread execution (each job's import/export runs on its own thread).
A job is stored only when the full update count trained, the snapshot exported and decoded, and the record committed.
Memory-limited, cancelled, failed and interrupted jobs are never stored. **Completed is not converged:** records carry
`convergence: unproven` unless a measurement is attached.

Commands (`RUN-TOOL.cmd tools\strategy-library.cjs <command>` or the `.cmd` files):
`status`, `verify`, `recover`, `misses`, `list`, `simulate` (record situations), `precompute [--from-misses=N]`,
`catalog --players= --pot= --stacks=` (all 1,755 canonical flops of one configuration), `export --out=`, `import --in=`,
`cancel --job=all`.

## 0.30 range model and tree profile (model assumptions)
* Range model `any-two-cards-v1`: every live player holds any two cards. 0.29 added the hero's own hand to a fixed range,
  which made every study unique to one hand and impossible to reuse. With the 0.29 range, 29 of 42 postflop decisions in a
  60-hand simulation were "hand not in range"; with any-two-cards, 23 of 24 were answered. It is an uninformative model,
  not an observed or equilibrium range. Deriving ranges from the preflop study is a 1.0 item.
* Tree profile: 2–3 players keep the 0.29 menus; 4 players one bet size (50 %) with up to two bets; 5–6 players one size
  and one bet per street. Measured on a 5-way flop: 1,305 nodes with the 0.29 menus versus 80 with the compact profile.
* 20,000 updates per postflop study.

## Limits
* Exact boards make postflop coverage of unseen hands depend on precomputation volume. Flops can be catalogued completely
  for the most frequent configurations (1,755 studies each); turns (≈86,000 per configuration) and rivers cannot.
* At most 6 live players postflop; players already all-in at the start of a street are not mapped (side-pot trees).
* Off-tree bet sizes are unavailable (no translation in the library).
* Nothing here proves equilibrium play for the full game; see `reports/0.30-math-validation.json` for what is measured.
