# Opponent ranges (0.31)

0.30 modelled every live player postflop with **any two cards** (`any-two-cards-v1`). 0.31 adds ranges derived from the betting
(`src/range-engine.js`, `src/range-model.js`). The application never claims to know hidden cards: a derived range is "the
hands a player following the stored strategy could hold, weighted by how likely that strategy made the observed actions".

## Representation
A weight for each of the 1,326 two-card combinations, in EightMax 5.1's own order (verified combo-for-combo in
tests/range-engine-031). Weights are relative; `normalized()` gives probabilities. Ranges reach the solver as EightMax range text
(scaled to a maximum of 1, rounded to a quantum of 0.02; the dropped mass and the largest rounding error are reported with every
decision).

## Updates
* **Action conditioning (Bayes).** If a player follows strategy σ, after action *a* at node *I* the posterior weight of combo *h* is
  `w'(h) = w(h) · σ(a | I, h)` (the normalising constant cancels). Applied to each of that player's actions, this is exact Bayes for
  "the player plays σ" — and only as good as σ.
* **Preflop**: σ is the eight-handed linked preflop study (the same study the simulator plays from). Suits are symmetric before
  the flop, so the likelihood of a hand class is the mean over its stored combinations (also removes sampling noise).
* **Flop → turn → river continuity**: at the start of the turn the flop range is conditioned on each player's flop actions with
  the stored flop strategy that was used for this hand's flop decisions (including the suit permutation of a canonical board);
  likewise turn → river. If no stored strategy was used on a street, the range is carried forward **unconditioned** and every
  decision says so.
* **Card removal**: board cards and cards known to the viewer get weight 0 (mass removed is recorded). Folded players' cards are
  unknown, never removed. Ranges sent to a study do not remove the hero's cards (the engine deals every player jointly from the
  ranges and blocks per deal).
* **Multiway**: one range per seat; only that seat's own actions condition it; folded players leave the live set; all-in players
  stay in the pot without further conditioning.

## Missing information is reported, never invented
A combination without a stored strategy row at a node gets likelihood "unknown": it keeps its prior weight and is counted as
*unsupported*. An observed action with zero probability for every remaining combination marks the range **invalid** (the prior is
kept and flagged). Support classes per seat: `supported`, `partially-supported`, `insufficient` (unsupported share above 25 %),
`unknown`, `invalid`. With an insufficient/unknown/invalid range the model **falls back** to any-two-cards with a FALLBACK warning
(default) or makes the decision unavailable (`fallback: 'unavailable'`).

## Provenance (stated with every range)
`derived-validated-strategy`, `derived-approximate-strategy` (the preflop study is not validated, so preflop-derived ranges are
always this or weaker), `observed-tendencies` (statistical estimate from an opponent's VPIP with a Wilson interval; needs ≥ 30
hands), `manual`, `assumed-any-two-cards`, `unknown`. A range is only as well founded as the weakest strategy used to build it.

## Measured support (reports/0.31-range-support.json)
Preflop lines sampled from the stored strategy (6,000 deals), each distinct line analysed with exactly the decision path's code:

| Preflop study | Flops whose live ranges are all within the 25 % limit | heads-up | 3-way | 4-way | 5-way |
|---|---|---|---|---|---|
| 500,000 updates (0.30 benchmark setting) | **5.0 %** | 7.6 % | 6.5 % | 3.1 % | 0 % |
| 2,000,000 updates | **53.7 %** | 66.2 % | 55.3 % | 44.7 % | 21.9 % |

The derived model therefore uses a **2,000,000-update** preflop study by default (about 4.5 minutes on 3 threads of the
development machine, trained once and cached). More updates would raise support further; the remaining fallbacks are labelled.

## Identity and reuse
The identity of a study records the range texts and the model name (`preflop-line-v1[q=0.02]`, `street-conditioned-v1[q=0.02]`,
or `any-two-cards-v1`). Preflop-line ranges depend only on the preflop line, so every flop of the same line shares them;
street-conditioned ranges depend on the earlier streets' boards and actions and are rarely shared — realistic ranges reduce exact
reuse, which the coverage report measures rather than hides.

## Display
Dashboard → **Opponent ranges**: starting and action-conditioned ranges per seat (13×13 grid), the actions that changed them with
the probability each action had, assumptions, missing information. `VIEW-OPPONENT-RANGES.cmd` plays simulated hands and saves the
views; the **range calculator** works in any browser and compares a range with any-two-cards.
