# Windows Graphics Capture helper (0.30.0) — RAN IN WINDOWS CI (0.29 BUILD), NOT VERIFIED ON THE TARGET PC

**0.30 status (from evidence/windows-ci-runs.json and desktop/COMPONENT-VERSIONS.json):** the 0.29.0 build of this helper passed its
13-stage self-test on a GitHub-hosted Windows Server 2025 runner (run 44374396745; no GPU, virtual display). 0.30.0 rebuilt it from the
same source with only the version changed; the rebuilt file's own Windows status is whatever COMPONENT-VERSIONS.json records for its
SHA-256. It is NOT VERIFIED ON THE TARGET PC (RTX 4060 Ti, 150 % DPI, GPU-composited windows). The historical text below is kept as written for 0.27-0.28.


`desktop/bin/EightMaxWgc.exe` (source `desktop/wgc/Program.cs`, `SelfTest.cs`, `PngWriter.cs`) is a self-contained .NET 8 Windows
x64 program (no .NET install needed to run it), cross-compiled on Linux with the .NET 8 SDK (target `net8.0-windows10.0.22000.0`,
runs on Windows 10 2004+). **It has NEVER RUN ON WINDOWS.** A successful compile proves the types agree with the Windows SDK
projection; it does not prove that a frame is captured, that the COM vtable slots are right at run time, or what the latency is.

## History merged in 0.29
* 0.27 compiled the 0.26 source for the first time (fixing `IsBorderRequired` / System.Drawing errors), added the bit-exact
  `PngWriter.cs`, the host route inside `CaptureService` (window identity checked BEFORE the helper starts, 8-second limit, no
  fallback) and made the backend **manual-only** (never selected automatically).
* 0.28, built independently from 0.26, compiled the same source, added **persistent sessions** (one capture session for many
  frames), the own-window self-test and the dashboard/acceptance integration.
* 0.29 keeps 0.28's helper and self-test, 0.27's `PngWriter.cs`, `resolution-changed` refusal, `CaptureService.GrabWgc` route,
  manual-only catalogue rule and 22000 projection. The helper is found next to the release root even when the host was compiled
  into `DesktopCache` on first launch.


`desktop/bin/EightMaxWgc.exe` (source `desktop/wgc/Program.cs`, `desktop/wgc/SelfTest.cs`) is a self-contained .NET 8 Windows x64
program (no .NET install needed to run it). It was **cross-compiled on Linux** with the .NET 8 SDK (`EnableWindowsTargeting`) for
0.28.0. It has **never been executed on Windows**; nothing below is a measured Windows result. Run `RUN-WGC-CHECK.cmd` to verify.

## Notes from 0.28
* 0.26 shipped this helper as source only. Compiling it for the first time in 0.28 found two real compile errors: `IsBorderRequired`
  (needs a newer Windows SDK contract than the 19041 target) and `System.Drawing.Bitmap` (not part of .NET 8). Both are gone: the yellow
  capture border is deliberately left on (the operator can always see what is captured) and PNGs are written by a small built-in encoder.
* Persistent session mode: one `GraphicsCaptureSession` for many frames instead of a new session per frame.

## Modes
| Command | What it does |
|---|---|
| `--version`, `--probe` | identity; whether Windows Graphics Capture is supported (exit 3 if not) |
| `--hwnd H [--pid P] --out f.png` | one frame of one operator-selected window (also `--monitor`) |
| `--session --hwnd H --out-dir D [--fps 10] [--frames N] [--duration-ms T] [--queue 4] [--save-every K] [--stall-ms 3000]` | persistent session; one JSON line per event; type `stop` to end |
| `--selftest --out-dir D` | captures its **own** test window only (see stages below) |

Session events: `started`, `frame` (sequence number, `systemRelativeTimeMs` timestamp, `ageMs`, size, blank flag), `resized`
(frame pool recreated at the new size), `minimized` / `restored`, `stalled` (WGC only delivers frames when content changes),
`capture-timeout`, `target-lost` / `target-closed`, `frame-error`, `summary` (delivered, arrived, dropped, throttled, blank, resizes,
age P50/P95, peak working set). The frame queue is bounded (`--queue`, default 4); when full the oldest frame is dropped and counted.
`--fps` throttles accepted frames (configurable capture frequency).

Refusals (never a silent substitute): `target-lost`, `target-identity-changed` (handle reused by another process), `target-minimized`,
`no-frame`, `stale-frame`, `blank-frame`, `unsupported`, `bad-arguments`, `capture-failed`.

## Self-test stages (`RUN-WGC-CHECK.cmd`)
create-window → session-start → first-frame → verify-original-pixels → resize-detected → verify-resized-pixels → refuse-wrong-process →
detect-minimized → recover-after-restore → frame-sequence → repeated-sessions-and-cleanup (5 sessions, working-set growth < 64 MiB) →
detect-closed → refuse-closed-handle. Results: `wgc-selftest-result.json` and `wgc-acceptance.json` in
`%LOCALAPPDATA%\EightMax-Test-Workbench\WgcAcceptance\<run>`.

## Backend identity in the host
The desktop host advertises `windows-graphics-capture` in `captureMethods` only when the helper file exists, and always reports
`windowsGraphicsCaptureVerified:false`. `/api/capture/frame` with `method:"windows-graphics-capture"` runs the helper and returns
`method:"windows-graphics-capture"` — or its refusal. It never falls back to PrintWindow/BitBlt. PrintWindow and BitBlt remain the
default backends. The capture catalogue (`src/capture-manager.js`) lists WGC as implemented with verification `windows-unrun`; no
shipped platform profile selects it.

## Safety
Documented APIs only (Windows.Graphics.Capture, Direct3D 11, DXGI interop, user32). No process memory access, injection, hooks,
input synthesis, hidden windows or network. Only a window or monitor that the operator selected is captured.

## Version identification
`EightMaxWgc.exe --version` prints `0.29.0`, and the Windows file properties show 0.29.0 (read on the GitHub-hosted Windows runner
for the 0.29 candidate). **Correction to 0.28:** 0.28 said a Linux build could not stamp the version resource; the real cause was
that its project file lacked the version metadata. The release check still asks the tool itself (`--version`).
