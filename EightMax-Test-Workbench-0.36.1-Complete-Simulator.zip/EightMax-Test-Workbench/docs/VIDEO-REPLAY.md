# Video replay (0.26)

`src/video-replay.js` decodes a recorded video of a table and feeds the frames to the same recognition code as every other source.

* **Decoder:** FFmpeg, run as a child process (rawvideo RGBA on a pipe). **FFmpeg is not bundled** in this archive — there was no network access to fetch a redistributable Windows build, and bundling one would add its licence terms. Put `ffmpeg.exe` (and optionally `ffprobe.exe`) in `tools\ffmpeg\`, or set `EIGHTMAX_FFMPEG`, or have it on `PATH`. Without it every function fails with `no-ffmpeg` and says what to do.
* **API:** `probe(file)`; `VideoReplay.open(file, {intervalMs, startMs, endMs, maxFrames, scaleWidth})`; `for await (frame of replay.frames())`; `pause()`, `resume()`, `seek(ms)`, `close()`; `recognizeVideo({replay, vision, engine, metrics, truthAt, heroSeatAt})`.
* **Frames** carry `seq` (never reused, also across seeks), `tMs` (nominal sample time = start + n × interval; the raw pipe carries no container timestamps), size and RGBA pixels. A paused replay applies back-pressure to the decoder; memory stays bounded.
* **Scoring:** `MetricsCollector` has a new domain `video-replay`; correct acceptances, false acceptances and rejections are counted separately, and `real-client` stays 0 ("not measured").
* **Verified (Linux, FFmpeg 6 class):** probe, exact pixel round trip through a lossless codec, interval/range/maxFrames, pause/resume without loss, seek with increasing frame ids, truncated-file error, missing-FFmpeg error (tests/video-replay-026.test.cjs, 7 tests). Recognition of 40 frames of the controlled client: lossless 40/40 accepted, H.264 (CRF 14, 4:2:0) 40/40 accepted, **0 false acceptances** in both. That is 40 frames of the application's own renderer — not evidence about any external client or about heavy compression.
* Not done: audio, variable-frame-rate timestamps, GPU decoding, a dashboard video panel (use the API or `tools/` scripts).
