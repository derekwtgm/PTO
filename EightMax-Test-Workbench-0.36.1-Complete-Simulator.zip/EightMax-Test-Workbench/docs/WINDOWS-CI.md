# Windows CI validation (0.29.0)

0.29 is the first release whose Windows parts were **executed on Windows**: on GitHub-hosted runners (`windows-latest` =
Windows Server 2025 Datacenter 10.0.26100, Windows PowerShell 5.1.26100, .NET Framework 4.8.1, 2 cores / 4 threads AMD EPYC,
16 GB RAM, Hyper-V virtual display 1024×768 at 100 %, no GPU, interactive desktop session, no third-party security software).

## How it works
Branch `claude/workbench-0.29-windows-ci` of the project repository holds only `candidate/EightMax-Test-Workbench-*.zip` (+ its
SHA-256), `ci/ci.ps1` and the workflow. The job verifies the ZIP checksum, extracts it, smoke-runs every executable, runs
`windows\Test-Release.ps1 -IncludeInstall` (integrity, PowerShell 5.1 parse, capture, WGC, desktop host + native solver,
host capture sessions, orphan check, hardware, install / rollback / uninstall), the Node regression suite with the bundled
`runtime\node\node.exe`, and the results collector, and prints every report into the job log.

## What the runner found (all fixed in 0.29)
| Run | Finding |
|---|---|
| ci1 | **HTTP 400 root cause**: `Method not found: String.Split(Char, StringSplitOptions)` (Mono class library vs .NET Framework) |
| ci1 | capture self-test window invisible: a hidden STARTUPINFO (0.28 `-WindowStyle Hidden`) is applied to the first `ShowWindow` |
| ci1 | `build.py` wrote CRLF on Windows; Playwright test had no skip; shell-script stubs run on Windows; collector packed shipped reports |
| ci3 | installer: `$uninstall=` assigned a string to the `[switch]$Uninstall` parameter (case-insensitive names) |
| ci3 | native runner: `-isnot [pscustomobject]` is always false for ConvertFrom-Json values in 5.1 → "Query path differs" |
| ci4 | native runner / installer: `[IO.File]::Replace(a,b,$null)` → `$null` becomes "" → "path is not of a legal form" |
| ci5 | native runner: `@($genericList)` → "Argument types do not match" after training |
| ci6 | `Invoke-EmTool` timeout killed only the top process; its child kept the log open (now kills the process tree) |
| ci7 | Test-Desktop's own host-capture test window was hidden by the same STARTUPINFO rule |
| ci8 | **deadlock**: the host's PrintWindow sent WM_PRINT to the test script's thread while that thread waited for the host's HTTP reply; the test window now runs in its own process (`windows\Capture-TestWindow.ps1`) |

Each has a regression test (`tests/netfx-029`, `tests/powershell-029`, `tests/windows-repairs-028`, `tests/capture-029`).

## Result on the final candidate (ci9, run 44374396745)
`RUN-RELEASE-ACCEPTANCE` (Test-Release.ps1 -IncludeInstall): **PASSED, 81 passed, 0 failed, 0 skipped**, every critical criterion
PASS, including the 0.29 criterion "Persistent capture session through the host": PrintWindow frame 480×300 of a test window owned
by another process; Windows Graphics Capture: 4 frames through ONE session (frameIds 1,1,2,2: the duplicate frames are correctly
marked not-fresh), first frame 393 ms; session close ends the helper; closing the window gives `target-lost`.
Node regression suite on Windows with the bundled node.exe: **704 tests, 679 pass, 0 fail, 25 skipped** (skips: Linux-only Mono /
.NET-SDK compile tests, shell-script stubs, Playwright UI, which is not installed on the runner).
The released ZIP differs from the ci9 candidate only in documentation (CHANGELOG, READ-ME-FIRST, reports, docs), the regenerated
manifest and component file; executables and scripts are byte-identical (compare `SHA256SUMS.txt`).

## What it cannot show
Not the target PC: no Windows 11 Home, no 3840×2160 @ 150 % scaling, no RTX 4060 Ti / GPU, no multi-monitor, no third-party
antivirus, no real poker client. Capture ran on a 1024×768 virtual display. Performance numbers from a 2-core runner are not
target-hardware numbers. RUN-RELEASE-ACCEPTANCE.cmd on the target PC remains the final check.
