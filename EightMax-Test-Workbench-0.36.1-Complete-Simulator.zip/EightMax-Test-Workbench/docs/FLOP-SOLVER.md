# Restricted heads-up flop solver (0.33)

Code: `src/flop-solver.js` (engine), `src/flop-solver-worker.js` (worker threads), `tools/flop-solver-benchmark-033.cjs`,
`RUN-FLOP-SOLVER-CHECK.cmd`. Report: `reports/0.33-flop-solver-benchmark.json`. Tests: `tests/flop-033.test.cjs`.

## Game (identical to the 0.32 multi-street evaluator's)
Heads-up postflop game of a study: starting flop, two weighted ranges (joint deal with card removal, weight = product of combination
weights), the study's betting menus on flop, turn and river (sizes, raise caps, all-in), every turn card and every river card dealt
uniformly from the cards not on the board and not held by either player, chip utility relative to the start of the flop (the starting
pot is common money). An all-in before the river is a terminal valued by the exact average over every remaining runout. **No sampling
and no abstraction of cards or boards**: every board is solved separately (suit isomorphism was investigated but not used: it is exact
only when both ranges are suit-symmetric and the board has suit symmetry, which most flops - e.g. rainbow boards with three distinct
suits - do not have; using it elsewhere would change the game).

## Algorithm
Two-player CFR+ (alternating updates, regret matching+, linear averaging with weight t) over the full tree with chance enumeration -
the same algorithm as 0.32's `fast-multistreet.cfrPlus`, re-engineered for flops:
* regret and average tables are flat `Float64Array`s per (decision node, public-card context): 1 flop context, 52 turn slots,
  52 x 52 river slots, allocated lazily per node;
* the average strategy is accumulated during the regret traversal (no second pass);
* each river board's showdown order is computed once (engine evaluator `evalCards`; a test checks that it orders hands exactly like the
  evaluator of the independent check) and reused; showdowns use the O(n) sorted inclusion–exclusion method with exact card removal;
* exact runout-equity matrices for flop and turn all-ins;
* value buffers are pooled (no allocation in the hot path).
**Workers:** turn cards are partitioned over worker threads. Every value is linear in the chance subtrees, so each worker returns its
partial regret increments for the flop decisions; the coordinator adds them in fixed worker order and applies the RM+ floor once.
Turn/river tables belong to exactly one worker; flop terminals and the flop average are counted by worker 0 only. Results are
bit-identical for a given thread count and differ across thread counts only by floating-point summation order (2.7e-4 relative after
40 iterations).
**Controls:** cancellation (`AbortSignal`), a memory estimate refused up front (`maxBytes`), a deadline (stops with the best evaluated
average), checksummed checkpoints (`EMFC`, SHA-256; a resumed run is bit-identical to an uninterrupted one; corrupt or foreign
checkpoints are refused).

## Independent evaluation
The solver never reports its own accuracy. Exploitability comes from `src/fast-multistreet.js` (own traversal, own showdown, own best
response); on a 28 x 28-combination flop the completely separate `src/independent-eval.js` (own betting rules, pots, 7-card evaluator
and best response) gives the same exploitability to **1.3e-15 bb**. The solved strategy is exported as a linked flop→turn→river record
(`.emlk`); re-reading the record and evaluating it again gives the solver's value, and **every record has 0 unvisited continuation rows**
(the 0.32 sampled flop study left 96 % of its river rows unvisited). `strategy-quality.evaluateLinked` therefore classifies such
records exactly (validated only within the policy limit).

## Measured (4-core Linux container, 2 worker threads, other jobs running; stop at 0.5 % of the pot; pot 6 bb)

| Board | Ranges (combos each) | Menu | SPR | Iterations | Exploitability | Wall time | Memory estimate | Linked record |
|---|---|---|---|---|---|---|---|---|
| As7d2h | 46 | 75 % pot, all-in raise, 1 bet/street | 2 | 75 | 0.375 % | 21.7 s | 67 MiB | 27 MB, complete |
| Th9h4c | 54 | same | 2 | 75 | 0.275 % | 24.8 s | 79 MiB | 31 MB, complete |
| 8s8d3c | 56 | same | 2 | 75 | 0.328 % | 24.9 s | 81 MiB | 33 MB, complete |
| As7d2h | 46 | same | 4 | 100 | 0.468 % | 46.1 s | 120 MiB | 48 MB, complete |
| As7d2h | 46 | 33 % or all-in, all-in raise, 2 bets/street | 2 | 150 | 0.394 % | 157.3 s | 299 MiB | 125 MB, complete |
| Th9h4c | 112 | 75 % pot, all-in raise, 1 bet/street | 2 | 50 | 0.427 % | 28.5 s | 163 MiB | 63 MB, complete |
| As7d2h | 169 | same | 2 | 75 | 0.407 % | 58.2 s | 246 MiB | 97 MB, complete |

Per iteration this engine is about 6–7x faster than 0.32's map-based CFR+ on the same 46-combination flop (0.18 s vs 1.2 s; the
first iteration also builds the river tables). The independent evaluation is the slowest part (several seconds each), so the
benchmark evaluates every 25 iterations. Flop solves take tens of seconds to minutes: they are for **precomputation and research**, not
for the decision path (decision deadlines are about 8 s). Any-two-cards ranges (≈1,100 combinations) are not supported in practice.

## Limits
Heads-up only; one starting flop per solve; menus as defined by the study (geometric sizes are evaluated but the multiway evaluator
does not support them); no GPU. CPU parallelism is limited by the number of turn cards per worker and by the single-threaded
evaluator.
