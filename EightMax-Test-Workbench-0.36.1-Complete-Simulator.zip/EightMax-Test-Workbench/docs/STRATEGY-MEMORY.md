# Strategy memory (0.26)

## What was wrong in 0.25 (reproduced, native EightMax 5.1, eight-seat linked preflop study)
| Observation | Evidence |
| --- | --- |
| A native run that fills its memory budget **stops early and exits with status 0** (`limitReached: true`). 0.25 never read the flag. | 250,000 updates at 256 MiB: stopped at **67,273 updates**, exit 0, 5.8 s. The shorter study was then used as if it had 250,000. |
| The budget was a constant (256) at every call site. | `A.nativeJob` (`memoryMiB:256`), `nativeTrainer`, `solver-factory` (`budgetMiB:256`). |
| The adapter accepted 8–1024 MiB for the JavaScript engine, which itself refuses more than 256 MiB. | `prepare()` at 1024 → engine error "must be between 1 and 256 MiB". |
| A trained native state was copied entirely into the Node heap. | 183 MiB state (250,000 updates): Node RSS **1.1 GB**, then "Strategy memory budget reached" at the 256 MiB cap. |

The native engine itself had no such ceiling: 250,000 updates at 1 GiB completed (peak RSS 542 MiB); 1,000,000 updates at 2 GiB completed (table 1,396 MiB, peak RSS 1,625 MiB, 110 s on 2 threads).

## What 0.26 does
* `src/strategy-budget.js` — **budget planner** (pure; also runs in the dashboard). Profiles 256 MiB, 512 MiB, 1, 2, 4 GiB are permitted only if budget + 128 MiB scratch + host (768 MiB) + a Windows reserve (max(3 GiB, 20 % of RAM)) fit in installed RAM **and** in the RAM that is free now. Out-of-range, fractional and unsafe requests are refused with a code. `interpretNativeRun` classifies a run as `complete`, `memory-limited`, `cancelled` or `invalid` — **a memory-limited run is never success**.
* `src/strategy-store.js` — **lazy, streaming, bounded reader** for native EMMW4 states. One chunked pass verifies the CRC32 and the tree table and indexes where each preflop information set's rows are; afterwards a lookup reads only that node (~0.5 ms) through a byte-bounded LRU cache. Resident memory = index + cache, not the state. Results are identical to a full `importNative` (9,600 compared lookups, 0 differences; unstored information sets agree too). Measured: 250,000-update state (183 MiB) → ~430 MiB process; 1,000,000-update state (594 MiB) → ~340 MiB steady index (peak 550 MiB while indexing).
* `tools/native-training.cjs` — **budgeted, resumable training** in a child process (never blocks the dashboard; cancellable). Writes to a temporary file, verifies it with the reader, then renames atomically, so an interrupted or failed write leaves the previous state intact. `ensureStudy` escalates a memory-limited study to the next *permitted* budget by **resuming** it (not restarting), caches by name/length with a SHA-256 sidecar and rebuilds a damaged cache.
* `tools/train-study.cjs: trainStudyLazy`, `tools/solver-factory.cjs` (`budgetMiB`, default 1024) and `tools/full-hand-scenario.cjs --budget=` use it. `--nolazy` restores the 0.25 import path.
* `src/study-adapter.js`: JavaScript budget now correctly limited to 8–256 MiB; new `nativeMemoryMiB` (64–16384, default 256 = 0.25 behaviour) is carried into the native job. Saved studies and jobs from 0.25 load unchanged.
* Dashboard → Platform workspace → Performance: **Strategy memory** panel (enter installed/free RAM; shows which budgets are allowed and why).

## Compatibility and determinism (measured)
* The native state format is unchanged (EMMW4); no migration is needed. Same inputs → identical bytes.
* `mwcli`'s iteration argument is the number of **additional** updates when a state is resumed (measured; the cumulative target is converted by `trainNative`).
* A study stopped at 128 MiB (31,213 updates) and resumed at 1 GiB to 120,000 updates is **byte-identical** to one uninterrupted 120,000-update run; so is 60,000 + 60,000.
* Corrupt, truncated, trailing-data, wrong-magic and header-damaged states are refused with a code (`checksum`, `truncated`, `bad-header`, `bad-magic`, …); a damaged cache file is rebuilt.

## Limits (not hidden)
* **Node tooling only.** The reader, trainer and scenario tools are Node modules. The Windows host runs native jobs through its own C# path (unchanged, not rebuilt: no compiler here); Node.js is **not bundled** (no network to fetch a Windows build), so these tools are for development/QA machines. The Windows runtime gains the planner panel and the larger `memoryMiB` accepted by the host's existing job validation (32–16384).
* The lazy reader serves **preflop** information sets only (what `PreflopTreeSource` reads). Postflop on-demand studies are small and still loaded into JavaScript.
* Index memory grows with the tree (3.8 M tree states / 3.4 M rows at 250k updates; 8.0 M / 6.5 M runs at 1 M). Four solver workers each hold their own index (no sharing yet).
* A larger budget does not make a strategy better; it only lets the study run longer. Convergence stays `unproven`; nothing is labelled equilibrium or GTO-certified.
* Verified here only on a 2-core, 7.7 GiB Linux container. 4 GiB budgets were **not** exercised (the planner correctly refused them on this machine); behaviour on the target 16 GB / i7 PC is unmeasured.
