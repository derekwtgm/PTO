# EightMax 5.3 — evaluated, NOT adopted as the study engine in 0.27

The supplied `EightMax-Windows-5.3` release (build `55c4fffde6deb9a1`) was checked against the workbench.

* Source difference to the bundled 5.1 (`native/source`): telemetry for deadline observation, the promotion-copy stop check (a cancellation/deadline during a strategy-table promotion is noticed within ~4,096 slots instead of after the copy), and the new `--study` decision-study command. `mw.cpp`, `mw.h`, `mwcli.cpp`, `coverage.hpp`, `action_ev.hpp`, `ev_control.hpp`, `server.c` differ by small hunks; the solving path is the same. The twelve vendored JavaScript libraries (`lib_cards … lib_river`) are byte-identical to 5.1.
* Compatibility test: the **untouched** 0.26.0 workbench with a Linux `mwcli` built from the 5.3 source passed **621 / 621** tests.
* Why it is not adopted: every study result, native job and checkpoint the workbench writes is keyed to build `7d08acc7eb4577ee` (`study-adapter.js`, `solver-tree.js`, `solver-service.js`, 20+ tests) and is refused under another build. Switching the key would invalidate saved studies unless a migration is designed and tested; the brief asks to preserve them. The benefits that 5.3 adds (faster stop under memory promotion, study statistics) are not used by the workbench's decision path.
* Not done: a Windows 5.3 `mwcli.exe` was **not** swapped in; the shipped `native/mwcli.exe` is still the 5.1 binary (`b3e675bf…`).

To adopt 5.3 later: add `{version:'5.3',build:'55c4fffde6deb9a1'}` to `SUPPORTED_ENGINES`, decide how results from 5.1 are migrated, replace `native/mwcli.exe` with the 5.3 `mwcli.exe` (SHA-256 `4ed6fa90…acb5d7`), and re-run the suite plus the coverage scenario.
