@echo off
rem EightMax Test Workbench 0.33.0 - target-PC acceptance of the 0.32 additions (i7-13700F / RTX 4060 Ti 8 GB / 16 GB / Windows 11, 3840x2160 at 150%).
rem Runs: self-test, shared-preflop memory check, turn-solver check, fast preflop research, research summary, then collects results.
rem Run RUN-RELEASE-ACCEPTANCE.cmd and RUN-LONG-ACCEPTANCE.cmd as well: they cover the desktop host, capture and WGC at 150% DPI.
setlocal
set "HERE=%~dp0"
if not exist "%HERE%runtime\node\node.exe" ( echo runtime\node\node.exe is missing; re-extract the ZIP. & pause & exit /b 3 )
if "%EIGHTMAX_TEST_CLI%"=="" set "EIGHTMAX_TEST_CLI=%HERE%native\mwcli.exe"
set "OUT=%LOCALAPPDATA%\EightMax-Test-Workbench\Acceptance-0.32"
if not exist "%OUT%" mkdir "%OUT%"
cd /d "%HERE%"
echo [1/6] Self-test ...
set NOPAUSE=1
call "%HERE%RUN-SELF-TEST.cmd" > "%OUT%\self-test.txt" 2>&1
echo self-test exit %ERRORLEVEL% >> "%OUT%\summary.txt"
echo [2/6] Memory check (0.31 path vs shared preflop snapshot, 1/5/10 tables) ...
"%HERE%runtime\node\node.exe" tools\memory-check-032.cjs --tables=1,5,10 --hands=6 --updates=200000 --work="%OUT%\memory-work" --out="%LOCALAPPDATA%\EightMax-Test-Workbench\memory-latest.json" > "%OUT%\memory.txt" 2>&1
echo memory check exit %ERRORLEVEL% >> "%OUT%\summary.txt"
echo [3/6] Turn solver check ...
"%HERE%runtime\node\node.exe" tools\turn-solver-benchmark-032.cjs --quick --maxMs=30000 --out="%LOCALAPPDATA%\EightMax-Test-Workbench\turn-solver-latest.json" > "%OUT%\turn.txt" 2>&1
echo turn solver exit %ERRORLEVEL% >> "%OUT%\summary.txt"
echo [4/6] Fast preflop research ...
"%HERE%runtime\node\node.exe" tools\preflop-research-032.cjs --mode=fast --updates=200000 --seeds=8 --deviations --deviationSamples=500 --cache="%LOCALAPPDATA%\EightMax-Test-Workbench\PreflopStudies" --out="%LOCALAPPDATA%\EightMax-Test-Workbench\preflop-research-latest.json" > "%OUT%\preflop.txt" 2>&1
echo preflop research exit %ERRORLEVEL% >> "%OUT%\summary.txt"
echo [5/6] Research summary ...
"%HERE%runtime\node\node.exe" tools\research-summary-032.cjs > "%OUT%\summary-tool.txt" 2>&1
echo research summary exit %ERRORLEVEL% >> "%OUT%\summary.txt"
echo [6/6] Hardware facts and results collection ...
"%HERE%runtime\node\node.exe" tools\collect-hardware-facts.cjs > "%OUT%\hardware.json" 2>&1
type "%OUT%\summary.txt"
echo Results: %OUT%  -  then run COLLECT-TEST-RESULTS.cmd and send the ZIP it creates.
if "%NOPAUSE_FINAL%"=="" pause
exit /b 0
