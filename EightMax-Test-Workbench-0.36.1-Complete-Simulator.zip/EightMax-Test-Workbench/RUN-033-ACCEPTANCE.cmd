@echo off
rem EightMax Test Workbench 0.33.0 - target-PC acceptance of the 0.33 additions (i7-13700F / RTX 4060 Ti 8 GB / 16 GB / Windows 11, 3840x2160 at 150%).
rem Runs: self-test, preflop solver modes (compact B169 and full linked A at 2,000,000 updates; Mode A needs about 3 GB), the flop solver
rem check (8 worker threads), the multiway validation, a 1/5/10-table memory check, the research summary, then collects hardware facts.
rem Run RUN-RELEASE-ACCEPTANCE.cmd and RUN-LONG-ACCEPTANCE.cmd as well: they cover the desktop host, capture and WGC at 150% DPI.
setlocal
set "HERE=%~dp0"
if not exist "%HERE%runtime\node\node.exe" ( echo runtime\node\node.exe is missing; re-extract the ZIP. & pause & exit /b 3 )
if "%EIGHTMAX_TEST_CLI%"=="" set "EIGHTMAX_TEST_CLI=%HERE%native\mwcli.exe"
set "APPD=%LOCALAPPDATA%\EightMax-Test-Workbench"
set "OUT=%APPD%\Acceptance-0.33"
if not exist "%OUT%" mkdir "%OUT%"
cd /d "%HERE%"
set NOPAUSE=1
echo [1/7] Self-test ...
call "%HERE%RUN-SELF-TEST.cmd" > "%OUT%\self-test.txt" 2>&1
echo self-test exit %ERRORLEVEL% >> "%OUT%\summary.txt"
echo [2/7] Preflop solver modes (about 15-30 minutes) ...
"%HERE%runtime\node\node.exe" --max-old-space-size=6000 tools\preflop-modes-033.cjs --modes=B169,A --seeds=8 --updates=2000000 --emz --budgetMiB=12000 --cache="%APPD%\PreflopModes" --out="%APPD%\preflop-modes-latest.json" > "%OUT%\preflop-modes.txt" 2>&1
echo preflop modes exit %ERRORLEVEL% >> "%OUT%\summary.txt"
echo [3/7] Flop solver check ...
"%HERE%runtime\node\node.exe" tools\flop-solver-benchmark-033.cjs --quick --maxMs=180000 --threads=8 --out="%APPD%\flop-solver-latest.json" > "%OUT%\flop.txt" 2>&1
echo flop solver exit %ERRORLEVEL% >> "%OUT%\summary.txt"
echo [4/7] Multiway validation ...
"%HERE%runtime\node\node.exe" tools\multiway-validation-033.cjs --quick --out="%APPD%\multiway-validation-latest.json" > "%OUT%\multiway.txt" 2>&1
echo multiway validation exit %ERRORLEVEL% >> "%OUT%\summary.txt"
echo [5/7] Memory check (1/5/10 tables) ...
"%HERE%runtime\node\node.exe" tools\memory-check-032.cjs --tables=1,5,10 --hands=6 --updates=200000 --work="%OUT%\memory-work" --out="%APPD%\memory-latest.json" > "%OUT%\memory.txt" 2>&1
echo memory check exit %ERRORLEVEL% >> "%OUT%\summary.txt"
echo [6/7] Research summary ...
"%HERE%runtime\node\node.exe" tools\research-summary-033.cjs > "%OUT%\summary-tool.txt" 2>&1
echo research summary exit %ERRORLEVEL% >> "%OUT%\summary.txt"
echo [7/7] Hardware facts ...
"%HERE%runtime\node\node.exe" tools\collect-hardware-facts.cjs > "%OUT%\hardware.json" 2>&1
for %%F in (preflop-modes-latest.json flop-solver-latest.json multiway-validation-latest.json memory-latest.json research-summary.json) do if exist "%APPD%\%%F" copy /y "%APPD%\%%F" "%OUT%\" >nul
type "%OUT%\summary.txt"
echo Results: %OUT%  -  then run COLLECT-TEST-RESULTS.cmd and send the ZIP it creates.
if "%NOPAUSE_FINAL%"=="" pause
exit /b 0
