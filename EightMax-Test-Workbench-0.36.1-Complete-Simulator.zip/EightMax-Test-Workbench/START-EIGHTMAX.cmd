@echo off
call "%~dp0START-DESKTOP.cmd"
