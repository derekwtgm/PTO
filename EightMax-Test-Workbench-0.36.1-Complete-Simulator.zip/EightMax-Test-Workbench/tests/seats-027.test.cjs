'use strict';
/* 0.27: the image reader, the hand-state engine and the pipeline work for 2 to 8 seats. Measured on the built-in renderer of the controlled client only:
 * this says nothing about any external poker client. Empty seats, sitting-out and departed players are NOT modelled (every seat of a table is occupied); such tables are rejected, not guessed. */
const test = require('node:test'), assert = require('node:assert/strict'), crypto = require('node:crypto');
const EM = require('../src/engine.js'), FH = require('../src/full-hand.js'), OCR = require('../src/vision-ocr.js'), SIM = require('../src/sim-display.js'), HS = require('../src/hand-state.js');
const none = { decide: async () => ({ status: 'unavailable', reason: 'no solver in this test' }) };
const sha = (x) => crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');

test('layouts for 2-8 seats are valid and free of overlapping regions; the 8-seat geometry is byte-identical to 0.26', () => {
  for (let n = 2; n <= 8; n++) for (const L of [OCR.defaultLayout(n), OCR.defaultLayoutV2(n)]) {
    assert.equal(L.seats.length, n); assert.deepEqual(OCR.validateLayout(L), { valid: true, issues: [] }); assert.deepEqual(OCR.layoutConflicts(L), [], L.id); assert.match(L.id, new RegExp('^eightmax-' + n + 'max-v[12]$'));
  }
  // fingerprint of the 0.26.0 eight-seat layouts (computed from the unmodified 0.26.0 source)
  assert.equal(sha(OCR.defaultLayout()), 'b1d627a2db3ab77ca86c0d9b5b588a4e075e575f223633ffebd6c25da32b8a21'); assert.equal(sha(OCR.defaultLayoutV2()), '2c93287a8be8c4d365eb2c6044f6ef0046a62844a6d364cfa89b707e01646312'); assert.equal(sha(OCR.defaultLayout(8)), sha(OCR.defaultLayout()));
  assert.throws(() => OCR.defaultLayout(1)); assert.throws(() => OCR.defaultLayout(9));
});
for (let n = 2; n <= 8; n++) {
  test('complete hands from pixels with ' + n + ' seats: vision → state → scripted decision → execution → acknowledgement, chips conserved, nothing rejected', async () => {
    const table = new EM.Table(1, 500 + n, n), client = new FH.OfflineClient(table), p = new FH.SingleTablePipeline({ client, vision: FH.makeVision(1, undefined, n), decisionSource: none, allowScripted: true, scriptedWhen: () => true, seed: 5 });
    const rep = await p.run(8); assert.equal(rep.completed, 8); assert.equal(rep.totals.suspended, 0); assert.equal(rep.totals.rejectedFrames, 0); assert.equal(rep.totals.ackMismatches, 0);
    assert.equal(table.players.reduce((a, q) => a + q.stack, 0), n * 2500); table.validate(); for (const h of p.hands) { assert.equal(h.settlementOk, true); assert.equal(h.final.length, n); assert.equal(h.final.reduce((a, b) => a + b, 0), n * 2500); }
  });
}
test('every hero seat position reads correctly at several resolutions (6 seats)', () => {
  const t = new EM.Table(1, 61, 6); t.startHand(); const vis = FH.makeVision(1, [800, 960, 1280, 1920], 6);
  for (const w of [800, 960, 1280, 1920]) for (let hero = 0; hero < 6; hero++) {
    const r = vis.observe(SIM.renderTable(t, w, { v2: true, heroSeat: hero }), { heroSeat: hero }); assert.equal(r.ok, true, w + '/' + hero + ' ' + JSON.stringify(r.reasons)); const o = r.observation;
    assert.equal(o.layout.seats, 6); assert.equal(o.seats.length, 6); assert.equal(o.button, t.dealer); assert.equal(o.actor, t.actor); assert.deepEqual(o.seats.map((s) => s.stack), t.players.map((q) => q.stack));
  }
});
test('the state engine accepts only observations of its own seat count and rejects the rest as an unrecognized layout', () => {
  const t6 = new EM.Table(1, 9, 6), t8 = new EM.Table(1, 9, 8); t6.startHand(); t8.startHand();
  const e6 = new HS.HandStateEngine(1, { seats: 6 }), e8 = new HS.HandStateEngine(1, {});
  assert.equal(e6.ingest(HS.observeSimulator(t6, 0)).accepted, true); assert.equal(e8.ingest(HS.observeSimulator(t8, 0)).accepted, true);
  const bad = new HS.HandStateEngine(1, { seats: 6 }).ingest(HS.observeSimulator(t8, 0)); assert.equal(bad.accepted, false); assert.ok(bad.issues.some((i) => i.code === 'unrecognized-layout'));
  const bad2 = new HS.HandStateEngine(1, {}).ingest(HS.observeSimulator(t6, 0)); assert.equal(bad2.accepted, false); assert.ok(bad2.issues.some((i) => i.code === 'unrecognized-layout'));
  for (const s of [1, 9, 2.5, '6']) assert.throws(() => new HS.HandStateEngine(1, { seats: s }), /Seat count/);
  assert.equal(e6.state.seats.length, 6); assert.equal(e6.startPot, 6 * 10 + 50 + 100);
});
test('profiles that share an aspect ratio are never guessed between: the seat count must be given', () => {
  const ps = new OCR.ProfileSet().add(OCR.defaultLayoutV2(6)).add(OCR.defaultLayoutV2(8)), img = { width: 960, height: 600, data: new Uint8ClampedArray(960 * 600 * 4) };
  assert.equal(ps.select(img).ambiguous, true); assert.equal(ps.select(img, 6).profile.seats.length, 6); assert.equal(ps.select(img, 8).profile.seats.length, 8); assert.equal(ps.select(img, 5), null);
  const t = new EM.Table(1, 3, 6); t.startHand(); const cal = SIM.calibrate([960], OCR.defaultLayoutV2(6)); const both = new OCR.ProfileSet().add(OCR.defaultLayoutV2(6)).add(OCR.defaultLayoutV2(8));
  const o = new OCR.ImageObserver({ table: 1, profiles: both, cards: cal.cards, glyphs: cal.glyphs }), pic = SIM.renderTable(t, 960, { v2: true });
  const r = o.observe(pic, {}); assert.equal(r.ok, false); assert.match(r.reasons[0], /ambiguous-layout/); assert.equal(o.observe(pic, { seats: 6 }).ok, true); assert.equal(o.observe(pic, { seats: 8 }).ok, false, 'reading a 6-seat picture with the 8-seat profile is refused or fails, never accepted');
});
test('a hero seat outside the table is rejected', () => {
  const t = new EM.Table(1, 3, 4); t.startHand(); const r = FH.makeVision(1, undefined, 4).observe(SIM.renderTable(t, 960, { v2: true }), { heroSeat: 4 }); assert.equal(r.ok, false); assert.match(r.reasons[0], /out of range/);
});
test('non-8-seat tables never receive an 8-handed strategy: explicit "player-count-unsupported", labelled scripted fallback only in simulation, a strict run suspends', async () => {
  const fakeSolver = { decide: async () => { throw new Error('the solver must not be asked about a 6-handed table'); } };
  let table = new EM.Table(1, 41, 6), p = new FH.SingleTablePipeline({ client: new FH.OfflineClient(table), vision: FH.makeVision(1, undefined, 6), decisionSource: fakeSolver, allowScripted: true, seed: 5, stopOnSuspend: false });
  let rep = await p.run(3); assert.equal(rep.completed, 3); assert.equal(rep.totals.solverActions, 0); assert.ok(rep.totals.scriptedActions > 20); assert.equal(rep.unavailableCodes['player-count-unsupported'], rep.totals.unavailable); assert.ok(p.hands.every((h) => h.actions.every((a) => a.source === 'scripted')));
  table = new EM.Table(1, 41, 6); p = new FH.SingleTablePipeline({ client: new FH.OfflineClient(table), vision: FH.makeVision(1, undefined, 6), decisionSource: fakeSolver, allowScripted: false, seed: 5, stopOnSuspend: true });
  rep = await p.run(1); assert.equal(rep.completed, 0); assert.equal(rep.totals.suspended, 1); assert.match(p.hands[0].reason, /8-handed tables only/);
});
