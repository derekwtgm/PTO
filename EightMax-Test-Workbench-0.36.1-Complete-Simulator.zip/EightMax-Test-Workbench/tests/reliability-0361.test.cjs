'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),EM=require('../src/engine.js'),M=require('../src/input-motion.js'),MS=require('../src/movement-settings.js');
function finish(t,aggressive=false){for(let n=0;t.status==='playing'&&n<300;n++){const l=t.legal(),a=aggressive&&l.canRaise?{type:'raise',amount:l.maxRaiseTo}:{type:l.canCheck?'check':'call'};t.execute(t.request(a.type,a.amount,0),0);t.validate();}assert.equal(t.status,'complete');}
test('tournament carries every settled chip forward and advances button among funded seats',()=>{
 const t=new EM.Table(1,71,8,{persistentStacks:true});t.startHand();finish(t);const stacks=t.players.map(p=>p.stack),old=t.dealer;t.startHand();
 assert.equal(t.dealer,t.nextSeat(old,p=>!p.folded));assert.deepEqual(t.players.map(p=>p.stack+p.total),stacks);assert.equal(t.bankroll,20000);finish(t);
});
test('100 seeded tournaments conserve chips, eliminate players, reach a winner without reset',()=>{
 for(let seed=1;seed<=100;seed++){const t=new EM.Table(1,seed,8,{persistentStacks:true});t.setNextStacks([10,20,30,40,50,60,70,80]);let h=0;
  while(t.startHand()!==false){assert.ok(++h<200);finish(t,true);assert.equal(t.players.reduce((n,p)=>n+p.stack,0),360);}
  assert.equal(t.players.filter(p=>p.stack>0).length,1);assert.equal(t.tournamentComplete,true);const hand=t.hand;assert.equal(t.startHand(),false);assert.equal(t.hand,hand);
 }
});
test('heads-up uses button as small blind even with vacant seats, ante-all-ins run out',()=>{
 const t=new EM.Table(1,9,8,{persistentStacks:true});t.setNextStacks([0,2500,0,0,2500,0,0,0]);t.startHand();assert.equal(t.sb,t.dealer);assert.equal(t.actor,t.sb);assert.equal(t.bb,4);finish(t);
 const short=new EM.Table(1,3,8,{persistentStacks:true});short.setNextStacks([1,2,0,0,0,0,0,0]);short.startHand();assert.equal(short.status,'complete');short.validate();
});
test('signed curves mirror paths and preserve analytic speed/acceleration bounds at every supported preset',()=>{
 for(const speed of [400,600,1200,2000,2800])for(const arc of [.01,.12,.25]){
 const p=M.profile({maxSpeed:speed,arc,maxDeviationPx:90}),a=M.plan({x:0,y:0},{x:3000,y:0},p),b=M.plan({x:0,y:0},{x:3000,y:0},{...p,arc:-arc});assert.equal(a.durationMs,b.durationMs);
 for(let i=0;i<a.points.length;i++){assert.equal(a.points[i].x,b.points[i].x);assert.ok(Math.abs(a.points[i].y+b.points[i].y)<=1);assert.ok(Math.abs(a.points[i].y)<=90);}
 assert.ok(a.peakSpeed<=speed+1e-8);assert.ok(a.peakAccel<=p.maxAccel+1e-8);
 }
});
test('seeded random direction covers both sides, honors explicit curvature range and is reproducible',()=>{
 const o={pattern:'random',seed:834,minCurvature:.1,maxCurvature:.22},a=new MS.Sequence(o),b=new MS.Sequence(o),signs=new Set();
 for(let i=0;i<100;i++){const x=a.next({arc:.05}),y=b.next({arc:.05});assert.deepEqual(x,y);signs.add(Math.sign(x.profile.arc));assert.ok(Math.abs(x.profile.arc)>=.1&&Math.abs(x.profile.arc)<=.22);}assert.equal(signs.size,2);
 assert.throws(()=>new MS.Sequence({minCurvature:.2,maxCurvature:.1}));
});

test('dealer advances an ante-only terminal hand without requiring an input event',async()=>{
 const FD=require('../src/fixture-dealer.js'),events=[];
 const dealer=new FD.TableDealer({table:1,stacks:[1,2,0,0,0,0,0,0],handGapMs:1,send:()=>{},record:e=>events.push(e)});
 dealer.start();
 try{await new Promise(resolve=>setTimeout(resolve,30));assert.ok(events.some(e=>e.kind==='hand-complete'));assert.ok(events.some(e=>e.kind==='tournament-complete'));assert.equal(dealer.t.tournamentComplete,true);}
 finally{dealer.onWindow({type:'closed'});}
});
