// 0.29: drives the REAL CaptureService persistent-session code (StreamFrame / WgcStream / CloseAllStreams) against a fake helper
// (tests/fixtures/wgc-stubs/wgc-session.sh). Proves session reuse, newest-frame delivery, duplicate marking, end-of-session codes and
// process clean-up. Linux/Mono only; no Windows Graphics Capture happens.
using System; using System.Threading; using EightMax.Workbench;
public static class WgcStreamHarness {
    static string F(string j, string k){ int i=j.IndexOf("\""+k+"\":"); if(i<0) return null; i+=k.Length+3; int e=i; if(j[i]=='"'){ e=j.IndexOf('"',i+1); return j.Substring(i+1,e-i-1);} while(e<j.Length&&j[e]!=','&&j[e]!='}') e++; return j.Substring(i,e-i); }
    static void Line(string name, string r){ Console.WriteLine("{\"case\":\""+name+"\",\"ok\":"+(F(r,"ok")??"null")+",\"code\":\""+(F(r,"code")??"")+"\",\"frameId\":"+(F(r,"frameId")??"0")+",\"fresh\":"+(F(r,"fresh")??"null")+",\"framesFromSession\":"+(F(r,"framesFromSession")??"0")+",\"sessions\":"+CaptureService.StreamCount+"}"); }
    public static int Main(string[] a){
        string helper=a[0];
        Environment.SetEnvironmentVariable("WGC_STUB_MODE","normal");
        Line("first", CaptureService.StreamFrameForTest(helper,"0x10",42,1000));
        Thread.Sleep(500);
        Line("second", CaptureService.StreamFrameForTest(helper,"0x10",42,300));
        Line("third-no-new-content", CaptureService.StreamFrameForTest(helper,"0x10",42,300));
        Line("other-window", CaptureService.StreamFrameForTest(helper,"0x20",42,1000));
        Console.WriteLine("{\"case\":\"close-all\",\"closed\":"+CaptureService.CloseAllStreams()+",\"sessions\":"+CaptureService.StreamCount+"}");
        Environment.SetEnvironmentVariable("WGC_STUB_MODE","lost");
        Line("lost-first", CaptureService.StreamFrameForTest(helper,"0x30",42,1000));
        Thread.Sleep(600);
        Line("lost-after", CaptureService.StreamFrameForTest(helper,"0x30",42,300));
        Environment.SetEnvironmentVariable("WGC_STUB_MODE","refuse");
        Line("refused", CaptureService.StreamFrameForTest(helper,"0x40",42,500));
        CaptureService.CloseAllStreams();
        return 0;
    }
}
