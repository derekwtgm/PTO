// EightMax 0.28.0 test double for desktop/CaptureService.cs (Linux/Mono only). It lets the REAL self-test control flow in
// desktop/capture/EightMaxCapture.cs run end to end (create, capture, resize, minimise, restore, close, closed detection)
// under Mono WinForms on X11. Pixels come from Control.DrawToBitmap, not from PrintWindow/BitBlt, so this validates the
// self-test sequencing and the closed-handle fix - NOT Windows capture.
using System; using System.Drawing; using System.Drawing.Imaging; using System.IO; using System.Windows.Forms;
namespace EightMax.Workbench {
public static class CaptureService {
    public sealed class Target { public string Kind, Hwnd, Title, Method = "auto"; public int Pid, X, Y, Width, Height; }
    public static string EnsureDpiAware() { return "test-double"; }
    public static string ListWindowsJson(int pid) { return "{\"format\":\"eightmax-capture-windows\",\"version\":1,\"windows\":[]}"; }
    public static string ListMonitorsJson() { return "{\"format\":\"eightmax-capture-monitors\",\"version\":1,\"virtual\":{\"x\":0,\"y\":0,\"width\":1280,\"height\":800},\"monitors\":[{\"id\":0,\"name\":\"X\",\"x\":0,\"y\":0,\"width\":1280,\"height\":800,\"dpiScale\":1,\"primary\":true}]}"; }
    static IntPtr Parse(string s) { return new IntPtr(Convert.ToInt64(s.Substring(2), 16)); }
    static Form Find(string hwnd) { Control c = Control.FromHandle(Parse(hwnd)); Form f = c as Form; return f == null || f.IsDisposed || !f.IsHandleCreated ? null : f; }
    public static bool WindowExists(string hwnd) { return Find(hwnd) != null; }
    static string Reject(string code, string reason, bool min) { return "{\"ok\":false,\"code\":\"" + code + "\",\"reason\":\"" + reason + "\",\"minimized\":" + (min ? "true" : "false") + "}"; }
    public static string GrabJson(Target t) {
        Form f = Find(t.Hwnd); if (f == null) { if (Environment.GetEnvironmentVariable("EIGHTMAX_FAKE_THROW_ON_LOST") == "1") throw new InvalidOperationException("injected fault"); return Reject("target-lost", "The window no longer exists.", false); }
        if (f.WindowState == FormWindowState.Minimized) return Reject("target-minimized", "The window is minimised.", true);
        Size sz = f.ClientSize;
        using (Bitmap whole = new Bitmap(f.Width, f.Height)) {
            f.DrawToBitmap(whole, new Rectangle(0, 0, f.Width, f.Height));
            Point origin = f.PointToScreen(Point.Empty); int dx = origin.X - f.Left, dy = origin.Y - f.Top; if (dx < 0 || dx > 64) dx = 0; if (dy < 0 || dy > 64) dy = 0;
            using (Bitmap client = whole.Clone(new Rectangle(dx, dy, Math.Min(sz.Width, whole.Width - dx), Math.Min(sz.Height, whole.Height - dy)), PixelFormat.Format32bppArgb))
            using (MemoryStream ms = new MemoryStream()) { client.Save(ms, ImageFormat.Png);
                return "{\"ok\":true,\"method\":\"test-double\",\"width\":" + client.Width + ",\"height\":" + client.Height + ",\"dpiScale\":1,\"occludedFraction\":0,\"png\":\"" + Convert.ToBase64String(ms.ToArray()) + "\"}"; }
        }
    }
}
}
