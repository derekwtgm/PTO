'use strict';
/* 0.31 test fixtures: deterministic stand-in studies with KNOWN strategies, so range updates can be checked analytically.
 * fakePreflop(): eight study seats act once each in order 0..7 with the menu Fold / Call 1 / Raise to 3 (labels as EightMax writes
 * them); the line ends at a chance node (flop) with the players who did not fold. The average strategy of a hand depends only
 * on its class (STRAT below). `missing` lists (seat, class) pairs with NO stored rows (to test unsupported combos).
 * fakeStreet(): one postflop street for given study seats, menu Check / Bet 2 at the first node and Fold / Call 2 after a bet. */
const EM = require('./load-solver.cjs'), RE = require('../src/range-engine.js'), ST = require('../src/solver-tree.js');
const STRAT = { AA: [0, 0, 1], KK: [0, 0.5, 0.5], AKs: [0, 1, 0], '72o': [1, 0, 0] }, DEFAULT = [0.6, 0.3, 0.1];
const stratOf = (cls) => STRAT[cls] || DEFAULT;
function allRows() { const rows = []; for (let i = 0; i < 1326; i++) rows.push([i, RE.C1[i], RE.C2[i], 1]); return rows; }
function fakePreflop(o = {}) {
  const missing = o.missing || [], n = 8, menu = ['Fold', 'Call 1', 'Raise to 3'];
  const game = {
    iterations: 1000,
    view(steps) {
      const live = Array.from({ length: n }, (_, s) => (s < steps.length ? steps[s] !== 0 : true));
      if (steps.length < n) return { kind: 'player', seat: steps.length, pot: 1.5 + steps.filter((x) => x > 0).length, behind: Array(n).fill(25), live, actions: menu.map((label) => ({ label })) };
      return { kind: 'chance', seat: -1, pot: 1.5 + steps.filter((x) => x > 0).length, behind: Array(n).fill(25), live, actions: null };
    },
    averageAt(key, board, seat, h) { const cls = RE.classNameOf(h.a, h.b); if (missing.some(([s, c]) => s === seat && c === cls)) return null; return Float64Array.from(stratOf(cls)); },
  };
  const prepared = { game, spec: { hands: Array.from({ length: n }, () => allRows()), board: [] }, options: { config: { ranges: Array(n).fill('random'), preflop: { mode: 'linked' }, stacks: Array(n).fill(25) } } };
  const study = new ST.TreeStudy(EM, prepared, { id: 'fake-preflop', kind: 'preflop', seatOrder: null });
  return { study, stack: 2500, EM };
}
/** Simulator actions for a preflop line given per-study-seat choices ('f'|'c'|'r'), button chosen so that study seat s == sim seat s. */
const BUTTON = [0, 1, 2, 3, 4, 5, 6, 7].find((b) => ST.preflopSeatOrder(b).every((sim, i) => sim === i));
function preflopActions(choices) { return choices.split('').map((c, s) => ({ seat: s, street: 'preflop', type: c === 'f' ? 'fold' : c === 'c' ? 'call' : 'raise', amount: c === 'r' ? 300 : c === 'c' ? 100 : 0 })); }
/** Postflop street study for the given number of players with a known strategy by class: AA always bets/calls, 72o always checks/folds. */
function fakeStreet(players, o = {}) {
  const pick = o.strategy || ((cls, facingBet) => (cls === 'AA' ? [0, 1] : cls === '72o' ? [1, 0] : facingBet ? [0.5, 0.5] : [0.75, 0.25]));
  const game = {
    // players act in seat order: Check / Bet 2 until someone bets (step value 1); then each other player once: Fold / Call 2
    view(steps) {
      const b = steps.indexOf(1);
      if (b < 0) return steps.length < players ? { kind: 'player', seat: steps.length, actions: [{ label: 'Check' }, { label: 'Bet 2' }] } : { kind: 'chance', live: Array(players).fill(true) };
      const r = steps.length - b - 1; if (r < players - 1) return { kind: 'player', seat: (b + 1 + r) % players, actions: [{ label: 'Fold' }, { label: 'Call 2' }] };
      return { kind: 'chance', live: Array.from({ length: players }, (_, s) => s === b || steps[b + 1 + ((s - b - 1 + players) % players)] === 1) };
    },
    averageAt(key, board, seat, h) { const steps = key.slice(1).split('').map(Number), facing = steps.includes(1); return Float64Array.from(pick(RE.classNameOf(h.a, h.b), facing, seat)); },
  };
  return { game, spec: { hands: Array.from({ length: players }, () => allRows()), board: o.board || [] } };
}
module.exports = { EM, STRAT, stratOf, fakePreflop, preflopActions, fakeStreet, BUTTON, allRows };
