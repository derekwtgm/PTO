'use strict';
// 0.33: restricted heads-up FLOP CFR+ (src/flop-solver.js): chance enumeration, card removal, convergence measured by INDEPENDENT
// evaluators (src/fast-multistreet.js and src/independent-eval.js), complete linked continuations, quality gate, checkpoint recovery,
// deterministic worker partitioning, cancellation and resource limits.
const test = require('node:test'), assert = require('node:assert');
const EM = require('./load-solver.cjs'), A = require('../src/study-adapter.js'), X = require('../src/exploitability.js'), MS = require('../src/fast-multistreet.js'), FS = require('../src/flop-solver.js'), IE = require('../src/independent-eval.js'), LK = require('../src/linked-study.js'), Q = require('../src/strategy-quality.js');
const ONE = { bets: '75', raises: 'a', maxBets: 1 };
const SMALL = { board: 'Kd8s3c', common: 6, stacks: [9, 9], ranges: ['AA,88,QJs', 'AA,88,QJs,KQs'], streets: { flop: ONE, turn: ONE, river: ONE }, privateSeed: 1 };
const MED = { board: 'As7d2h', common: 6, stacks: [12, 12], ranges: ['AA,KK,77,AK,KQs,T9s', 'AA,KK,77,AK,KQs,T9s'], streets: { flop: ONE, turn: ONE, river: ONE }, privateSeed: 1 };
const prep = (cfg) => A.prepare(EM, { config: cfg, iterations: 1 });

test('flop solver: every turn and river card is enumerated with exact card removal (values conserve the pot for any strategy)', () => {
  const p = prep(SMALL), core = FS.createCore(p.game, p.spec), F = MS.prepare(p.game, p.spec);
  const e0 = F.evaluate(core.strategy());   // untrained: uniform current strategy
  assert.ok(Math.abs(e0.values[0] + e0.values[1] - 6) < 1e-9, 'constant sum');
  assert.strictEqual(core.turnCards.length, 49); assert.deepStrictEqual(core.board0, IE.cards('Kd8s3c'));
  // the engine evaluator used for showdown tables orders hands exactly like the evaluator of the independent check
  let x = 3; const rnd = () => { x = (Math.imul(x, 1103515245) + 12345) >>> 0; return x / 4294967296; };
  for (let t = 0; t < 500; t++) { const d = Array.from({ length: 52 }, (_, i) => i); for (let i = 51; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [d[i], d[j]] = [d[j], d[i]]; } const a = d.slice(0, 7), b = d.slice(0, 5).concat(d.slice(7, 9)); assert.strictEqual(Math.sign(EM.evalCards(a) - EM.evalCards(b)), Math.sign(X.score7(a) - X.score7(b))); }
});
test('flop CFR+ converges and agrees with the 0.32 multi-street CFR+ on the same game (both evaluated by fast-multistreet)', () => {
  const p = prep(MED), a = FS.solve(p.game, p.spec, { iterations: 60, every: 60 }), b = MS.prepare(p.game, p.spec).cfrPlus(60, { every: 60 });
  assert.ok(a.exploitabilityPctPot < 1.5, 'flop solver ' + a.exploitabilityPctPot + '% of pot after 60 iterations');
  assert.ok(Math.abs(a.exploitability - b.exploitability) < 0.02 * 6 / 100 + 0.25 * b.exploitability, 'same algorithm, same order of exploitability: ' + a.exploitability + ' vs ' + b.exploitability);
  assert.ok(a.curve.length === 1 && a.stopped === 'complete');
});
test('independent check: fast-multistreet and independent-eval give the same exploitability for the flop solver output', () => {
  const p = prep(SMALL), r = FS.solve(p.game, p.spec, { iterations: 30, every: 30 });
  const G = IE.holdem({ board: SMALL.board, common: 6, stacks: SMALL.stacks, hands: p.spec.hands.map((l) => l.map((h) => [h[1], h[2], h[3]])), streets: SMALL.streets });
  const geo = IE.compareGeometry(G, (s) => p.game.view(s)); assert.deepStrictEqual(geo.mismatches, []);
  const e = IE.evaluate(G, (seat, node, board, ti, type) => { const h = p.spec.hands[seat][type.src]; return r.strategy.averageAt(node.path, board, seat, { id: h[0], a: h[1], b: h[2], w: h[3] }); });
  assert.strictEqual(e.missingRows, 0); assert.ok(Math.abs(e.exploitability - r.exploitability) < 1e-9, e.exploitability + ' vs ' + r.exploitability); assert.ok(Math.abs(e.values[0] - r.values[0]) < 1e-9);
});
test('complete continuation: the flop linked record stores every turn and river row (0 unvisited) and re-evaluates to the solver value; quality gate validates it only within the limit', () => {
  const p = prep(SMALL), r = FS.solve(p.game, p.spec, { iterations: 120, every: 40, target: 0.004 * 6 });
  const stand = { game: { view: (s) => p.game.view(s), iterations: r.iterations, averageAt: (a, b, c, d) => r.strategy.averageAt(a, b, c, d) }, spec: p.spec, options: p.options };
  const rec = LK.open(LK.exportLinked(stand, { EM })); assert.strictEqual(rec.meta.counts.missingRows, 0); assert.ok(rec.meta.counts.boards > 49 * 48 / 2);
  const ev = Q.evaluateLinked(rec, { potBB: 6 }); assert.strictEqual(ev.type, 'exact'); assert.ok(Math.abs(ev.exploitabilityBB - r.exploitability) < 1e-9); assert.deepStrictEqual(ev.streets, ['flop', 'turn', 'river']);
  const c = Q.classify(ev, 'research'); assert.strictEqual(c.status, r.exploitabilityPctPot <= 1 ? 'validated' : 'failed-quality-check');
  const strict = Q.classify(ev, { base: 'strict', headsUp: { maxExploitabilityPctPot: 0.0001 } }); assert.strictEqual(strict.status, 'failed-quality-check'); assert.strictEqual(Q.gate(strict, 'research').allowed, false);
});
test('checkpoint recovery: 12 + 12 iterations from a checkpoint is bit-identical to 24; corrupt or foreign checkpoints are refused', () => {
  const p = prep(SMALL), full = FS.solve(p.game, p.spec, { iterations: 24, evaluate: false }), half = FS.solve(p.game, p.spec, { iterations: 12, evaluate: false });
  const cp = half.checkpoint(), res = FS.solve(p.game, p.spec, { iterations: 24, evaluate: false, resume: cp });
  assert.ok(Buffer.compare(full.checkpoint(), res.checkpoint()) === 0, 'identical tables and header'); assert.strictEqual(res.iterations, 24);
  const bad = Buffer.from(cp); bad[bad.length - 9] ^= 1; assert.throws(() => FS.solve(p.game, p.spec, { iterations: 13, evaluate: false, resume: bad }), /checksum/);
  const other = prep({ ...SMALL, stacks: [10, 10] }); assert.throws(() => FS.solve(other.game, other.spec, { iterations: 13, evaluate: false, resume: cp }), /different game/);
});
test('worker partition over turn cards: deterministic for a thread count and equivalent to the single-thread solve', async () => {
  const a = await FS.solveParallel(SMALL, { iterations: 20, every: 20, threads: 3 }), b = await FS.solveParallel(SMALL, { iterations: 20, every: 20, threads: 3 });
  assert.strictEqual(a.exploitability, b.exploitability, 'bit-identical for the same thread count');
  const p = prep(SMALL), s = FS.solve(p.game, p.spec, { iterations: 20, every: 20 });
  assert.ok(Math.abs(a.exploitability - s.exploitability) <= 0.05 * s.exploitability + 1e-6, 'same algorithm up to summation order: ' + a.exploitability + ' vs ' + s.exploitability);
  // parallel checkpoint resumes in a single thread and vice versa
  const r = FS.solve(p.game, p.spec, { iterations: 21, evaluate: false, resume: a.checkpoint() }); assert.strictEqual(r.iterations, 21);
});
test('cancellation, memory limit and wrong game shape are refused up front', () => {
  const p = prep(SMALL), ac = new AbortController(); ac.abort();
  assert.strictEqual(FS.solve(p.game, p.spec, { iterations: 10, signal: ac.signal, evaluate: false }).stopped, 'cancelled');
  assert.throws(() => FS.solve(p.game, p.spec, { iterations: 10, maxBytes: 1024 }), (e) => e.code === 'memory-limit');
  const turn = prep({ ...SMALL, board: 'Kd8s3c2h', streets: { turn: ONE, river: ONE } }); assert.throws(() => FS.createCore(turn.game, turn.spec), /three-card starting board/);
  const three = prep({ ...SMALL, stacks: [9, 9, 9], ranges: Array(3).fill('AA,KK,88,QJs,AK,T9s,65s') }); assert.throws(() => FS.createCore(three.game, three.spec), /heads-up only/);
});
