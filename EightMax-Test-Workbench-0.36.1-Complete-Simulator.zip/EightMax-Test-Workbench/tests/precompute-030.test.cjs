'use strict';
/* 0.30 precomputation queue, checkpoint continuation, throttling, shared strategy memory across threads, and the
 * end-to-end simulator with the library (Study Mode pass, then a Decision Mode replay that must train nothing). */
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), { Worker } = require('node:worker_threads');
const L = require('../src/strategy-library.js'), LS = require('../src/library-source.js'), { PrecomputeQueue } = require('../src/precompute.js');
const { cliPath } = require('../tools/train-study.cjs');
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'em-pre-test-'));
const cards = (s) => s.match(/../g);
const spot = (pot, it = 1200, street = 'river') => LS.spotFromParams({ street, board: cards(street === 'river' ? 'AsKd7h4c2s' : street === 'turn' ? 'AsKd7h4c' : 'AsKd7h'), stacksBehind: [10, 10], pot }, { iterations: it, trainerName: 'javascript-reference-cpu' }).spot;

test('queue: priority order, de-duplication, already-stored detection, only completed studies stored', async () => {
  const lib = L.StrategyLibrary.open(tmp()), q = new PrecomputeQueue({ library: lib, reserveMiB: 0, memoryMiB: 1 }); q.pause(); const order = [];
  q.on((e) => { if (e.type === 'started') order.push(e.job.priority); });
  q.enqueue(spot(4), { priority: 1 }); q.enqueue(spot(5), { priority: 9 }); q.enqueue(spot(6), { priority: 5 });
  assert.equal(q.enqueue(spot(5), { priority: 2 }).priority, 9, 'duplicate keeps the higher priority'); assert.equal(q.stats.duplicates, 1);
  q.start(); await q.drain(); assert.deepEqual(order, [9, 5, 1]); assert.equal(q.status().counts.complete, 3); assert.equal(lib.list().length, 3);
  assert.equal(q.enqueue(spot(4)).status, 'already-stored');
  for (const e of lib.list()) assert.equal(e.convergence, 'unproven', 'completed is not converged');
});
test('worker-thread mode: jobs train in their own threads, results identical to in-thread training, cancellation still works', async () => {
  const a = L.StrategyLibrary.open(tmp()), b = L.StrategyLibrary.open(tmp()), s1 = spot(4), s2 = spot(5);
  const qa = new PrecomputeQueue({ library: a, reserveMiB: 0, memoryMiB: 1, workerThreads: true, concurrency: 2 }); qa.enqueue(s1); qa.enqueue(s2); await qa.drain();
  const qb = new PrecomputeQueue({ library: b, reserveMiB: 0, memoryMiB: 1 }); qb.enqueue(s1); qb.enqueue(s2); await qb.drain();
  for (const s of [s1, s2]) assert.deepEqual(Array.from(a.get(s.identity).game.probs), Array.from(b.get(s.identity).game.probs));
  const qc = new PrecomputeQueue({ library: L.StrategyLibrary.open(tmp()), reserveMiB: 0, memoryMiB: 1, workerThreads: true, chunkUpdates: 100 }); const big = spot(6, 80000); qc.enqueue(big);
  qc.on((e) => { if (e.type === 'progress' && e.job.progress > 0.01) qc.cancel(big.fingerprint); }); await qc.drain(); assert.equal(qc.jobs.get(big.fingerprint).status, 'cancelled');
});
test('cancellation: a queued job is cancelled; a running job is aborted and nothing is stored', async () => {
  const lib = L.StrategyLibrary.open(tmp()), q = new PrecomputeQueue({ library: lib, reserveMiB: 0, memoryMiB: 1, chunkUpdates: 100 }); q.pause();
  const a = q.enqueue(spot(4, 60000), { priority: 2 }), b = q.enqueue(spot(5), { priority: 1 });
  assert.equal(q.cancel(b.fingerprint), true); q.on((e) => { if (e.type === 'progress' && e.job.fingerprint === a.fingerprint && e.job.progress > 0.01) q.cancel(a.fingerprint); });
  q.start(); await q.drain(); assert.equal(q.jobs.get(a.fingerprint).status, 'cancelled'); assert.equal(q.jobs.get(b.fingerprint).status, 'cancelled'); assert.equal(lib.list().length, 0);
});
test('throttling: nothing starts while free memory is below reserve + job budget or while the decision workload asks for priority', async () => {
  const lib = L.StrategyLibrary.open(tmp()); let free = 100 * 1048576, busy = true;
  const q = new PrecomputeQueue({ library: lib, reserveMiB: 2048, memoryMiB: 512, freeMem: () => free, pollMs: 5 }); q.enqueue(spot(4)); q.start();
  await new Promise((r) => setTimeout(r, 60)); assert.equal(q.status().counts.queued, 1); assert.ok(q.stats.throttled > 0); assert.match(q.status().lastThrottle, /memory/);
  free = 8 * 2 ** 30; q.o.pressure = () => ({ pause: busy, reason: '3 decisions waiting' }); await new Promise((r) => setTimeout(r, 40)); assert.equal(q.status().counts.queued, 1); assert.match(q.status().lastThrottle, /decisions waiting/);
  busy = false; await q.drain(); assert.equal(q.status().counts.complete, 1);
});
test('persistent queue: a job interrupted mid-training resumes from its checkpoint after a restart (native engine)', { skip: !cliPath() && 'native engine (EIGHTMAX_TEST_CLI) required for checkpointed training' }, async () => {
  const dir = tmp(), cli = cliPath(), s = LS.spotFromParams({ street: 'flop', board: cards('Td7c2h'), stacksBehind: [20, 20], pot: 5 }, { iterations: 12000 }).spot;
  const q1 = new PrecomputeQueue({ library: L.StrategyLibrary.open(dir), cli, reserveMiB: 0, memoryMiB: 256, chunkUpdates: 4000, faultAfterChunk: 1 }); q1.enqueue(s); q1.start(); await q1.drain();
  assert.equal(q1.jobs.get(s.fingerprint).status, 'interrupted'); assert.equal(L.StrategyLibrary.open(dir).list().length, 0, 'an interrupted study is not stored');
  const q2 = new PrecomputeQueue({ library: L.StrategyLibrary.open(dir), cli, reserveMiB: 0, memoryMiB: 256, chunkUpdates: 4000 }); assert.equal(q2.jobs.get(s.fingerprint).status, 'queued'); q2.start(); await q2.drain();
  const j = q2.jobs.get(s.fingerprint); assert.equal(j.status, 'complete'); assert.equal(j.training.resumedFrom, 4000); assert.equal(j.training.chunks, 2); assert.equal(q2.stats.resumed, 1);
  // continuation is exact: the resumed study equals one trained in the same chunks without interruption
  const q3lib = L.StrategyLibrary.open(tmp()), q3 = new PrecomputeQueue({ library: q3lib, cli, reserveMiB: 0, memoryMiB: 256, chunkUpdates: 4000 }); q3.enqueue(s); q3.start(); await q3.drain();
  const a = L.StrategyLibrary.open(dir).get(s.identity), b = q3lib.get(s.identity); assert.ok(a.ok && b.ok); assert.deepEqual(Array.from(a.game.probs), Array.from(b.game.probs));
});
test('native training is deterministic for a given identity (repeated-seed reproducibility)', { skip: !cliPath() && 'native engine required' }, async () => {
  const s = LS.spotFromParams({ street: 'turn', board: cards('Td7c2h5s'), stacksBehind: [15, 15, 15], pot: 6 }, { iterations: 5000 }).spot;
  const r1 = await LS.trainSpot(s, { cli: cliPath() }), r2 = await LS.trainSpot(s, { cli: cliPath() }); assert.equal(Buffer.compare(Buffer.from(r1.body), Buffer.from(r2.body)), 0);
});
test('planFromMisses queues the most frequent missing situations first', async () => {
  const lib = L.StrategyLibrary.open(tmp());
  for (const [pot, n] of [[4, 1], [5, 3], [6, 2]]) { const s = spot(pot); for (let i = 0; i < n; i++) lib.recordMiss(s.identity, s.fingerprint, { spot: s }); }
  fs.appendFileSync(path.join(lib.dir, 'misses.jsonl'), '{broken\n');
  const q = new PrecomputeQueue({ library: lib, reserveMiB: 0, memoryMiB: 1 }); q.pause(); const r = q.planFromMisses(10); assert.equal(r.queued, 3); assert.equal(r.damagedLines, 1);
  assert.deepEqual(q.status().next.map((j) => j.priority), [3, 2, 1]);
});
test('shared strategy memory: three worker threads read one copy of a record loaded by the host', async () => {
  const { SharedStrategyHost } = require('../src/shared-strategy-cache.js'), dir = tmp(), s = spot(4, 1500), r = await LS.trainSpot(s, {});
  L.StrategyLibrary.open(dir).put(s.identity, r.body, { status: 'complete' });
  const host = new SharedStrategyHost(L.StrategyLibrary.open(dir, { sharedMemory: true }));
  const code = `const { parentPort, workerData } = require('node:worker_threads'); const { SharedStrategyClient } = require(${JSON.stringify(path.join(__dirname, '../src/shared-strategy-cache.js'))});
    const c = new SharedStrategyClient(workerData.port); (async () => { const a = await c.fetch(workerData.fp, workerData.identity); const bad = JSON.parse(JSON.stringify(workerData.identity)); bad.potBB = 77; const b = await c.fetch(workerData.fp, bad);
    parentPort.postMessage({ ok: !!a, shared: a.game.probs.buffer instanceof SharedArrayBuffer, first: a.game.probs[3], mismatchRefused: b === null }); })();`;
  const res = await Promise.all([0, 1, 2].map(() => new Promise((ok, no) => { const port = host.port(); const w = new Worker(code, { eval: true, workerData: { port, fp: s.fingerprint, identity: s.identity }, transferList: [port] }); w.on('message', (m) => { ok(m); w.terminate(); }); w.on('error', no); })));
  assert.ok(res.every((x) => x.ok && x.shared && x.mismatchRefused)); assert.equal(new Set(res.map((x) => x.first)).size, 1);
  const i = host.info(); assert.equal(i.sharedRecords, 1); assert.equal(i.sharedBytes, r.body.byteLength); assert.ok(i.served >= 3); host.close();
});
test('simulator: a Study Mode pass fills the library; the Decision Mode replay of the same seeded hands trains nothing and is answered entirely from the library', { skip: !cliPath() && 'native engine required (linked preflop study)', timeout: 900000 }, async () => {
  const EM = require('../src/engine.js'), FH = require('../src/full-hand.js'), F = require('../tools/solver-factory.cjs'), dir = tmp();
  const run = async (mode) => { const src = await F.createSource({ kind: 'preflop-linked', cli: cliPath(), updates: 250000, budgetMiB: 1024, library: { dir, mode } });
    const p = new FH.SingleTablePipeline({ tableId: 1, client: new FH.OfflineClient(new EM.Table(1, 4127 + 139)), vision: FH.makeVision(1), decisionSource: src, allowScripted: true, seed: 4128, stopOnSuspend: false });
    const rep = await p.run(40); return { rep, acts: p.hands.flatMap((h) => h.actions.map((a) => [a.street, a.seat, a.type, a.amount, a.source].join(':'))), post: p.hands.flatMap((h) => h.actions.filter((a) => a.street !== 'preflop')), info: src.librarySource.info() }; };
  const a = await run('study'), b = await run('decision');
  assert.ok(a.info.trainedInline > 0, 'study pass trained postflop spots'); assert.equal(b.info.trainedInline, 0); assert.equal(b.info.misses, 0);
  assert.deepEqual(b.acts, a.acts, 'identical hands, identical actions'); assert.ok(b.post.filter((x) => x.source === 'solver').length >= a.info.trainedInline);
  assert.equal(b.rep.totals.staleDecisions, 0); assert.equal(b.rep.totals.ackMismatches, 0);
  for (const x of b.post.filter((y) => y.source === 'solver')) assert.match(x.strategySource, /^library-(disk|memory)$/);
});
