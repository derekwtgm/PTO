'use strict';
// 0.28.0: memory-aware ten-table scheduling and native-job concurrency that account for OTHER programs.
// The target PC (16 GB) had only ~5.17 GiB available during the 0.26 hardware check (hardware-facts.json).
const test = require('node:test'), assert = require('node:assert/strict');
const SB = require('../src/strategy-budget.js'), MT = require('../src/multitable.js'), F = require('./study-fixture.cjs');
const G = 1024 ** 3, TOTAL = 17012719616;

test('native concurrency on the target PC figures: 1 GiB jobs -> 2 at once, 4 GiB job refused as insufficient memory', () => {
  assert.equal(SB.nativeConcurrency({ totalRamBytes: TOTAL, freeRamBytes: 5.17 * G, perJobMiB: 1024, maxJobs: 10 }).jobs, 2);
  const big = SB.nativeConcurrency({ totalRamBytes: TOTAL, freeRamBytes: 5.17 * G, perJobMiB: 4096 });
  assert.equal(big.jobs, 0); assert.match(big.reason, /^Insufficient memory/);
  assert.equal(SB.nativeConcurrency({ totalRamBytes: TOTAL, freeRamBytes: 1 * G, perJobMiB: 256 }).jobs, 0, 'nothing starts when Windows itself is short of memory');
  assert.ok(SB.nativeConcurrency({ totalRamBytes: TOTAL, freeRamBytes: 12 * G, perJobMiB: 1024, maxJobs: 10 }).jobs > 2, 'more jobs when other programs free memory');
  assert.equal(SB.nativeConcurrency({ totalRamBytes: TOTAL, freeRamBytes: 5 * G, perJobMiB: 7 }).code, 'out-of-range');
});

test('system pressure rises as free memory approaches the Windows reserve', () => {
  assert.equal(SB.systemPressure(5.17 * G, TOTAL), 0);
  assert.equal(SB.systemPressure(2.3 * G, TOTAL), 0.8);
  assert.equal(SB.systemPressure(1.9 * G, TOTAL), 0.92);
  assert.equal(SB.systemPressure(1.0 * G, TOTAL), 1);
  assert.equal(SB.systemPressure(NaN, TOTAL), 0);
});

test('ten tables: low system memory (other programs) holds tables instead of growing, and every hand still completes', async () => {
  let free = 1.2 * G; // below the reserve: pressure 1
  const s = new MT.MultiTableScheduler({ tables: 10, handsPerTable: 4, decisionSource: F.study().src, allowFallback: true, rss: () => 50 * 1024 * 1024, freeMemory: () => free, totalMemory: () => TOTAL });
  const r = await s.run();
  assert.equal(r.handsCompleted, 40, 'held tables are resumed sequentially rather than deadlocked');
  assert.ok(r.memory.systemAware); assert.ok(r.memory.systemPressureEvents > 0); assert.ok(r.memory.pressureEvents > 0, 'tables were held for memory');
  assert.equal(r.memory.minSystemFreeBytes, free);
  assert.equal(r.crashes, 0);
});

test('ten tables with ample free memory are not held; without a probe the scheduler reports it is not system-aware', async () => {
  const a = await new MT.MultiTableScheduler({ tables: 10, handsPerTable: 3, decisionSource: F.study().src, allowFallback: true, rss: () => 50 * 1024 * 1024, freeMemory: () => 12 * G, totalMemory: () => TOTAL }).run();
  assert.equal(a.memory.pressureEvents, 0); assert.equal(a.handsCompleted, 30);
  const b = await new MT.MultiTableScheduler({ tables: 2, handsPerTable: 2, decisionSource: F.study().src, allowFallback: true, freeMemory: null, totalMemory: null }).run();
  assert.equal(b.memory.systemAware, false);
});
