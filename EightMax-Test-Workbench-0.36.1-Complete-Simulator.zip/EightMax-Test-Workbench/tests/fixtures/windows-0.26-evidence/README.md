# 0.26.0 evidence from the target Windows PC (redacted)

Copied from EightMax-Windows-Test-Results-20261118-084905.zip (run 2026-11-18 07:49 local, Windows 11 Home 10.0.26300,
i7-13700F, RTX 4060 Ti, 3840x2160 at 150 %). The user name and computer name were replaced with USER / MACHINE.
The second run (07:38) produced the same failures. Used by tests/windows-repairs-028.test.cjs as reference evidence.
