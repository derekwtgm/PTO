'use strict';
// 0.29.0: seat states. A table has N layout POSITIONS (2-8); each is vacant, sitting-out or in the hand (active / folded / all-in as
// before); a position that turns vacant after being occupied is reported as departed. Measured on the built-in renderer of the
// controlled client only (synthetic pixels) - nothing here is accuracy on an external poker client.
const test = require('node:test'), assert = require('node:assert/strict');
const EM = require('../src/engine.js'), FH = require('../src/full-hand.js'), OCR = require('../src/vision-ocr.js'), SIM = require('../src/sim-display.js');
const none = { decide: async () => ({ status: 'unavailable', reason: 'no solver in this test' }) };
const L8 = SIM.seatStateLayoutFor(8); let kit = null;
const observer = () => { if (!kit) kit = SIM.calibrate([960], L8); return new OCR.ImageObserver({ table: 1, profiles: kit.profiles, cards: kit.cards, glyphs: kit.glyphs, seats: 8 }); };
function copyBox(img, from, to) { const W = img.width, H = img.height, fx = Math.floor(from.x * W), fy = Math.floor(from.y * H), tx = Math.floor(to.x * W), ty = Math.floor(to.y * H), w = Math.ceil(from.w * W), h = Math.ceil(from.h * H); const src = Uint8ClampedArray.from(img.data); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const a = ((fy + y) * W + fx + x) * 4, b = ((ty + y) * W + tx + x) * 4; for (let c = 0; c < 3; c++) img.data[b + c] = src[a + c]; } }
function paint(img, b, v) { for (let y = Math.floor(b.y * img.height) + 1; y < Math.ceil((b.y + b.h) * img.height) - 1; y++) for (let x = Math.floor(b.x * img.width) + 1; x < Math.ceil((b.x + b.w) * img.width) - 1; x++) { const i = (y * img.width + x) * 4; img.data[i] = img.data[i + 1] = img.data[i + 2] = v; } }

test('seat-state layouts for 2-8 positions are valid and conflict-free; the 0.24-0.27 layouts are untouched', () => {
  for (let n = 2; n <= 8; n++) { const L = SIM.seatStateLayoutFor(n); assert.equal(L.seatStates, true); assert.match(L.id, new RegExp('^eightmax-' + n + 'max-v2-ss$')); assert.deepEqual(OCR.validateLayout(L), { valid: true, issues: [] }); assert.deepEqual(OCR.layoutConflicts(L), []); assert.ok(L.seats.every((s) => s.vacant && s.sittingOut)); }
  assert.equal(OCR.defaultLayoutV2(8).seats[0].vacant, undefined);
});
test('the reader separates in-hand, vacant and sitting-out positions and maps button, actor, hero and stacks onto the players in the hand', () => {
  const t = new EM.Table(1, 77, 6); t.startHand(); const map = [0, 'vacant', 1, { sittingOut: 1750 }, 2, 3, 4, 5], o = observer();
  for (const hero of [0, 1, 2, 3, 4, 5]) {
    const r = o.observe(SIM.renderTable(t, 960, { layout: L8, seatMap: map, heroSeat: hero, v2: true }), { heroSeat: map.indexOf(hero) }); assert.equal(r.ok, true, JSON.stringify(r.reasons));
    const ob = r.observation; assert.equal(ob.seats.length, 6); assert.deepEqual(ob.seatMap, [0, 2, 4, 5, 6, 7]); assert.equal(ob.layout.inHand, 6); assert.equal(ob.layout.seats, 8);
    assert.deepEqual(ob.seatStates.map((s) => s.state), ['in-hand', 'vacant', 'in-hand', 'sitting-out', 'in-hand', 'in-hand', 'in-hand', 'in-hand']); assert.equal(ob.seatStates[3].stack, 1750);
    assert.equal(ob.button, t.dealer); assert.equal(ob.actor, t.actor); assert.equal(ob.heroSeat, hero); assert.deepEqual(ob.seats.map((s) => s.stack), t.players.map((p) => p.stack));
    assert.deepEqual(ob.seats[hero].cards, t.players[hero].cards);
  }
});
test('inconsistent seat pictures are rejected, never guessed: chips on a vacant seat, both markers lit, a hand marker on a sitting-out seat', () => {
  const t = new EM.Table(1, 78, 6); t.startHand(); const map = [0, 'vacant', 1, { sittingOut: 1750 }, 2, 3, 4, 5], o = observer();
  const base = () => SIM.renderTable(t, 960, { layout: L8, seatMap: map, heroSeat: 0, v2: true });
  let img = base(); paint(img, L8.seats[1].stack, 255); let r = o.observe(img, { heroSeat: 0 }); assert.equal(r.ok, false); assert.ok(r.reasons.some((x) => /marked vacant but shows chips/.test(x)), r.reasons.join('|'));
  img = base(); paint(img, L8.seats[1].sittingOut, 255); r = o.observe(img, { heroSeat: 0 }); assert.equal(r.ok, false); assert.ok(r.reasons.some((x) => /both vacant and sitting-out/.test(x)));
  img = base(); paint(img, L8.seats[3].folded, 255); r = o.observe(img, { heroSeat: 0 }); assert.equal(r.ok, false); assert.ok(r.reasons.some((x) => /sitting out but shows/.test(x)));
});
for (const [n, map] of [[6, [0, 'vacant', 1, { sittingOut: 1750 }, 2, 3, 4, 5]], [5, [0, 1, 2, { sittingOut: 4000 }, 'vacant', 3, 'vacant', 4]], [3, [0, 'vacant', 'vacant', 1, { sittingOut: 900 }, 'vacant', 2, 'vacant']], [2, ['vacant', 0, 'vacant', 'vacant', { sittingOut: 300 }, 1, 'vacant', 'vacant']]]) {
  test('complete hands from pixels with ' + n + ' players on an 8-position table (vacant and sitting-out positions): chips conserved, nothing rejected', async () => {
    const table = new EM.Table(1, 900 + n, n), client = new FH.OfflineClient(table, { render: { layout: L8, seatMap: map } });
    const p = new FH.SingleTablePipeline({ client, vision: FH.makeVision(1, undefined, 8, { seatStates: true }), decisionSource: none, allowScripted: true, scriptedWhen: () => true, seed: 5, engineOptions: { seats: n, expectedLayout: L8.id } });
    const rep = await p.run(6); assert.equal(rep.completed, 6); assert.equal(rep.totals.suspended, 0); assert.equal(rep.totals.rejectedFrames, 0); assert.equal(rep.totals.ackMismatches, 0);
    assert.equal(table.players.reduce((a, q) => a + q.stack, 0), n * 2500); assert.ok(p.hands.every((h) => h.settlementOk && h.final.length === n));
  });
}
test('strategy safety is kept: with fewer than eight players in the hand an 8-handed strategy is never applied (explicit player-count-unsupported)', async () => {
  let asked = 0; const eager = { decide: async () => { asked++; return { status: 'ok', decision: { probabilities: { fold: 1 } } }; } };
  const table = new EM.Table(1, 960, 6), client = new FH.OfflineClient(table, { render: { layout: L8, seatMap: [0, 'vacant', 1, { sittingOut: 1750 }, 2, 3, 4, 5] } });
  const p = new FH.SingleTablePipeline({ client, vision: FH.makeVision(1, undefined, 8, { seatStates: true }), decisionSource: eager, allowScripted: true, scriptedWhen: () => false, seed: 5, engineOptions: { seats: 6, expectedLayout: L8.id } });
  const rep = await p.run(2); assert.equal(rep.completed, 2); assert.equal(rep.totals.solverActions, 0); assert.equal(asked, 0, 'the 8-handed source is never even asked'); const codes = p.unavailableCodes instanceof Map ? Object.fromEntries(p.unavailableCodes) : p.unavailableCodes; assert.ok((codes['player-count-unsupported'] || 0) > 0, JSON.stringify(codes));
});
test('SeatTracker reports departed and joined positions across hands without guessing identities', () => {
  const tr = new OCR.SeatTracker(), S = (...x) => x.map((state, seat) => ({ seat, state }));
  tr.update(S('in-hand', 'in-hand', 'vacant', 'sitting-out'), 1);
  const out = tr.update(S('in-hand', 'vacant', 'in-hand', 'vacant'), 2);
  assert.equal(out[1].state, 'departed'); assert.equal(out[1].departedAfterHand, 1); assert.equal(out[3].state, 'departed'); assert.equal(out[2].state, 'in-hand');
  assert.deepEqual(tr.events.map((e) => e.seat + ':' + e.event), ['1:departed', '2:joined', '3:departed']);
  assert.equal(tr.update(S('in-hand', 'vacant', 'in-hand', 'vacant'), 3)[1].state, 'vacant', 'a seat that stays empty is vacant, not departed again');
});
test('variable-stack tables work at every seat count (0.27 regression: the stack policy received the hand number as its seat count)', async () => {
  for (const n of [8, 6, 3]) {
    const table = new EM.Table(1, 700 + n, n), client = new FH.OfflineClient(table, { stackPolicy: FH.variableStacks });
    const p = new FH.SingleTablePipeline({ client, vision: FH.makeVision(1, undefined, n), decisionSource: none, allowScripted: true, scriptedWhen: () => true, seed: 3 });
    const rep = await p.run(4); assert.equal(rep.completed, 4, n + ' seats'); assert.equal(rep.totals.suspended, 0);
  }
});
