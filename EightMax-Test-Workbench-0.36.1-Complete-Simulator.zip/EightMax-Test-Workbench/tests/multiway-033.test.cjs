'use strict';
// 0.33: independent N-player evaluator (src/independent-eval.js): analytic reference games, own side-pot accounting and hand evaluator,
// geometry cross-check against the EightMax tree, exact agreement with the engine's best response, multiway linked-record evaluation.
const test = require('node:test'), assert = require('node:assert'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const EM = require('./load-solver.cjs'), A = require('../src/study-adapter.js'), X = require('../src/exploitability.js'), IE = require('../src/independent-eval.js'), LK = require('../src/linked-study.js'), Q = require('../src/strategy-quality.js');
const cli = process.env.EIGHTMAX_TEST_CLI && fs.existsSync(process.env.EIGHTMAX_TEST_CLI) ? process.env.EIGHTMAX_TEST_CLI : null;
const rng = (l) => l.map((s) => { const c = IE.cards(s); return [c[0], c[1], 1]; });
const passive = (seat, node) => node.actions.map((a) => (a.kind === 'check' || a.kind === 'fold' ? 1 : 0));

test('analytic: 2-player Kuhn equilibrium family has value -1/18 for player 1 and NashConv 0 (exact)', () => {
  for (const al of [0, 0.15, 1 / 3]) {
    const s = (seat, node, b, ti) => { const p = node.path; if (seat === 0) { if (p === 'r') return ti === 0 ? [1 - al, al] : ti === 1 ? [1, 0] : [1 - 3 * al, 3 * al]; return ti === 0 ? [1, 0] : ti === 1 ? [2 / 3 - al, al + 1 / 3] : [0, 1]; } if (p === 'r0') return ti === 0 ? [2 / 3, 1 / 3] : ti === 1 ? [1, 0] : [0, 1]; return ti === 0 ? [1, 0] : ti === 1 ? [2 / 3, 1 / 3] : [0, 1]; };
    const e = IE.evaluate(IE.kuhn(2), s); assert.ok(Math.abs(e.values[0] + 1 / 18) < 1e-12, 'value ' + e.values[0]); assert.ok(Math.abs(e.nashConv) < 1e-12); assert.ok(Math.abs(e.exploitability) < 1e-12);
  }
  // a non-equilibrium profile is detected: player 2 never bluffs -> player 1 gains
  const bad = (seat, node, b, ti) => (seat === 1 && node.path === 'r0' ? (ti === 2 ? [0, 1] : [1, 0]) : node.actions.map((_, a) => (a === 0 ? 1 : 0)));
  assert.ok(IE.evaluate(IE.kuhn(2), bad).nashConv > 0.01);
});
test('analytic: 3-player Kuhn check/fold profile has NashConv exactly 6; independent CFR lowers NashConv', () => {
  const e = IE.evaluate(IE.kuhn(3), passive); assert.deepStrictEqual(e.gains, [2, 2, 2]); assert.strictEqual(e.nashConv, 6); assert.ok(!('exploitability' in e), 'no two-player exploitability for 3 players'); assert.match(e.note, /not an exploitability/i);
  const a = IE.evaluate(IE.kuhn(3), IE.cfr(IE.kuhn(3), 200)).nashConv, b = IE.evaluate(IE.kuhn(3), IE.cfr(IE.kuhn(3), 2000)).nashConv; assert.ok(b < a && b < 0.03, a + ' -> ' + b);
});
test('analytic: 3-player hold\'em river, passive profile: NashConv = 2 x pot, values sum to the pot', () => {
  const G = IE.holdem({ board: 'AhKd7c2s9h', common: 6, stacks: [12, 12, 12], hands: [rng(['AsAc', 'KcKh', '7d7h']), rng(['AdKs', 'Ts9s', 'QhQd']), rng(['KsQs', '6h6d', 'AcKc'])], streets: { river: { bets: '50', raises: 'a', maxBets: 1 } } });
  const e = IE.evaluate(G, passive); assert.ok(Math.abs(e.nashConv - 12) < 1e-9); assert.ok(Math.abs(e.valueSum - 6) < 1e-9); assert.strictEqual(e.classification, 'exact');
});
test('own side-pot accounting: main and side pots, folded chips, uncalled excess, common money, ties', () => {
  assert.deepStrictEqual(IE.settle([10, 5, 10], [true, true, true], [1, 3, 2], 0), [-10, 10, 0]);          // seat 1 wins the 15 main pot, seat 2 the 10 side pot
  assert.deepStrictEqual(IE.settle([10, 5, 10], [true, true, true], [3, 1, 2], 6), [21, -5, -10]);        // seat 0 wins everything incl. common 6
  assert.deepStrictEqual(IE.settle([4, 10, 0], [true, true, false], [1, 2, null], 3), [-4, 7, 0]);         // seat 1: main 8+3; its 6 excess returned
  assert.deepStrictEqual(IE.settle([6, 6, 2], [true, true, false], [2, 2, null], 0), [1, 1, -2]);          // tie splits, folded 2 stays in the pot
  assert.deepStrictEqual(IE.settle([3, 8, 8], [false, true, true], [null, 5, 5], 1), [-3, 2, 2]);           // folded seat's chips split by tied winners
  // agrees with exploitability.payoff on random terminals
  let x = 7; const rnd = () => { x = (Math.imul(x, 1103515245) + 12345) >>> 0; return x / 4294967296; };
  for (let t = 0; t < 300; t++) { const n = 3, contrib = Array.from({ length: n }, () => Math.round(rnd() * 20) / 2), live = contrib.map(() => rnd() < 0.8); if (!live.some(Boolean)) live[0] = true; const topLive = Math.max(...contrib.filter((_, i) => live[i])); if (contrib.some((c, i) => !live[i] && c > topLive)) continue;   // illegal: a seat folds only when facing a larger live wager
    const sc = live.map((l) => (l ? Math.floor(rnd() * 4) : null)), common = Math.round(rnd() * 6);
    const total = common + contrib.reduce((a, b) => a + b, 0), mine = IE.settle(contrib, live, sc, common), theirs = X.payoff({ contrib, live, total }, sc, common);
    assert.ok(Math.abs(mine.reduce((a, b) => a + b, 0) - common) < 1e-9, 'chips conserved'); mine.forEach((v, i) => assert.ok(Math.abs(v - theirs[i]) < 1e-9, JSON.stringify({ contrib, live, sc, common, mine, theirs }))); }
});
test('own 7-card evaluator orders hands exactly like exploitability.score7 and the engine evaluator (random boards)', () => {
  let x = 99; const rnd = () => { x = (Math.imul(x, 1103515245) + 12345) >>> 0; return x / 4294967296; };
  for (let t = 0; t < 1500; t++) { const deck = Array.from({ length: 52 }, (_, i) => i); for (let i = 51; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
    const board = deck.slice(0, 5), a = board.concat(deck.slice(5, 7)), b = board.concat(deck.slice(7, 9));
    const s = Math.sign(IE.rank5of7(a) - IE.rank5of7(b)), r = Math.sign(X.score7(a) - X.score7(b)), e = Math.sign(EM.evalCards(a) - EM.evalCards(b)); assert.strictEqual(s, r, a + ' vs ' + b); assert.strictEqual(r, e); }
});
test('independent betting rules reproduce the EightMax tree of a 3-player turn game node by node', () => {
  const m = { bets: '50', raises: 'a', maxBets: 1 }, cfg = { board: 'AhKd7c2s', common: 6, stacks: [12, 12, 12], ranges: Array(3).fill('AA,KK,77,AK,KQs,T9s'), streets: { turn: m, river: m }, privateSeed: 3 };
  const p = A.prepare(EM, { config: cfg, iterations: 1 }), G = IE.holdem({ board: cfg.board, common: 6, stacks: cfg.stacks, hands: p.spec.hands.map((l) => l.map((h) => [h[1], h[2], h[3]])), streets: cfg.streets });
  const g = IE.compareGeometry(G, (s) => p.game.view(s)); assert.ok(g.checked > 150); assert.deepStrictEqual(g.mismatches, []);
  const m2 = { bets: '33,a', raises: '2.5x,a', maxBets: 2 }, cfg2 = { board: 'Ks8d5h2c2s', common: 12, stacks: [30, 18, 30], ranges: Array(3).fill('AA,KK,88'), streets: { river: m2 }, privateSeed: 1 };
  const p2 = A.prepare(EM, { config: cfg2, iterations: 1 }), G2 = IE.holdem({ board: cfg2.board, common: 12, stacks: cfg2.stacks, hands: p2.spec.hands.map((l) => l.map((h) => [h[1], h[2], h[3]])), streets: cfg2.streets });
  assert.deepStrictEqual(IE.compareGeometry(G2, (s) => p2.game.view(s)).mismatches, [], 'raises, multiples and a short stack (side pots)');
});
test('NashConv correctness: independent evaluator == native engine exact best response on a trained 3-player river study', { skip: !cli && 'native EightMax CLI not available (set EIGHTMAX_TEST_CLI)' }, () => {
  const m = { bets: '50,a', raises: 'a', maxBets: 2 }, cfg = { board: 'Ks8d5h2c2s', common: 12, stacks: [20, 20, 20], ranges: Array(3).fill('AA,KK,88,AK,KQs,QJs,55'), streets: { river: m }, privateSeed: 4 };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em-mw033t-')), p = A.prepare(EM, { config: cfg, iterations: 30000, strategyBudgetMiB: 64 }), spec = A.nativeJob(p, 't').spec, sf = path.join(dir, 's.json'), st = path.join(dir, 'o.state'), rq = path.join(dir, 'q.json');
  try {
    fs.writeFileSync(sf, JSON.stringify(spec)); assert.strictEqual(cp.spawnSync(cli, [sf, '30000', '1', st, '512']).status, 0);
    fs.writeFileSync(rq, JSON.stringify({ method: 'exact', seats: [0, 1, 2], samples: 100, seed: 1, timeLimitMs: 300000, threads: 1 }));
    const r = cp.spawnSync(cli, ['--gain', sf, st, rq, '1024'], { encoding: 'utf8', maxBuffer: 1 << 26 }), nat = JSON.parse(r.stdout.slice(r.stdout.indexOf('{'), r.stdout.lastIndexOf('}') + 1));
    const G = IE.holdem({ board: cfg.board, common: 12, stacks: cfg.stacks, hands: spec.hands.map((l) => l.map((h) => [h[1], h[2], h[3]])), streets: cfg.streets }), rd = IE.readNativeRows(fs.readFileSync(st), spec, G.board), e = IE.evaluate(G, rd.strategy.bind(rd));
    nat.seats.forEach((s, i) => assert.ok(Math.abs(s.gain - e.gains[i]) < 1e-9, 'seat ' + i + ': engine ' + s.gain + ' vs independent ' + e.gains[i]));
    // independent reconstruction of the stored strategy == the engine's own reader
    p.game.importNative(fs.readFileSync(st)); let n = 0; for (const [k, v] of rd.rows) { const [ph, cs, seat, hi] = k.split('|'), h = spec.hands[+seat][+hi], s = p.game.averageAt(ph, cs.split('.').map(Number), +seat, { id: h[0], a: h[1], b: h[2], w: h[3] }); if (!s) continue; v.forEach((x, a) => assert.ok(Math.abs(x - s[a]) < 1e-12)); if (++n > 400) break; }
    assert.ok(n > 50);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
test('multiway linked records: 0.33 stores the betting rules and evaluateLinked gives an exact independent NashConv (classified by the multiway limit)', () => {
  const m = { bets: '50', raises: 'a', maxBets: 1 }, cfg = { board: 'Ks8d5h2c2s', common: 12, stacks: [20, 20, 20], ranges: Array(3).fill('AA,KK,88,AK'), streets: { river: m }, privateSeed: 2 };
  const p = A.prepare(EM, { config: cfg, iterations: 4000 }); p.game.iterate(4000);
  const rec = LK.open(LK.exportLinked(p, { EM })); assert.ok(rec.meta.rules && rec.meta.rules.sizes[5], 'rules stored');
  const ev = Q.evaluateLinked(rec, { potBB: 12 }); assert.strictEqual(ev.type, 'exact', ev.reason); assert.strictEqual(ev.evaluator, 'independent'); assert.ok(ev.nashConvBB >= -1e-9 && ev.gainsBB.length === 3);
  const c = Q.classify({ ...ev, players: 3, potBB: 12 }, 'research'); assert.ok(['validated', 'failed-quality-check', 'unverified'].includes(c.status)); assert.match(c.reason, /NashConv \(multiway; not a two-player exploitability\)|never visited/);
  // a record without rules (0.32 export) is not evaluated, never reported as 0
  const old = LK.open(LK.exportLinked(p, { EM })); old.meta.rules = null; const ev2 = Q.evaluateLinked(old, { potBB: 12 }); assert.strictEqual(ev2.type, 'none'); assert.strictEqual(ev2.nashConvBB, undefined);
});
