'use strict';
// 0.29.0 continuous capture: persistent Windows Graphics Capture sessions in the host (real CaptureService code under Mono with a
// fake helper process), window-move and DPI-change handling in the capture session, and the invalid-frame action gate.
// No Windows Graphics Capture happens here.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const C = require('../src/screen-capture.js'), EM = require('../src/engine.js'), SIM = require('../src/sim-display.js'), { CODES } = C;
const root = path.join(__dirname, '..'), read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const has = (c, a = ['--version']) => { try { cp.execFileSync(c, a, { stdio: 'pipe' }); return true; } catch (e) { return false; } };
function clockFrom(start = 1000) { let t = start; const c = () => t; c.advance = (ms) => { t += ms; }; return c; }
function rig(o = {}) { const t = new EM.Table(1, 5); t.startHand(); const clock = clockFrom(); const src = new C.SimulatedWindowSource((w, id) => SIM.renderTable(t, w, { v2: true, seed: id }), { clock, width: 960, ...o }); const session = new C.CaptureSession(src, { clock, settleFrames: 2, maxFrameAgeMs: 500 }); session.state = 'live'; return { src, clock, session }; }

test('host keeps ONE helper session per window: newest frame served, unchanged content marked not fresh, sessions end and leave no process', { skip: has('mcs') && has('mono') ? false : 'Mono not installed', timeout: 120000 }, () => {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em-ws-')), exe = path.join(d, 'ws.exe'), pids = path.join(d, 'pids');
  cp.execFileSync('mcs', ['-langversion:5', '-main:WgcStreamHarness', '-r:System.Web.Extensions', '-r:System.Windows.Forms', '-r:System.Drawing', '-out:' + exe, path.join(root, 'tests/mono/WgcStreamHarness.cs'), path.join(root, 'desktop/CaptureService.cs')], { stdio: 'pipe' });
  const out = cp.execFileSync('mono', [exe, path.join(root, 'tests/fixtures/wgc-stubs/wgc-session.sh')], { encoding: 'utf8', timeout: 60000, env: { ...process.env, WGC_STUB_PIDS: pids } });
  const r = Object.fromEntries(out.trim().split('\n').map((l) => { const j = JSON.parse(l); return [j.case, j]; }));
  assert.equal(r.first.ok, true); assert.equal(r.first.frameId, 1); assert.equal(r.first.sessions, 1);
  assert.equal(r.second.frameId, 3, 'the newest frame is served (frame 2 was superseded, never queued as stale)'); assert.equal(r.second.framesFromSession, 3); assert.equal(r.second.sessions, 1, 'same session reused: no new capture session per frame');
  assert.equal(r['third-no-new-content'].fresh, false); assert.equal(r['third-no-new-content'].frameId, 3);
  assert.equal(r['other-window'].sessions, 2); assert.equal(r['close-all'].closed, 2); assert.equal(r['close-all'].sessions, 0);
  assert.equal(r['lost-after'].ok, false); assert.equal(r['lost-after'].code, 'target-lost'); assert.equal(r['lost-after'].sessions, 0);
  assert.equal(r.refused.code, 'target-minimized', 'the helper refusal code is passed through, no fallback');
  cp.execFileSync('sleep', ['1']); const started = fs.readFileSync(pids, 'utf8').trim().split('\n');
  assert.equal(started.length, 5); for (const p of started) { let alive = true; try { process.kill(+p, 0); } catch (e) { alive = false; } assert.equal(alive, false, 'helper ' + p + ' still running'); }
});
test('host wiring: capture close and host shutdown end persistent sessions; health reports them', () => {
  const h = read('desktop/DesktopHost.cs'), cs = read('desktop/CaptureService.cs');
  assert.match(h, /\/api\/capture\/close"\)\{[^\n]*CaptureService\.CloseStream\(ct\)/); assert.match(h, /CaptureService\.CloseAllStreams\(\)/); assert.match(h, /activeCaptureSessions=CaptureService\.StreamCount/);
  assert.match(cs, /"--session --emit-png --hwnd "/); assert.match(read('desktop/wgc/Program.cs'), /emitPng && !f\.Blank/, 'blank frames never carry pixels');
  assert.match(cs, /const int MaxStreams = 10;/);
});
test('a window move is recorded without invalidating content; a DPI change restarts settling like a resize', async () => {
  const { src, clock, session } = rig(); await src.open();
  for (let i = 0; i < 3; i++) { clock.advance(100); await session.tick(); }
  src.moveTo(400, 300); clock.advance(100); const moved = await session.tick();
  assert.equal(moved.valid, true); assert.equal(moved.moved, true); assert.equal(session.status().moves, 1);
  src.setDpiScale(1.5); clock.advance(100); const settling = await session.tick();
  assert.equal(settling.valid, false); assert.equal(settling.code, CODES.RESIZING); assert.equal(settling.image, null, 'no pixels from an unsettled frame');
  clock.advance(100); const ok = await session.tick(); assert.equal(ok.valid, true); assert.equal(ok.dpiScale, 1.5); assert.equal(session.status().dpiChanges, 1);
});
test('invalid frames never reach action execution: the observation gate refuses them', async () => {
  const CM = require('../src/capture-manager.js'); assert.equal(typeof CM.ObservationGate, 'function');
  const { src, clock, session } = rig(); await src.open(); clock.advance(100); await session.tick();
  src.set({ minimized: true }); clock.advance(100); const f = await session.tick(); assert.equal(f.valid, false); assert.equal(f.image, null);
  assert.match(read('src/capture-manager.js'), /class ObservationGate/);
});
