'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),MS=require('../src/movement-settings.js'),M=require('../src/input-motion.js'),D=require('../src/windows-input-driver.js');
test('seeded curves reproduce, vary per operation, preserve endpoints and stay within analytic limits',()=>{
 for(const maxSpeed of [600,1200,2000]){
  const a=new MS.Sequence({pattern:'random',seed:19,variation:1}),b=new MS.Sequence({pattern:'random',seed:19,variation:1});const arcs=new Set();
  for(let i=0;i<100;i++){
   const p=M.profile({maxSpeed,arc:.25}),x=a.next(p),y=b.next(p);assert.deepEqual(x,y);arcs.add(x.profile.arc);
   const plan=M.plan({x:-100,y:50},{x:1800,y:900},x.profile);assert.equal(plan.points.at(-1).x,1800);assert.equal(plan.points.at(-1).y,900);assert.ok(plan.peakSpeed<=maxSpeed+1e-6);assert.ok(plan.peakAccel<=p.maxAccel+1e-6);assert.ok(plan.durationMs<=M.durationMs(plan.distance,p)+1e-6);
  }assert.equal(arcs.size,100);
 }
});
test('fixed and straight selection, invalid settings, no mutation',()=>{
 const p=M.profile({arc:.2});assert.equal(new MS.Sequence({pattern:'straight'}).next(p).profile.arc,0);assert.equal(new MS.Sequence({pattern:'fixed'}).next(p).profile.arc,.2);assert.equal(p.arc,.2);
 for(const o of [{seed:0},{seed:1.1},{variation:2},{pattern:'jitter'}])assert.throws(()=>new MS.Sequence(o));
});
test('driver sends bounded profile and records selected curve; dry-run never clicks',async()=>{
 const commands=[],traces=[],session={call:async(cmd,args)=>{commands.push({cmd,args});return cmd==='window-info'?{window:{client:{x:0,y:0,w:1000,h:600}}}:{ok:true};}};
 const driver=new D.WindowsUiDriver({session,hwnd:'0x1',dryRun:true,motion:{arc:.2},movement:{pattern:'random',seed:2},onTrace:x=>traces.push(x)});
 await driver.activate('call',{x:.8,y:.8,w:.1,h:.1});assert.equal(commands.at(-1).cmd,'move');assert.ok(commands.at(-1).args.motion.arc<=.2);assert.ok(traces.some(x=>x.kind==='motion-plan'&&x.index===0));
});
