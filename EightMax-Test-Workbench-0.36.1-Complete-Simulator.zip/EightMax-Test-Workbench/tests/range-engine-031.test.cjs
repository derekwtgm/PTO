'use strict';
/* 0.31 opponent range engine: weighted ranges, Bayesian action conditioning, card removal, multiway tracking, street continuity,
 * invalid-range rejection and provenance. Every expected value here is computed by hand from the fixture strategies. */
const test = require('node:test'), assert = require('node:assert/strict');
const RE = require('../src/range-engine.js'), RM = require('../src/range-model.js'), F = require('./range-fixture.cjs'), EM = F.EM;
const close = (a, b, eps = 1e-9) => assert.ok(Math.abs(a - b) <= eps, a + ' != ' + b);
const classWeight = (r, cls) => RE.CLASS_COMBOS.get(cls).reduce((a, i) => a + r.w[i], 0);
const N_AA = 6, N_KK = 6, N_AKS = 4, N_72O = 12, N_REST = 1326 - 6 - 6 - 4 - 12;

test('combination order, classes and card ids are identical to EightMax 5.1', () => {
  for (let i = 0; i < 1326; i++) { assert.equal(RE.C1[i], EM.C1[i]); assert.equal(RE.C2[i], EM.C2[i]); assert.equal(RE.CLASS[i], EM.CLASS_NAMES[EM.CLS[i]]); }
  assert.equal(RE.CLASS_NAMES.length, 169); assert.equal(RE.comboIndex('As', 'Ah'), RE.comboIndex('Ah', 'As')); assert.throws(() => RE.comboIndex('As', 'As'));
});

test('weighted preflop ranges: class weights, text weights and the study text round trip', () => {
  const r = RE.WeightedRange.fromText(EM, 'QQ+,AKs:0.5,72o:0.25');
  close(classWeight(r, 'AA'), 6); close(classWeight(r, 'AKs'), 2); close(classWeight(r, '72o'), 3); assert.equal(r.combos(), 6 * 3 + 4 + 12);
  const t = r.toStudyText(EM, { quantum: 0.01 }); assert.equal(t.droppedMassShare, 0); assert.ok(t.maxAbsWeightError < 1e-6);
  const back = RE.WeightedRange.fromText(EM, t.text); for (let i = 0; i < 1326; i++) close(back.w[i], r.w[i], 1e-6);
  const c = RE.WeightedRange.fromClassWeights({ AA: 1, KK: 0.5 }); close(c.total(), 9); assert.equal(c.provenance, 'manual');
  assert.throws(() => new RE.WeightedRange(new Float64Array(1325)), /1,326/); const bad = new Float64Array(1326); bad[3] = -1; assert.throws(() => new RE.WeightedRange(bad), /non-negative/);
});

test('position-specific ranges and the raise update are exact Bayes under the stored strategy', () => {
  const src = F.fakePreflop(), r = RE.preflopRanges(src, { button: F.BUTTON, actions: F.preflopActions('rffffffc') }, {});
  assert.equal(r.status, 'ok');
  const opener = r.ranges.get(0);   // raised: weight = P(raise | class)
  close(classWeight(opener, 'AA'), N_AA * 1); close(classWeight(opener, 'KK'), N_KK * 0.5); close(classWeight(opener, 'AKs'), 0); close(classWeight(opener, '72o'), 0);
  close(opener.total(), N_AA + N_KK * 0.5 + N_REST * 0.1);
  const p = opener.normalized(), iAA = RE.comboIndex('As', 'Ah'); close(p[iAA], 1 / (N_AA + 3 + N_REST * 0.1));
  assert.equal(opener.provenance, 'derived-approximate-strategy'); assert.equal(opener.events[0].kind, 'action'); close(opener.events[0].actionProbability, (N_AA + 3 + N_REST * 0.1) / 1326, 1e-6);
});

test('call and fold updates; folded players keep a (fold-conditioned) range but are not live', () => {
  const src = F.fakePreflop(), r = RE.preflopRanges(src, { button: F.BUTTON, actions: F.preflopActions('cfffffff') }, {});
  const caller = r.ranges.get(0), folder = r.ranges.get(1);
  close(classWeight(caller, 'AKs'), N_AKS); close(classWeight(caller, 'KK'), 3); close(classWeight(caller, 'AA'), 0); close(caller.total(), 4 + 3 + N_REST * 0.3);
  close(classWeight(folder, '72o'), N_72O); close(classWeight(folder, 'AA'), 0); close(folder.total(), N_72O + N_REST * 0.6);
});

test('card removal: board and known cards remove exactly the combinations that contain them', () => {
  const r = RE.WeightedRange.anyTwo(); r.removeCards(['As', 'Kd', '2c']);
  assert.equal(r.combos(), 1326 - 3 * 51 + 3); assert.equal(r.events[0].kind, 'card-removal'); close(r.events[0].massRemoved, 3 * 51 - 3);
  assert.ok(r.validate(['As', 'Kd', '2c']).valid); const r2 = RE.WeightedRange.anyTwo(); assert.equal(r2.validate(['As']).valid, false);
  const aa = RE.WeightedRange.fromText(EM, 'AA'); aa.removeCards(['As', 'Ah', 'Ad']); assert.equal(aa.combos(), 0); assert.ok(aa.invalid); assert.equal(aa.validate().valid, false);
});

test('multiway tracking: three and four players stay separate and only their own actions condition them', () => {
  const src = F.fakePreflop(), r = RE.preflopRanges(src, { button: F.BUTTON, actions: F.preflopActions('rccffffc') }, {});
  const live = [0, 1, 2, 7]; assert.equal(r.status, 'ok');
  for (const s of [1, 2, 7]) { const c = r.ranges.get(s); close(classWeight(c, 'AKs'), N_AKS); close(classWeight(c, 'AA'), 0); assert.equal(c.events.length, 1); assert.equal(c.events[0].seat, s); }
  close(classWeight(r.ranges.get(0), 'AA'), N_AA);
  const t = new RE.RangeTracker(1, 1); t.startPreflop(r); const ss = t.streetStart('flop', ['Ac', 'Kh', '7d'], live);
  assert.deepEqual([...ss.keys()], live); assert.ok(classWeight(ss.get(0), 'AA') < N_AA);   // AA combos with the Ac removed
  close(classWeight(ss.get(0), 'AA'), 3);
});

test('street continuity: flop actions condition the turn ranges with the stored flop strategy (with a suit permutation)', () => {
  const ranges = new Map([[3, RE.WeightedRange.anyTwo()], [5, RE.WeightedRange.anyTwo()]]), st = F.fakeStreet(2);
  // seat 3 checks, seat 5 bets, seat 3 calls
  const res = RE.conditionOnStreet(ranges, st.game, st.spec, [3, 5], [{ seat: 3, type: 'check' }, { seat: 5, type: 'bet', amount: 200 }, { seat: 3, type: 'call', amount: 200 }], { street: 'flop', perm: [1, 0, 2, 3] });
  assert.equal(res.status, 'ok');
  const a = ranges.get(3), b = ranges.get(5);
  close(classWeight(a, 'AA'), 0); close(classWeight(a, '72o'), 0); close(classWeight(a, 'KK'), 6 * 0.75 * 0.5);   // check then call
  close(classWeight(b, 'AA'), 6); close(classWeight(b, '72o'), 0); close(classWeight(b, 'KK'), 6 * 0.25);          // bet
  assert.equal(a.events.length, 2); assert.equal(b.events.length, 1);
  const off = RE.conditionOnStreet(new Map([[3, RE.WeightedRange.anyTwo()], [5, RE.WeightedRange.anyTwo()]]), st.game, st.spec, [3, 5], [{ seat: 3, type: 'bet', amount: 900 }], { street: 'flop' });
  assert.equal(off.status, 'unknown'); assert.match(off.reason, /not in the study menu/);
  const wrongSeat = RE.conditionOnStreet(new Map([[3, RE.WeightedRange.anyTwo()], [5, RE.WeightedRange.anyTwo()]]), st.game, st.spec, [3, 5], [{ seat: 5, type: 'check' }], { street: 'flop' });
  assert.equal(wrongSeat.status, 'unknown');
});

test('invalid ranges are rejected: impossible observed action, likelihood outside [0,1], NaN weights', () => {
  const r = RE.WeightedRange.fromText(EM, 'AKs'), lik = new Float64Array(1326);   // every likelihood 0
  r.condition(lik, { action: 'raise' }); assert.ok(r.invalid); assert.equal(r.validate().valid, false); close(r.total(), 4);   // prior kept, flagged
  const bad = new Float64Array(1326).fill(2); assert.throws(() => RE.WeightedRange.anyTwo().condition(bad), /outside/);
  const w = new Float64Array(1326).fill(1); w[7] = NaN; assert.throws(() => new RE.WeightedRange(w), /finite/);
});

test('unsupported combinations (no stored row) keep their prior weight and are reported, never invented', () => {
  const src = F.fakePreflop({ missing: [[0, 'QQ']] }), r = RE.preflopRanges(src, { button: F.BUTTON, actions: F.preflopActions('rfffffff') }, {});
  const o = r.ranges.get(0); close(classWeight(o, 'QQ'), 6); assert.equal(o.unsupported.length, 1); assert.equal(o.unsupported[0].combos, 6); close(o.unsupported[0].massShare, 6 / 1326, 1e-6);   // reported to 6 decimals
});

test('off-tree preflop history gives an UNKNOWN range with the reason', () => {
  const src = F.fakePreflop(), acts = F.preflopActions('rfffffff'); acts[0].amount = 777;
  const r = RE.preflopRanges(src, { button: F.BUTTON, actions: acts }, {}); assert.equal(r.status, 'unknown'); for (const [, x] of r.ranges) assert.equal(x.provenance, 'unknown');
});

test('provenance ordering and observed-tendency estimates are labelled with an interval', () => {
  assert.equal(RE.worse('derived-validated-strategy', 'derived-approximate-strategy'), 'derived-approximate-strategy'); assert.equal(RE.worse('unknown', 'manual'), 'unknown');
  const few = RE.fromTendencies({ hands: 5, vpip: 2 }, { EM }); assert.equal(few.range.provenance, 'unknown');
  const t = RE.fromTendencies({ hands: 400, vpip: 100 }, { EM }); assert.equal(t.range.provenance, 'observed-tendencies'); assert.ok(t.interval.ci95[0] < 0.25 && 0.25 < t.interval.ci95[1]);
  assert.ok(classWeight(t.range, 'AA') === 6 && classWeight(t.range, '72o') === 0);
});

test('derived model vs any-two-cards: comparison is measurable and the derived range is narrower', () => {
  const src = F.fakePreflop(), r = RE.preflopRanges(src, { button: F.BUTTON, actions: F.preflopActions('rfffffff') }, {});
  const cmp = r.ranges.get(0).compare(RE.WeightedRange.anyTwo()); assert.ok(cmp.totalVariation > 0.05 && cmp.totalVariation < 1); close(cmp.overlap, 1 - cmp.totalVariation, 1e-6);
});

test('library range model: preflop line -> flop -> turn with continuity, fallback and unavailable modes', () => {
  const src = F.fakePreflop(), model = new RM.LibraryRangeModel({ preflopSource: src, EM });
  const base = { table: 1, hand: 9, button: F.BUTTON, stacks: Array(8).fill(2500), blinds: { sb: 50, bb: 100, ante: 10 } };
  const pre = F.preflopActions('rfffffff').map((a, i) => (i === 7 ? { ...a, type: 'call', amount: 300 } : a));
  const flop = model.rangesFor({ ...base, street: 'flop', actions: pre }, { live: [0, 7] });
  assert.equal(flop.name, 'preflop-line-v1[q=0.02]'); assert.equal(flop.texts.length, 2); assert.equal(flop.provenance, 'derived-approximate-strategy'); assert.ok(!flop.fallback);
  // a stored flop study was used on the flop: the turn ranges are conditioned on the flop actions
  const st = F.fakeStreet(2); model.noteStudy({ ...base, street: 'flop' }, { game: st.game, spec: st.spec, seatOrder: [0, 7], perm: null, isomorphismApplied: false, validated: false });
  const flopActs = [{ seat: 0, street: 'flop', type: 'bet', amount: 200 }, { seat: 7, street: 'flop', type: 'call', amount: 200 }];
  const turn = model.rangesFor({ ...base, street: 'turn', actions: pre.concat(flopActs) }, { live: [0, 7] });
  assert.equal(turn.name, 'street-conditioned-v1[q=0.02]'); assert.ok(turn.texts[0] !== flop.texts[0]); assert.equal(model.info().streetConditioned, 1);
  // no stored turn study: river ranges are carried forward and the decision is warned
  const river = model.rangesFor({ ...base, street: 'river', actions: pre.concat(flopActs, [{ seat: 0, street: 'turn', type: 'check' }, { seat: 7, street: 'turn', type: 'check' }]) }, { live: [0, 7] });
  assert.ok(river.warnings.some((w) => /NOT updated for the turn/.test(w))); assert.equal(river.name, 'preflop-line-v1[q=0.02]');
  // stacks that differ from the preflop study: unknown -> fallback to any-two (labelled) or unavailable
  const fb = model.rangesFor({ ...base, hand: 10, stacks: Array(8).fill(1800), street: 'flop', actions: pre }, { live: [0, 7] }); assert.ok(fb.fallback); assert.equal(fb.name, 'any-two-cards-v1'); assert.ok(fb.warnings[0].startsWith('FALLBACK'));
  const strict = new RM.LibraryRangeModel({ preflopSource: src, EM, fallback: 'unavailable' }); const un = strict.rangesFor({ ...base, hand: 11, stacks: Array(8).fill(1800), street: 'flop', actions: pre }, { live: [0, 7] });
  assert.ok(un.unavailable); assert.equal(un.code, 'range-unknown');
  // insufficient support (>25% unsupported) falls back
  const thin = new RM.LibraryRangeModel({ preflopSource: F.fakePreflop({ missing: RE.CLASS_NAMES.slice(0, 60).map((c) => [0, c]) }), EM });
  const t2 = thin.rangesFor({ ...base, hand: 12, street: 'flop', actions: pre }, { live: [0, 7] }); assert.ok(t2.fallback); assert.equal(t2.perSeat[0].support, 'insufficient');
});

test('range view for the dashboard removes the viewer\'s known cards and the board from opponents\' ranges', () => {
  const src = F.fakePreflop(), model = new RM.LibraryRangeModel({ preflopSource: src, EM }), base = { table: 2, hand: 1, button: F.BUTTON, stacks: Array(8).fill(2500), blinds: { sb: 50, bb: 100, ante: 10 } };
  model.rangesFor({ ...base, street: 'flop', actions: F.preflopActions('rfffffff') }, { live: [0, 7] });
  const v = model.view(2, 1, ['As', 'Ah'], ['Kd', '7c', '2h']); assert.equal(v.status, 'ok');
  assert.ok(v.seats[0].combos < 1326); assert.ok(v.seats[0].top.length > 0); assert.ok(Array.isArray(v.seats[0].history));
});

test('street-conditioned (per-combination) ranges are accepted by the study builder and train', () => {
  const A = require('../src/study-adapter.js'), r = RE.WeightedRange.anyTwo(), lik = new Float64Array(1326); for (let i = 0; i < 1326; i++) lik[i] = ((i * 7919) % 100) / 100; r.condition(lik);
  const t = r.toStudyText(EM, { quantum: 0.02 }); assert.ok(t.text.length > 2000, 'per-combination text is long (' + t.text.length + ')');
  const p = A.prepare(EM, { config: { board: 'Kh9s5c3d2h', common: 6, stacks: [20, 20], ranges: [t.text, 'random'], streets: { river: { bets: '50', raises: 'a', maxBets: 1 } } }, iterations: 10 }); p.game.iterate(50);
  const back = RE.WeightedRange.fromText(EM, t.text); back.removeCards(['Kh', '9s', '5c', '3d', '2h']); assert.equal(p.spec.hands[0].length, back.combos(), 'study rows = combinations of the text not blocked by the board');
  assert.throws(() => A.prepare(EM, { config: { board: 'Kh9s5c3d2h', common: 6, stacks: [20, 20], ranges: ['AA,'.repeat(9000), 'random'], streets: { river: { bets: '50', raises: 'a', maxBets: 1 } } }, iterations: 10 }), /24,000/);
});
