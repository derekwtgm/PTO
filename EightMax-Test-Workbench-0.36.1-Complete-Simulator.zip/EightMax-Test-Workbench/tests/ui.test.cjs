'use strict';
(function(){
let chromium=null;try{({chromium}=require('playwright'));}catch(e){}
const exe=process.env.CHROME_PATH||'/usr/bin/chromium';if(!chromium||!require('node:fs').existsSync(exe)){require('node:test')('browser UI smoke test',{skip:'Playwright/Chromium not available here (needs require("playwright") and '+exe+')'},()=>{});return;}
const assert=require('node:assert/strict');const path=require('node:path');
(async()=>{const browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:1536,height:1200}});const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('file://'+path.resolve(__dirname,'../START.html'));
assert.equal(await page.locator('.table-card').count(),10);await page.click('#start');await page.waitForTimeout(1800);assert.ok(await page.evaluate(()=>window.workbench.coordinator.totalActions)>0);await page.click('[data-table="5"]');assert.match(await page.locator('#detail-title').innerText(),/05/);await page.click('#table-pause');assert.equal(await page.evaluate(()=>window.workbench.coordinator.tables[4].paused),true);await page.click('#table-pause');assert.equal(await page.evaluate(()=>window.workbench.coordinator.tables[4].paused),false);
await page.click('#pause');const before=await page.evaluate(()=>window.workbench.coordinator.totalActions);await page.waitForTimeout(250);assert.equal(await page.evaluate(()=>window.workbench.coordinator.totalActions),before);
await page.click('#replay-nav');assert.equal(await page.locator('#replay-panel').isVisible(),true);assert.ok((await page.locator('#replay-caption').innerText()).includes('Frame'));await page.click('#close-replay');await page.click('#start');await page.waitForTimeout(600);await page.click('#stop');assert.equal(await page.locator('#start').isDisabled(),true);assert.match(await page.locator('#status-text').innerText(),/latched/);
page.on('dialog',d=>d.accept());await page.click('#reset');await page.selectOption('#speed','3');await page.click('#start');await page.waitForTimeout(4500);await page.click('#pause');await page.screenshot({path:path.resolve(__dirname,'../docs/dashboard-preview.png'),fullPage:true});
// Export creates a parseable read-only replay and import shows it without execution.
const downloadPromise=page.waitForEvent('download');await page.click('#export');const download=await downloadPromise;const stream=await download.createReadStream();let text='';for await(const chunk of stream)text+=chunk;assert.ok(JSON.parse(text).frames.length>0);
await page.click('#replay-nav');await page.setInputFiles('#file',{name:'replay.json',mimeType:'application/json',buffer:Buffer.from(text)});assert.equal(await page.evaluate(()=>window.workbench.coordinator.running),false);
await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.resolve(__dirname,'../docs/mobile-preview.png'),fullPage:true});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth),true);
assert.deepEqual(errors,[]);console.log('PASS browser UI: 10 tables; start/pause/resume; per-table pause; emergency stop/reset; replay export/import; responsive layout; no script errors.');await browser.close();})().catch(e=>{console.error(e);process.exit(1);});

})();
