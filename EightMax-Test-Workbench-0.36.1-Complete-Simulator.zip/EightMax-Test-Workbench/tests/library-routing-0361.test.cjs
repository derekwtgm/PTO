'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),os=require('node:os'),fs=require('node:fs'),path=require('node:path');
const service=require('../tools/simulator-library-decision.cjs'),SS=require('../src/solver-service.js'),EM=require('../src/engine.js'),HS=require('../src/hand-state.js');
function request(){const t=new EM.Table(1,7);t.startHand();const h=new HS.HandStateEngine(1);return SS.requestFromState(h.ingest(HS.observeSimulator(t,t.actor,{actions:[]})).state);}
test('stored lookup rejects invalid observations before invoking engine',async()=>{
 let called=false;await assert.rejects(service.decide({}, {verifyEngine:()=>{called=true;}}));assert.equal(called,false);
});
test('lookup refuses incompatible engine and preflop instead of inventing strategy',async()=>{
 const req=request();await assert.rejects(service.decide(req,{verifyEngine:()=>({version:'5.4',build:'wrong'})}),/Incompatible/);
 const d=await service.decide(req,{verifyEngine:()=>({version:'5.1',build:'7d08acc7eb4577ee'})});assert.equal(d.status,'unavailable');assert.match(d.reason,/preflop/);
});
test('native engine probe reports actual startup failure on non-Windows', {skip:process.platform==='win32'},()=>{assert.throws(()=>service.verifyEngine(),/startup/);});
