@echo off
rem EightMax Test Workbench 0.36.2-dev - MILESTONE 2 Windows tests: simulator window lifecycle, safe recovery, input cancellation,
rem emergency-stop priority and preserved scripted gameplay, with REAL windows. Nothing needs to be installed (bundled Node.js).
rem The mouse moves by itself inside the EightMax test tables for about 10-15 minutes: do not touch the mouse or keyboard.
rem Results: test-results\Milestone2-<date-time>\ next to this file (and a .zip of it). Read READ-ME-MILESTONE2-TESTS.txt.
setlocal
cd /d "%~dp0"
echo EightMax 0.36.2 Milestone 2 tests. Close the EightMax Workbench and its dashboard before continuing.
echo The mouse will move by itself inside the test tables. Do not touch the mouse or keyboard until the end.
pause
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\Test-Milestone2-0362.ps1" %*
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" (echo MILESTONE 2 TESTS PASSED.) else (echo MILESTONE 2 TESTS FAILED - send the results ZIP named above.)
pause
endlocal & exit /b %RC%
