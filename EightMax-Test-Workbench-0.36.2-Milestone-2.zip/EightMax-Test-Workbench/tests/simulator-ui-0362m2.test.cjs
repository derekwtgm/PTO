'use strict';
// 0.36.2 Milestone 2: the dashboard's window-lifecycle and guided-recovery flow in a real browser (Playwright/Chromium) against a
// FAKE desktop host on the host's own origin. The fake driver answers like the real one: a closed window is window-gone, a restarted
// simulator is a NEW handle and process with the same executable SHA-256. No real input happens here; the test asserts that recovery
// never sends input, never arms automation and never captures the old handle, and that every step needs the operator.
const test = require('node:test'), assert = require('node:assert/strict'), path = require('path'), fs = require('fs');
let chromium = null; try { ({ chromium } = require('playwright')); } catch (e) { /* not installed */ }
const ROOT = path.join(__dirname, '..'), FD = require('../src/fixture-dealer.js');
const skip = chromium && fs.existsSync(path.join(ROOT, 'START.html')) ? false : 'needs Playwright and START.html';
const TOKEN = 'b'.repeat(64), SHA = 'f'.repeat(64);

test('M2 dashboard: lost window is shown and never retried; a replacement needs review, confirmation, fresh authorisation and an explicit enable', { skip, timeout: 180000 }, async () => {
  const html = fs.readFileSync(path.join(ROOT, 'START.html'), 'utf8'); let frame = null;
  const d = new FD.TableDealer({ table: 1, send: (m) => { if (m.type === 'frame') frame = m; } }); d.onWindow({ type: 'ready', client: { x: 100, y: 80, w: 960, h: 600 } });
  const client = { x: 100, y: 80, w: 960, h: 600 }, px = (b) => ({ x: Math.round(client.x + b.x * client.w), y: Math.round(client.y + b.y * client.h), w: Math.round(b.w * client.w), h: Math.round(b.h * client.h) });
  const A = { hwnd: '0x1A2B', pid: 77, processStart: '133', className: 'MySimWindow', title: 'My Poker Simulator', exe: 'C:\\Sim\\MySim.exe', client, dpiScale: 1.25, minimized: false };
  const B = { hwnd: '0x3C4D', pid: 88, processStart: '244', className: 'MySimWindow', title: 'My Poker Simulator', exe: 'C:\\Sim\\MySim.exe', client, dpiScale: 1.25, minimized: false };
  const world = { windows: [A], estop: null }, commands = [], frames = [], registrations = [];
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1400, height: 1000 } }); const errors = [];
  page.on('pageerror', (e) => errors.push(e.message)); page.on('dialog', (dlg) => dlg.accept());
  await page.route('http://127.0.0.1:48713/**', async (route) => {
    const req = route.request(), url = new URL(req.url()), p = url.pathname;
    if (p === '/' || p === '/START.html') return route.fulfill({ status: 200, contentType: 'text/html', body: html });
    if (req.headers()['x-eightmax-session'] !== TOKEN) return route.fulfill({ status: 403, contentType: 'application/json', body: '{"error":"session"}' });
    const body = req.postData() ? JSON.parse(req.postData()) : null, j = (v) => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(v) });
    const win = (h) => world.windows.find((w) => w.hwnd.toLowerCase() === String(h || '').toLowerCase());
    if (p === '/api/input/settings') return j(body ? { ok: true } : { format: 'eightmax-input-settings', saved: false });
    if (p === '/api/input/status') return j({ format: 'eightmax-input-status', version: 1, running: true, driver: { driver: '0.36.2-dev', armed: commands.includes('arm'), estop: world.estop, capabilities: { hotkey: 'Ctrl+Alt+F12', hotkeyRegistered: true, dpiAwareness: 'per-monitor-v2', uiAutomation: true, rawInputOverride: true } }, events: [] });
    if (p === '/api/input/estop') { world.estop = 'dashboard'; return j({ ok: true }); }
    if (p === '/api/capture/open') return win(body.target.hwnd) ? j({ ok: true }) : j({ ok: false, code: 'target-lost', reason: 'The window no longer exists.' });
    if (p === '/api/capture/close') return j({ ok: true, closedSessions: 0 });
    if (p === '/api/capture/frame') { frames.push(body.target.hwnd); return win(body.target.hwnd) ? j({ ok: true, width: frame.w, height: frame.h, png: frame.png, bounds: { x: client.x, y: client.y, width: client.w, height: client.h }, dpiScale: 1.25, title: 'My Poker Simulator' }) : j({ ok: false, code: 'target-lost', reason: 'The window no longer exists.' }); }
    if (p === '/api/simulator/decision') return j({ status: 'unavailable', reason: 'No compatible EightMax preflop study is loaded' });
    if (p === '/api/input/command') {
      commands.push(body.cmd); const w = win(body.hwnd);
      switch (body.cmd) {
        case 'status': return j({ ok: true, estop: world.estop, capabilities: { signedCurves: true, maxDeviationPx: true, singleClickGuardMaxMs: 540 } });
        case 'arm': return world.estop ? j({ ok: false, code: 'emergency-stop', error: 'Reset the emergency stop first.' }) : j({ ok: true });
        case 'list-windows': return j({ ok: true, windows: world.windows.map((x) => ({ ...x, registered: registrations.some((r) => r.hwnd === x.hwnd) })) });
        case 'exe-identity': return w ? j({ ok: true, exeSha256: SHA, window: w }) : j({ ok: false, code: 'window-gone', error: 'That window no longer exists.' });
        case 'register-target': if (!w) return j({ ok: false, code: 'window-gone', error: 'That window no longer exists.' }); registrations.push({ hwnd: body.hwnd, auth: body.authorization }); return j({ ok: true, window: w, exeSha256: SHA });
        case 'unregister-target': return j({ ok: true });
        case 'window-info': return w ? j({ ok: true, window: w }) : j({ ok: false, code: 'window-gone', error: 'That window no longer exists.' });
        case 'uia-controls': return j({ ok: true, available: true, controls: [['Fold', 'fold'], ['Check', 'check'], ['Call', 'call'], ['Raise', 'raise'], ['All-in', 'allin']].map(([n, k]) => ({ name: n, type: 'Button', box: px(FD.CONTROLS[k]) })).concat([{ name: 'Wager amount', type: 'Edit', box: px(FD.WAGER_FIELD) }]) });
        default: return j({ ok: true, plannedMs: 10, actualMs: 11, steps: 2, clickedAt: body.to || { x: 0, y: 0 } });
      }
    }
    return j({ ok: false, error: 'unhandled ' + p });
  });
  const status = () => page.textContent('#simc-status');
  try {
    await page.goto('http://127.0.0.1:48713/#desktop-token=' + TOKEN); await page.click('#simc-nav'); await page.waitForTimeout(600);
    await page.selectOption('#simc-window', A.hwnd); await page.click('#simc-calibrate'); await page.waitForTimeout(400); await page.click('#simc-uia'); await page.waitForTimeout(200);
    await page.fill('#simc-prof-id', 'my-sim'); const dl = page.waitForEvent('download'); await page.click('#simc-save-profile'); await dl;
    for (const id of ['#simc-own', '#simc-test', '#simc-nomoney']) await page.check(id);
    await page.click('#simc-register'); await page.waitForTimeout(300); assert.match(await status(), /Registered My Poker Simulator/);
    assert.match(await page.textContent('#simc-lifecycle-summary'), /1 REGISTERED/);

    // ---- the simulator closes; automation is started anyway: the stale registration is detected before ANY capture ----
    world.windows = []; const framesBefore = frames.length;
    await page.click('#simc-start'); await page.waitForTimeout(600);
    assert.match(await status(), /No registered simulator window can be automated.*lost: reopen the simulator and register its window again/);
    assert.equal(frames.length, framesBefore, 'no capture request for the lost window'); assert.ok(!commands.includes('arm'), 'automation never armed');
    const row = await page.textContent('#simc-tables'); assert.match(row, /Simulator window closed/); assert.match(row, /Automation for this table has stopped/); assert.match(row, /Original window exists: no/); assert.match(row, /Re-registration required: yes/);
    assert.match(await page.textContent('#simc-lifecycle-summary'), /1 TARGET_LOST/);
    await page.waitForTimeout(2500); assert.equal(frames.length, framesBefore, 'still no capture after periodic refreshes');

    // ---- the simulator is reopened: a candidate is offered, never controlled ----
    world.windows = [B]; await page.click('#simc-refresh-registrations'); await page.waitForTimeout(500);
    assert.equal(await page.isVisible('#simc-recovery'), true); const card = await page.textContent('#simc-recovery-list');
    assert.match(card, /0x3C4D/); assert.match(card, /pid 88/); assert.match(card, /same program/); assert.match(await page.textContent('#simc-tables'), /1 replacement window\(s\) available/);
    const regBtn = page.getByRole('button', { name: 'Register this window as the replacement' });
    await regBtn.click(); await page.waitForTimeout(200); assert.match(await status(), /Confirm that the replacement is your own simulator/); assert.equal(registrations.length, 1, 'refused without the confirmations');
    // emergency stop latched: recovery refuses to register anything
    world.estop = 'dashboard'; const boxes = page.locator('#simc-recovery-list input[type=checkbox]'); for (let i = 0; i < 3; i++) await boxes.nth(i).check();
    await regBtn.click(); await page.waitForTimeout(300); assert.match(await status(), /Emergency stop is latched/); assert.equal(registrations.length, 1);
    world.estop = null; await regBtn.click(); await page.waitForTimeout(600);
    assert.match(await status(), /Replacement registered for table 1/); assert.match(await status(), /automation for it is OFF/);
    assert.equal(registrations.length, 2); assert.equal(registrations[1].hwnd, B.hwnd); assert.ok(registrations[1].auth.expiresAtUnixMs > Date.now(), 'a FRESH authorisation was issued');
    assert.equal(await page.isVisible('#simc-recovery'), false); const after = await page.textContent('#simc-tables'); assert.match(after, /Registered/); assert.match(after, /Replaces registration reg-/);
    for (const c of ['move', 'move-click', 'click', 'enter-text', 'type', 'arm']) assert.ok(!commands.includes(c), 'recovery sent no ' + c);
    assert.ok(!frames.includes(A.hwnd) || frames.lastIndexOf(A.hwnd) < framesBefore, 'the old handle was never captured after the loss');

    // ---- the export carries lifecycle, retired registration and the separated failure families ----
    const dl2 = page.waitForEvent('download'); await page.click('#simc-export-report'); const file = await dl2, doc = JSON.parse(fs.readFileSync(await file.path(), 'utf8'));
    assert.equal(doc.format, 'eightmax-simulator-diagnostics'); assert.equal(doc.version, 1); assert.ok(doc.extensions.includes('window-lifecycle-v1'));
    assert.equal(doc.registrations.length, 1); assert.equal(doc.registrations[0].lifecycle.state, 'REGISTERED'); assert.ok(doc.registrations[0].replaces);
    assert.equal(doc.retiredRegistrations.length, 1); assert.equal(doc.retiredRegistrations[0].lifecycle.state, 'TARGET_LOST'); assert.equal(doc.failureSummary.targetLost, 1);
    assert.ok(doc.lifecycleEvents.some((e) => e.to === 'TARGET_LOST')); assert.ok(Array.isArray(doc.tables) && doc.diagnostics && doc.diagnostics.format === 'eightmax-diagnostics', 'existing fields preserved');
    assert.deepEqual(errors, []);
  } finally { await browser.close(); }
});
