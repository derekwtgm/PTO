/* EightMax Test Workbench 0.25 (0.35: real Windows input driver behind the UI adapter): execution, acknowledgment and diagnostics ADAPTERS (platform independent).
 *
 * The executor (test-executor.js) decides WHETHER an action may be sent; an execution adapter decides HOW it reaches an
 * AUTHORISED test target. Three interchangeable kinds exist, chosen by `profile.execution.interface`:
 *   internal-simulation   the workbench's own simulator (always available)
 *   test-server-api       an HTTP test server named in a QA authorisation record (loopback or individually allow-listed host)
 *   approved-ui-automation a generic driver that clicks regions taken from the PROFILE (never hard-coded), for a test client the operator owns
 * Nothing here knows any external poker client. 0.35: the UI driver is src/windows-input-driver.js (WindowsUiDriver -> desktop/bin/EightMaxInput.exe).
 * No anti-detection, no hidden input, no process-memory access.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./test-executor.js'));
  else root.WorkbenchExecutionAdapters = factory(root.WorkbenchExecutor);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (EX) {
  'use strict';

  const mono = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());

  /** Every execution adapter must look like this (checked before it can be attached). */
  const ADAPTER_CONTRACT = Object.freeze({ kind: ['simulator', 'approved-client'], submit: 'function(act) -> {accepted, reason?, simRevisionAfter?} | Promise', id: 'string' });
  function assertAdapter(a) {
    const problems = [];
    if (!a || typeof a !== 'object') return { ok: false, problems: ['adapter missing'] };
    if (!ADAPTER_CONTRACT.kind.includes(a.kind)) problems.push('adapter.kind must be one of ' + ADAPTER_CONTRACT.kind.join(', '));
    if (typeof a.submit !== 'function') problems.push('adapter.submit must be a function'); if (typeof a.id !== 'string' || !a.id) problems.push('adapter.id must be a non-empty string');
    return { ok: problems.length === 0, problems };
  }

  /** 0.35: driver refusals that happen BEFORE any button is pressed (nothing reached the simulator). Anything else may have clicked. */
  const BEFORE_INPUT = new Set(['layout-changed', 'outside-region', 'outside-window', 'target-covered', 'window-minimized', 'window-hidden', 'window-gone', 'identity-changed', 'target-not-registered', 'authorization-expired', 'not-armed', 'focus-denied', 'focus-lost', 'move-too-long', 'deadline', 'bad-request', 'bad-motion', 'unexpected-control', 'queue-full', 'expired', 'field-not-focused', 'field-unreadable', 'field-unexpected', 'clear-failed', 'verify-mismatch', 'manual-mode', 'wager-invalid', 'paused', 'stale', 'table-busy', 'no-deadline', 'double-click-not-authorized',
    // 0.36.2 M2: lifecycle refusals that are always raised before any button or key goes down
    'target-lost', 'lease-invalid', 'lifecycle-blocked', 'cancelled-before-input']);
  /** 0.35: wager conventions a simulator's entry field can use. raise-to = the total the player's bet becomes; raise-by = chips ABOVE the current highest bet. */
  const AMOUNT_CONVENTIONS = Object.freeze(['raise-to', 'raise-by']);
  /**
   * Validate and convert an executor wager (always RAISE-TO, from concretize) into the text to type. Never rounds: an amount that is
   * not a whole number of chip units, or outside the legal range, or beyond the stack, is refused.
   */
  function wagerText(act, o = {}) {
    const c = act.context || {}, unit = o.chipUnit || 1, conv = o.amountConvention || 'raise-to', to = act.amount;
    if (!AMOUNT_CONVENTIONS.includes(conv)) return { ok: false, reason: 'Unknown amount convention ' + conv };
    if (!Number.isInteger(to) || to <= 0) return { ok: false, reason: 'Wager amount invalid' };
    if (to % unit !== 0) return { ok: false, reason: 'Wager ' + to + ' is not a whole number of chip units (' + unit + ')' };
    if (Number.isFinite(c.currentBet) && to <= c.currentBet) return { ok: false, reason: 'Raise-to ' + to + ' does not exceed the current bet ' + c.currentBet };
    if (Number.isFinite(c.maxRaiseTo) && to > c.maxRaiseTo) return { ok: false, reason: 'Wager ' + to + ' exceeds the maximum ' + c.maxRaiseTo + ' (stack)' };
    if (Number.isFinite(c.minRaiseTo) && to < c.minRaiseTo && to !== c.maxRaiseTo) return { ok: false, reason: 'Wager ' + to + ' is below the minimum ' + c.minRaiseTo };
    if (Number.isFinite(c.myStack) && Number.isFinite(c.myBet) && to > c.myStack + c.myBet) return { ok: false, reason: 'Wager exceeds the available stack' };
    if (c.canRaise === false) return { ok: false, reason: 'Raising is not available' };
    if (conv === 'raise-by') { if (!Number.isFinite(c.currentBet)) return { ok: false, reason: 'raise-by needs the current bet, which was not read' }; return { ok: true, text: String(to - c.currentBet), to, convention: conv }; }
    return { ok: true, text: String(to), to, convention: conv };
  }

  /**
   * Generic UI-automation adapter. `driver.activate(regionName, box, act)` performs ONE click on a normalised region of the target window and
   * `driver.enterAmount(text, field, act)` types a wager and reads it back. Regions come from `controls` (profile.layout.controls) — nothing is
   * assumed about any client. It refuses to be built without a valid QA authorisation and a driver, and it never submits an amount it cannot
   * type exactly. 0.35: the idempotency key is recorded BEFORE any input (a slow click can no longer be repeated by an executor retry),
   * visible input is never retried (noRetry), an "allin" control is used when the profile has one, wagers follow the profile's amount
   * convention, and with a scheduler every submission runs inside one exclusive cursor lease with a deadline.
   */
  class UiAutomationAdapter {
    constructor({ authorization, now, driver, controls, amountField, amountConvention, chipUnit, scheduler, deadlineMs, controlledFixture, table }) {
      const v = EX.validateAuthorization(authorization, typeof now === 'function' ? now() : Date.now()); if (!v.valid) throw new Error('QA authorization refused: ' + v.issues.join('; '));
      if (!driver || typeof driver.activate !== 'function') throw new Error('A UI driver with activate(region, box) is required');
      if (!controls || !['fold', 'check', 'call', 'raise'].every((k) => controls[k])) throw new Error('Profile control regions fold/check/call/raise are required');
      this.kind = 'approved-client'; this.transportKind = 'ui-automation'; this.id = 'ui:' + authorization.environment; this.auth = authorization; this.driver = driver; this.controls = controls; this.amountField = amountField || null; this.sentKeys = new Set();
      this.amountConvention = amountConvention || 'raise-to'; this.chipUnit = chipUnit || 1; this.scheduler = scheduler || null; this.deadlineMs = deadlineMs || 8000; this.controlledFixture = controlledFixture === true; this.table = table; this.noRetry = true; this.ackTimeoutMs = 60000;
      if (!AMOUNT_CONVENTIONS.includes(this.amountConvention)) throw new Error('Unknown amount convention ' + this.amountConvention);
    }
    async submit(act) {
      if (this.sentKeys.has(act.key)) return { accepted: false, reason: 'Duplicate idempotency key', code: 'duplicate' };
      const allIn = this.controls.allin && (act.type === 'allin' || (act.abstractType === 'allin' && act.type === 'raise' && act.context && act.amount === act.context.maxRaiseTo));
      const region = allIn ? 'allin' : act.type === 'fold' ? 'fold' : act.type === 'check' ? 'check' : act.type === 'call' ? 'call' : 'raise';
      let wager = null;
      if (region === 'raise') {
        if (!this.amountField || typeof this.driver.enterAmount !== 'function') return { accepted: false, reason: 'Profile has no wager-entry field; cannot place a bet/raise exactly' };
        wager = wagerText(act, { amountConvention: this.amountConvention, chipUnit: this.chipUnit }); if (!wager.ok) return { accepted: false, reason: wager.reason, code: 'wager-invalid', noInputSent: true };
      }
      this.sentKeys.add(act.key);   // before any input: one key, at most one attempt
      if (this.sentKeys.size > 20000) this.sentKeys = new Set([...this.sentKeys].slice(-10000));
      const perform = async (lease) => {
        // 0.36.2 M2: a lease voided by invalidateTable (window lost) or a lifecycle guard that no longer holds sends nothing.
        const blocked = async () => { if (lease && lease.valid === false) return { code: 'lease-invalid', reason: 'The input lease was revoked (target unavailable)' }; if (typeof act.guard === 'function') { let g; try { g = await act.guard(); } catch (e) { g = { ok: false, reason: e.message }; } if (!g || g.ok !== true) return { code: (g && g.code) || 'lifecycle-blocked', reason: (g && g.reason) || 'target no longer eligible' }; } return null; };
        const b0 = await blocked(); if (b0) return { accepted: false, reason: b0.reason, code: b0.code, inputMayHaveHappened: false, noInputSent: true };
        if (wager) {
          if (tl) { try { tl.mark('wager-begin'); } catch (e) { /* measurement only */ } }
          const typed = await this.driver.enterAmount(wager.text, this.amountField, act);
          if (tl) { try { tl.mark('wager-end'); } catch (e) { /* measurement only */ } }
          // No action button was pressed yet: a failed or unverifiable wager entry sends no action (the driver cleared the field).
          if (!typed || typed.ok !== true) return { accepted: false, reason: 'Could not enter the wager: ' + (typed && typed.reason || 'driver refused'), code: typed && typed.code, inputMayHaveHappened: false, noInputSent: BEFORE_INPUT.has(typed && typed.code) || !(typed && typed.code) };
          if (lease && lease.remainingMs && lease.remainingMs() < 0) return { accepted: false, reason: 'Deadline passed while typing; not submitted', code: 'deadline', noInputSent: true };
          const b1 = await blocked(); if (b1) return { accepted: false, reason: b1.reason + ' (wager typed, no action button pressed)', code: b1.code, inputMayHaveHappened: false, noInputSent: true };
        }
        const r = await this.driver.activate(region, this.controls[region], act);
        // 0.36.2 M4.0: the driver's phases on the action timeline (measurement only)
        if (tl && r && r.detail && r.detail.timing) { try { tl.driverPhases(r.detail.timing.sentAt, r.detail.timing.repliedAt, r.detail.timing.phases); tl.mark('driver-ack', r.detail.timing.repliedAt); } catch (e) { /* measurement only */ } }
        if (r && r.ok === true) return r.detail ? { accepted: true, via: 'ui-automation', region, input: { region, wager: wager && wager.text, convention: wager && wager.convention, ...r.detail } } : { accepted: true, via: 'ui-automation', region };
        // A refusal before the button press is clean; an error after pressing could mean the click happened.
        const before = !!(r && BEFORE_INPUT.has(r.code));
        return { accepted: false, reason: 'Click failed: ' + (r && r.reason || 'driver refused'), code: r && r.code, inputMayHaveHappened: !before, noInputSent: before };
      };
      const finish = (res) => { if (res && res.accepted === false && res.noInputSent === true) this.sentKeys.delete(act.key); return res; };
      const tl = act.timeline || null; if (tl) { try { tl.mark('submitted'); } catch (e) { /* measurement only */ } }
      if (!this.scheduler) return finish(await perform(null));
      const est = (typeof this.driver.estimateMs === 'function' ? this.driver.estimateFor(region, this.controls[region], wager) : 0) || 0;
      // 0.36.2 M4.0: estimateFrom(point) lets a distance-aware policy estimate the input time from the cursor's point when the job is chosen
      const estimateFrom = typeof this.driver.estimateFor === 'function' ? (pt) => this.driver.estimateFor(region, this.controls[region], wager, pt || undefined) : null;
      const out = await this.scheduler.submit({ table: act.table, registrationId: act.registrationId, kind: region, deadline: (act.deadline || (this.scheduler.now() + this.deadlineMs)), estimateMs: est, revalidate: act.revalidate, run: perform, timeline: tl, estimateFrom });
      // 0.36.2 M4.0: a settle the driver let run after the lease (the target window confirmed it processed the click): the cursor is free
      // for other tables, and THIS table still waits the configured settle before its confirmation reads the screen
      const deferred = out.ok && out.result && out.result.input && Number(out.result.input.deferredSettleMs);
      if (deferred > 0) await new Promise((res) => setTimeout(res, deferred));
      // 0.36.2 M3.2: the lease's timing (scheduling delay, input run time) travels with the result (input-confirmation evidence, metrics)
      const schedule = { leaseId: out.leaseId === undefined ? null : out.leaseId, waitedMs: out.waitedMs, runMs: out.runMs === undefined ? null : out.runMs, code: out.ok ? null : out.code };
      if (!out.ok) return finish({ accepted: false, reason: 'Input scheduler: ' + out.reason, code: out.code, inputMayHaveHappened: out.code === 'run-failed', noInputSent: out.code !== 'run-failed', schedule });
      return finish(out.result && typeof out.result === 'object' ? { ...out.result, schedule } : out.result);
    }
  }

  /** Build the adapter a profile asks for. Throws (never silently downgrades) when the required authorisation, transport or driver is missing. */
  function adapterForProfile(profile, deps = {}) {
    const e = profile && profile.execution; if (!e) throw new Error('Profile has no execution section');
    switch (e.interface) {
      case 'none': return null;
      case 'internal-simulation': if (!deps.table) throw new Error('internal-simulation needs the simulator table'); return new EX.SimulatorAdapter(deps.table, deps.clock);
      case 'test-server-api': return new EX.ApprovedClientAdapter(deps.authorization, deps.now ? deps.now() : Date.now(), deps.transport);
      case 'approved-ui-automation': return new UiAutomationAdapter({ authorization: deps.authorization, now: deps.now, driver: deps.driver, controls: { ...(profile.layout && profile.layout.controls), ...(e.controls || {}) }, amountField: e.amountField, amountConvention: e.amountConvention, chipUnit: e.chipUnit, scheduler: deps.scheduler, deadlineMs: deps.deadlineMs, controlledFixture: profile.verification && profile.verification.status === 'controlled-renderer' && e.controlledFixture === true, table: deps.tableId });
      default: throw new Error('Unknown execution interface ' + e.interface);
    }
  }

  /**
   * Acknowledgment adapter (pure): did the NEXT reconstructed state show exactly the action that was sent?
   *   confirmed  - exactly one new action in the same hand, matching seat/type/amount, or the hand ended with it as the last action
   *   rejected   - no new action and the same actor is still to act (the interface ignored it)
   *   ambiguous  - anything else (extra or different actions, hand moved on without a record); the table must be suspended, never retried blindly
   */
  function confirmAction(sent, before, after) {
    if (!before || !after) return { status: 'ambiguous', reason: 'missing state' };
    if (after.hand !== before.hand) return { status: 'ambiguous', reason: 'hand changed (' + before.hand + ' -> ' + after.hand + ') with no record of the action' };
    const n0 = before.actions.length, n1 = after.actions.length;
    if (n1 === n0) return after.actor === before.actor && after.status !== 'complete' ? { status: 'rejected', reason: 'no new action observed; same actor still to act' } : { status: 'ambiguous', reason: 'no new action but the table moved' };
    if (n1 !== n0 + 1 && !(after.status === 'complete' && n1 > n0)) return { status: 'ambiguous', reason: (n1 - n0) + ' new actions observed after one submission' };
    const h = after.actions[n0], wager = ['bet', 'raise', 'allin'];
    const same = h.seat === sent.seat && (wager.includes(sent.type) ? wager.includes(h.type) && h.amount === sent.amount : h.type === sent.type);
    return same ? { status: 'confirmed', observed: h } : { status: 'ambiguous', reason: 'observed ' + h.type + ' by seat ' + h.seat + ' differs from the submitted ' + sent.type + ' by seat ' + sent.seat, observed: h };
  }

  /** Diagnostics adapter: one bounded, ordered record of capture / recognition / state / decision / action events per table, exportable for replay review.
   * 0.36.2 M2: identical consecutive FAILURES (same table, stage and code) are coalesced: the first is kept in full, repeats are counted
   * and closed by one 'repeat-summary' event when the episode ends (success, a different failure, or flush()). counts[stage] and
   * failureTotals still count every occurrence, so totals stay exact while the event list stays readable (801 identical target-lost
   * events in the operator's report would now be 1 event + 1 summary). Pass {coalesce:false} for the 0.35 behaviour. */
  const COALESCE_STAGES = new Set(['capture', 'recognition', 'state', 'decision']);
  const failKey = (d) => { if (d.code) return String(d.code); if (d.category) return String(d.category); const a = (d.issues && d.issues[0]) || (d.reasons && d.reasons[0]); const v = a && (a.code || a); return v ? String(v).replace(/\d+/g, '#').slice(0, 80) : 'failed'; };
  class DiagnosticsRecorder {
    constructor(o = {}) { this.max = o.max || 5000; this.clock = o.clock || mono; this.events = []; this.counts = {}; this.seq = 0; this.dropped = 0; this.coalesce = o.coalesce !== false; this.episodes = new Map(); this.suppressed = 0; this.failureTotals = {}; }
    _push(table, stage, detail) { const e = { seq: ++this.seq, t: this.clock(), table, stage, ...detail }; this.events.push(e); if (this.events.length > this.max) { this.events.shift(); this.dropped++; } return e; }
    record(table, stage, detail = {}) {
      // 0.36.2 M3: 'gameplay' carries the table's gameplay condition (waiting for a valid hand, elimination, tournament finished, ...);
      // SimulatorTable records it only when the condition CHANGES, so it never floods the bounded log.
      if (!['capture', 'recognition', 'state', 'decision', 'validation', 'execution', 'ack', 'resource', 'system', 'lifecycle', 'gameplay'].includes(stage)) throw new Error('Unknown diagnostics stage ' + stage);
      this.counts[stage] = (this.counts[stage] || 0) + 1;
      if (this.coalesce && COALESCE_STAGES.has(stage)) {
        const k = table + '|' + stage, ep = this.episodes.get(k);
        if (detail.ok === false) {
          const code = failKey(detail), tt = this.failureTotals[table] || (this.failureTotals[table] = {}); tt[stage + ':' + code] = (tt[stage + ':' + code] || 0) + 1;
          if (ep && ep.code === code) { ep.repeats++; ep.lastT = this.clock(); this.suppressed++; return ep.first; }
          if (ep) this._close(k, ep);
          const e = this._push(table, stage, detail); this.episodes.set(k, { code, first: e, repeats: 0, lastT: e.t }); return e;
        }
        if (ep) this._close(k, ep);
      }
      return this._push(table, stage, detail);
    }
    _close(k, ep) { this.episodes.delete(k); if (ep.repeats > 0) this._push(ep.first.table, ep.first.stage, { ok: false, kind: 'repeat-summary', code: ep.code, repeated: ep.repeats, firstSeq: ep.first.seq, durationMs: +(ep.lastT - ep.first.t).toFixed(1) }); }
    /** A success at this stage ends the open repeat episode (no event is stored for the success itself). */
    success(table, stage) { const k = table + '|' + stage, ep = this.episodes.get(k); if (ep) this._close(k, ep); }
    /** Close every open repeat episode (end of a run, a state transition). */
    flush(table) { for (const [k, ep] of [...this.episodes]) if (table === undefined || ep.first.table === table) this._close(k, ep); }
    forTable(table) { return this.events.filter((e) => e.table === table); }
    errors() { return this.events.filter((e) => e.ok === false || e.error); }
    export() {
      const open = [...this.episodes.values()].filter((ep) => ep.repeats > 0).map((ep) => ({ table: ep.first.table, stage: ep.first.stage, code: ep.code, firstSeq: ep.first.seq, repeated: ep.repeats, durationMs: +(ep.lastT - ep.first.t).toFixed(1) }));
      return { format: 'eightmax-diagnostics', version: 1, counts: { ...this.counts }, dropped: this.dropped, events: this.events.slice(), coalesced: this.coalesce, suppressedDuplicates: this.suppressed, openRepeats: open, failureTotals: JSON.parse(JSON.stringify(this.failureTotals)) };
    }
  }

  return { ADAPTER_CONTRACT, AMOUNT_CONVENTIONS, BEFORE_INPUT, assertAdapter, wagerText, UiAutomationAdapter, adapterForProfile, confirmAction, DiagnosticsRecorder };
});
